import React, { useState } from 'react';
import {
  Skull,
  Radio,
  Flame,
  Search,
  ExternalLink,
  MessageSquare,
  AlertTriangle,
  Coins,
  ShieldAlert,
  Sparkles,
  Layers,
  ChevronRight,
  Eye,
  X,
  CheckCircle2,
} from 'lucide-react';
import { DarkwebChatterItem, NotificationTier } from '../types/threat';
import { DARKWEB_FORUM_DISCUSSIONS, DARKWEB_LEAK_SITES } from '../data/threatData';

interface DarkwebChatterMonitorProps {
  onAnalyzeChatterWithAi: (chatter: DarkwebChatterItem) => void;
  onTestTierSound: (tier: NotificationTier) => void;
}

export const DarkwebChatterMonitor: React.FC<DarkwebChatterMonitorProps> = ({
  onAnalyzeChatterWithAi,
  onTestTierSound,
}) => {
  const [search, setSearch] = useState('');
  const [tierFilter, setTierFilter] = useState<'ALL' | NotificationTier>('ALL');
  const [selectedChatterDetail, setSelectedChatterDetail] = useState<DarkwebChatterItem | null>(null);

  const filteredChatter = DARKWEB_FORUM_DISCUSSIONS.filter((item) => {
    if (tierFilter !== 'ALL' && item.threatTier !== tierFilter) return false;
    if (search.trim()) {
      const q = search.toLowerCase();
      return (
        item.topicTitle.toLowerCase().includes(q) ||
        item.authorHandle.toLowerCase().includes(q) ||
        item.forumName.toLowerCase().includes(q) ||
        item.targetedSectorOrRegion.toLowerCase().includes(q) ||
        item.detectedTactic.toLowerCase().includes(q) ||
        item.excerpt.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const getTierBadge = (tier: NotificationTier) => {
    switch (tier) {
      case 'TIER_1_NL_VITAAL':
        return 'bg-rose-950 text-rose-300 border-rose-800 font-extrabold animate-pulse';
      case 'TIER_2_EUROPA':
        return 'bg-amber-950 text-amber-300 border-amber-800 font-bold';
      case 'TIER_3_DARKWEB_CHATTER':
        return 'bg-cyan-950 text-cyan-300 border-cyan-800 font-semibold';
    }
  };

  const getTierLabel = (tier: NotificationTier) => {
    switch (tier) {
      case 'TIER_1_NL_VITAAL':
        return '🔴 TIER 1: NL VITAAL ACCUUT';
      case 'TIER_2_EUROPA':
        return '🟠 TIER 2: EUROPA RANSOMWARE';
      case 'TIER_3_DARKWEB_CHATTER':
        return '🟡 TIER 3: DARKWEB CHATTER';
    }
  };

  return (
    <div className="bg-slate-900/90 border border-slate-800 rounded-xl sm:rounded-2xl p-3.5 sm:p-5 shadow-xl">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between pb-3 sm:pb-4 border-b border-slate-800 gap-3 sm:gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-1.5 rounded-lg bg-purple-950 text-purple-400 border border-purple-800">
              <MessageSquare className="w-4 h-4 animate-pulse" />
            </span>
            <h2 className="text-sm sm:text-base font-bold text-white tracking-tight">
              Dark Web Discussie & Forum Scanner (Ondergrondse Inlichtingen)
            </h2>
          </div>
          <p className="text-[11px] sm:text-xs text-slate-400 mt-0.5 sm:mt-1">
            Geverifieerde en ontdubbelde monitoring van Exploit.in, XSS.is, RAMP en Telegram op daadwerkelijke publicatiedatum
          </p>
        </div>

        {/* Search */}
        <div className="relative w-full md:w-auto md:min-w-[240px]">
          <Search className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Zoek forum post, exploit, broker..."
            className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-9 pr-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-purple-600 transition-colors"
          />
        </div>
      </div>

      {/* Active .Onion Leak Portals Telemetry Bar */}
      <div className="mt-3 sm:mt-4 p-3 rounded-xl bg-slate-950/90 border border-purple-900/60 space-y-2">
        <div className="flex items-center justify-between gap-2 flex-wrap">
          <span className="text-[11px] font-mono-code font-bold text-purple-300 uppercase flex items-center gap-1.5">
            <Radio className="w-3.5 h-3.5 text-rose-400 animate-pulse" />
            <span>Gemonitorde .Onion Ransomware & Afpersingsportalen (Tor Netwerk)</span>
          </span>
          <span className="text-[10px] font-mono-code text-emerald-400 bg-emerald-950/70 px-2 py-0.5 rounded border border-emerald-800">
            {DARKWEB_LEAK_SITES.length} Actieve Tor-leksites online
          </span>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2">
          {DARKWEB_LEAK_SITES.map((site) => (
            <button
              key={site.id}
              type="button"
              onClick={() => setSearch(site.name.split(' ')[0])}
              className="text-left p-2.5 rounded-lg bg-slate-900/90 hover:bg-slate-800 border border-slate-800 hover:border-purple-600/70 transition-all flex items-center justify-between gap-2 cursor-pointer"
              title={`Filter berichten op ${site.name}`}
            >
              <div className="min-w-0">
                <div className="text-xs font-bold text-white truncate">{site.name}</div>
                <div className="text-[10px] font-mono-code text-purple-300 truncate">{site.onionAddress}</div>
              </div>
              <div className="text-right shrink-0">
                <span className="text-[10px] font-mono-code font-bold bg-rose-950 text-rose-300 border border-rose-800 px-1.5 py-0.5 rounded block">
                  {site.activeVictimsCount} doelwitten
                </span>
                <span className="text-[9px] text-slate-400 font-mono-code block mt-0.5">{site.lastScraped}</span>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Filter Tabs & Tier shortcuts */}
      <div className="mt-3 sm:mt-4 flex flex-wrap items-center justify-between gap-2 border-b border-slate-800/80 pb-3">
        <div className="flex items-center gap-1.5 overflow-x-auto scrollbar-none py-0.5 max-w-full sm:flex-wrap">
          <button
            type="button"
            onClick={() => {
              setTierFilter('ALL');
              setSearch('');
            }}
            className={`px-3 py-1 rounded-lg text-xs font-semibold transition-colors shrink-0 cursor-pointer ${
              tierFilter === 'ALL' && !search
                ? 'bg-purple-600 text-white shadow-sm shadow-purple-950'
                : 'bg-slate-950 text-slate-400 hover:text-white border border-slate-800'
            }`}
          >
            Alle Berichten ({DARKWEB_FORUM_DISCUSSIONS.length})
          </button>
          <button
            type="button"
            onClick={() => {
              setTierFilter('ALL');
              setSearch(search.toLowerCase() === 'php2shell' ? '' : 'php2shell');
            }}
            className={`px-3 py-1 rounded-lg text-xs font-bold transition-colors flex items-center gap-1.5 shrink-0 cursor-pointer ${
              search.toLowerCase() === 'php2shell'
                ? 'bg-rose-600 text-white border border-rose-400 shadow-sm'
                : 'bg-rose-950/90 text-rose-200 hover:text-white border border-rose-700'
            }`}
          >
            <span>🚨</span> PHP2Shell (50+ Gemeenten / CISA KEV)
          </button>
          <button
            type="button"
            onClick={() => {
              setTierFilter('ALL');
              setSearch(search.toLowerCase() === 'brotli' ? '' : 'brotli');
            }}
            className={`px-3 py-1 rounded-lg text-xs font-bold transition-colors flex items-center gap-1.5 shrink-0 cursor-pointer ${
              search.toLowerCase() === 'brotli'
                ? 'bg-cyan-600 text-white border border-cyan-400 shadow-sm'
                : 'bg-cyan-950/80 text-cyan-200 hover:text-white border border-cyan-700'
            }`}
          >
            <span>⚡</span> Node2Shell / Google Brotli (CVE-2026-111497)
          </button>
          <button
            type="button"
            onClick={() => {
              setTierFilter('ALL');
              setSearch(search.toLowerCase() === 'pepijn' ? '' : 'pepijn');
            }}
            className={`px-3 py-1 rounded-lg text-xs font-bold transition-colors flex items-center gap-1.5 shrink-0 cursor-pointer ${
              search.toLowerCase() === 'pepijn'
                ? 'bg-amber-600 text-white border border-amber-400 shadow-sm'
                : 'bg-amber-950/80 text-amber-200 hover:text-white border border-amber-700'
            }`}
          >
            <span>🇳🇱</span> Pepijn van der Stap / ShinyHunters
          </button>
          <button
            type="button"
            onClick={() => {
              setTierFilter('ALL');
              setSearch(search.toLowerCase() === 'philips' ? '' : 'philips');
            }}
            className={`px-3 py-1 rounded-lg text-xs font-bold transition-colors flex items-center gap-1.5 shrink-0 cursor-pointer ${
              search.toLowerCase() === 'philips'
                ? 'bg-rose-600 text-white border border-rose-400 shadow-sm'
                : 'bg-rose-950/80 text-rose-200 hover:text-white border border-rose-800'
            }`}
          >
            <span>🕵️‍♂️</span> Philips & Shell Cl0p Dossier
          </button>
          <button
            type="button"
            onClick={() => setTierFilter('TIER_1_NL_VITAAL')}
            className={`px-3 py-1 rounded-lg text-xs font-semibold transition-colors flex items-center gap-1.5 shrink-0 cursor-pointer ${
              tierFilter === 'TIER_1_NL_VITAAL'
                ? 'bg-rose-950 text-rose-300 border border-rose-700'
                : 'bg-slate-950 text-rose-400 hover:text-white border border-slate-800'
            }`}
          >
            <span>🚨</span> Tier 1 (NL Vitaal)
          </button>
          <button
            type="button"
            onClick={() => setTierFilter('TIER_2_EUROPA')}
            className={`px-3 py-1 rounded-lg text-xs font-semibold transition-colors flex items-center gap-1.5 cursor-pointer ${
              tierFilter === 'TIER_2_EUROPA'
                ? 'bg-amber-950 text-amber-300 border border-amber-700'
                : 'bg-slate-950 text-amber-400 hover:text-white border border-slate-800'
            }`}
          >
            <span>⚠️</span> Tier 2 (Europa)
          </button>
          <button
            type="button"
            onClick={() => setTierFilter('TIER_3_DARKWEB_CHATTER')}
            className={`px-3 py-1 rounded-lg text-xs font-semibold transition-colors flex items-center gap-1.5 cursor-pointer ${
              tierFilter === 'TIER_3_DARKWEB_CHATTER'
                ? 'bg-cyan-950 text-cyan-300 border border-cyan-700'
                : 'bg-slate-950 text-cyan-400 hover:text-white border border-slate-800'
            }`}
          >
            <span>📡</span> Tier 3 (Ondergronds Chatter)
          </button>
        </div>

        <div className="text-[11px] text-slate-400 font-mono-code">
          Tor Scraper: <strong className="text-emerald-400">{DARKWEB_LEAK_SITES.length} .onion portals & fora (0 duplicaten)</strong>
        </div>
      </div>

      {/* Chatter cards feed */}
      <div className="mt-4 space-y-3.5">
        {filteredChatter.map((item) => (
          <div
            key={item.id}
            className={`p-4 rounded-xl border transition-all ${
              item.threatTier === 'TIER_1_NL_VITAAL'
                ? 'bg-slate-950/90 border-rose-900/70 shadow-md shadow-rose-950/20'
                : item.threatTier === 'TIER_2_EUROPA'
                ? 'bg-slate-950/70 border-amber-900/50'
                : 'bg-slate-950/50 border-slate-800'
            }`}
          >
            {/* Card top row */}
            <div className="flex flex-wrap items-center justify-between gap-2 pb-2.5 border-b border-slate-900">
              <div className="flex flex-wrap items-center gap-2">
                <span className={`text-[10px] font-mono-code px-2 py-0.5 rounded border ${getTierBadge(item.threatTier)}`}>
                  {getTierLabel(item.threatTier)}
                </span>

                <span className="text-xs font-bold text-slate-200 flex items-center gap-1">
                  <span>{item.originFlag}</span>
                  <span className="text-white">{item.forumName}</span>
                </span>

                <span className="text-slate-600">•</span>

                <span className="text-xs text-purple-300 font-mono-code">
                  Auteur: <strong className="text-purple-200">{item.authorHandle}</strong> ({item.authorReputation})
                </span>
              </div>

              <div className="text-[11px] font-mono-code text-amber-300 bg-slate-900 px-2 py-0.5 rounded border border-slate-800">
                📅 {item.timestamp}
              </div>
            </div>

            {/* Title & Post Excerpt */}
            <div className="mt-3">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                {item.topicTitle}
              </h3>
              <p className="mt-2 text-xs text-slate-300 bg-slate-900/90 p-3 rounded-lg border border-slate-800/80 font-mono-code leading-relaxed">
                "{item.excerpt}"
              </p>
            </div>

            {/* Metadata Pills: 2-column on mobile (just like tablet!), 4 on desktop */}
            <div className="mt-3 grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-4 gap-2 text-xs">
              <div className="p-2 rounded-lg bg-slate-900/60 border border-slate-800/80">
                <span className="text-[10px] text-slate-400 block font-mono-code">BEOOGD DOELWIT</span>
                <span className="font-semibold text-rose-300 truncate block text-[11px] sm:text-xs">
                  {item.targetedSectorOrRegion}
                </span>
              </div>

              <div className="p-2 rounded-lg bg-slate-900/60 border border-slate-800/80">
                <span className="text-[10px] text-slate-400 block font-mono-code">GEDETECTEERDE TACTIEK</span>
                <span className="font-mono-code text-amber-300 truncate block text-[11px]">
                  {item.detectedTactic}
                </span>
              </div>

              <div className="p-2 rounded-lg bg-slate-900/60 border border-slate-800/80">
                <span className="text-[10px] text-slate-400 block font-mono-code">ACTOR AFFILIATIE</span>
                <span className="font-semibold text-purple-300 truncate block text-[11px] sm:text-xs">
                  {item.actorAffiliation}
                </span>
              </div>

              <div className="p-2 rounded-lg bg-slate-900/60 border border-slate-800/80">
                <span className="text-[10px] text-slate-400 block font-mono-code">PRIJS / FORUM LINK</span>
                <span className="font-mono-code text-emerald-300 truncate block text-[11px]">
                  {item.priceListed || item.onionUrlMask}
                </span>
              </div>
            </div>

            {/* Bottom Actions */}
            <div className="mt-3 pt-2.5 border-t border-slate-900 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setSelectedChatterDetail(item)}
                  className="w-full sm:w-auto px-3 py-1.5 sm:py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold border border-slate-700 transition-colors flex items-center justify-center gap-1.5 min-h-[38px] sm:min-h-0 cursor-pointer"
                >
                  <Eye className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Details & Forum Dossier</span>
                </button>
              </div>

              <div className="flex items-center gap-2 w-full sm:w-auto">
                <button
                  type="button"
                  onClick={() => onAnalyzeChatterWithAi(item)}
                  className="flex-1 sm:flex-initial flex items-center justify-center gap-1.5 px-3 py-2 sm:py-1 rounded-lg bg-gradient-to-r from-purple-600 to-rose-600 hover:from-purple-500 hover:to-rose-500 text-white text-xs font-bold transition-all shadow-md shadow-purple-950/40 min-h-[38px] sm:min-h-0 cursor-pointer"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>AI Analyse</span>
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Dark Web Chatter Detail Modal */}
      {selectedChatterDetail && (
        <div
          onClick={() => setSelectedChatterDetail(null)}
          className="fixed inset-0 z-[70] flex items-center justify-center p-2.5 sm:p-4 bg-slate-950/85 backdrop-blur-sm animate-in fade-in duration-150"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="bg-slate-900 border border-purple-700/80 rounded-2xl max-w-2xl w-full p-4 sm:p-6 shadow-2xl relative overflow-hidden flex flex-col max-h-[92vh]"
          >
            <div className="flex items-start justify-between gap-3 pb-4 border-b border-slate-800">
              <div className="space-y-1.5">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className={`text-[10px] font-mono-code px-2 py-0.5 rounded border ${getTierBadge(selectedChatterDetail.threatTier)}`}>
                    {getTierLabel(selectedChatterDetail.threatTier)}
                  </span>
                  <span className="text-xs font-bold text-white flex items-center gap-1">
                    <span>{selectedChatterDetail.originFlag}</span>
                    <span>{selectedChatterDetail.forumName}</span>
                  </span>
                </div>
                <h2 className="text-base sm:text-lg font-extrabold text-white">
                  {selectedChatterDetail.topicTitle}
                </h2>
              </div>
              <button
                type="button"
                onClick={() => setSelectedChatterDetail(null)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="mt-4 flex-1 overflow-y-auto space-y-4 pr-1 text-xs">
              <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-1.5">
                <div className="text-[10px] font-mono-code text-purple-400 uppercase font-bold">
                  Onderschept Dark Web Bericht ({selectedChatterDetail.onionUrlMask})
                </div>
                <p className="text-xs text-slate-200 font-mono-code leading-relaxed bg-slate-900 p-3 rounded-lg border border-slate-800">
                  "{selectedChatterDetail.excerpt}"
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800">
                  <span className="text-[10px] font-mono-code text-slate-400 block">AUTEUR & REPUTATIE</span>
                  <span className="font-bold text-purple-300 mt-0.5 block">
                    {selectedChatterDetail.authorHandle} ({selectedChatterDetail.authorReputation})
                  </span>
                  <span className="text-[11px] text-slate-400 mt-0.5 block">
                    Affiliatie: {selectedChatterDetail.actorAffiliation}
                  </span>
                </div>

                <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800">
                  <span className="text-[10px] font-mono-code text-slate-400 block">BEOOGD DOELWIT & TACTIEK</span>
                  <span className="font-bold text-rose-300 mt-0.5 block">
                    {selectedChatterDetail.targetedSectorOrRegion}
                  </span>
                  <span className="text-[11px] text-amber-300 font-mono-code mt-0.5 block">
                    {selectedChatterDetail.detectedTactic}
                  </span>
                </div>
              </div>

              <div className="p-3.5 rounded-xl bg-emerald-950/30 border border-emerald-800/70 space-y-1.5">
                <div className="flex items-center gap-1.5 text-emerald-300 font-bold">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>CSIRT-NL & NCSC Handelingsperspectief</span>
                </div>
                <p className="text-slate-200 leading-relaxed">
                  Dit bericht is geautomatiseerd onderschept op {selectedChatterDetail.forumName}. Controleer direct of uw organisatie gebruikmaakt van de genoemde randapparatuur of voorkomt in gelekte stealer-logs, en verifieer FIDO2-MFA op alle externe toegangen.
                </p>
              </div>
            </div>

            <div className="mt-4 pt-3 border-t border-slate-800 flex items-center justify-between gap-2">
              <button
                type="button"
                onClick={() => {
                  const item = selectedChatterDetail;
                  setSelectedChatterDetail(null);
                  onAnalyzeChatterWithAi(item);
                }}
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-gradient-to-r from-purple-600 to-rose-600 hover:from-purple-500 hover:to-rose-500 text-white text-xs font-bold transition-all cursor-pointer"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>Open in NCSC AI Analyse</span>
              </button>

              <button
                type="button"
                onClick={() => setSelectedChatterDetail(null)}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold transition-colors cursor-pointer"
              >
                Sluiten
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
