import React, { useState } from 'react';
import {
  FileText,
  Download,
  Printer,
  X,
  ShieldAlert,
  Building2,
  Lock,
  CheckCircle2,
  Sliders,
  Eye,
  Sparkles,
} from 'lucide-react';
import { ThreatItem, VitalSectorNL } from '../types/threat';
import { ExecutiveSummaryData } from './ThreatAnalysisSummary';
import { downloadThreatAnalysisPdf, generateThreatAnalysisPdf, PdfExportOptions } from '../utils/pdfExport';

export interface ThreatReportPdfModalProps {
  isOpen: boolean;
  onClose: () => void;
  summaryData: ExecutiveSummaryData;
  threats: ThreatItem[];
  selectedSector?: VitalSectorNL | 'ALL';
}

export const ThreatReportPdfModal: React.FC<ThreatReportPdfModalProps> = ({
  isOpen,
  onClose,
  summaryData,
  threats,
  selectedSector = 'ALL',
}) => {
  const [orgName, setOrgName] = useState<string>('NCSC Veiligheidsregio & Vitale Infrastructuur');
  const [classification, setClassification] = useState<'TLP:CLEAR' | 'TLP:GREEN' | 'TLP:AMBER' | 'TLP:RED'>('TLP:AMBER');
  const [authorName, setAuthorName] = useState<string>('Nationale CTI Threat Desk');
  const [includeSectorBreakdown, setIncludeSectorBreakdown] = useState<boolean>(true);
  const [includeRecommendations, setIncludeRecommendations] = useState<boolean>(true);
  const [includeLiveIncidents, setIncludeLiveIncidents] = useState<boolean>(true);
  const [isExporting, setIsExporting] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<'CONFIG' | 'PREVIEW'>('CONFIG');

  if (!isOpen) return null;

  const currentOptions: PdfExportOptions = {
    organizationName: orgName,
    classification,
    authorName,
    includeSectorBreakdown,
    includeRecommendations,
    includeLiveIncidents,
    filterSector: selectedSector,
  };

  const handleDownload = () => {
    setIsExporting(true);
    try {
      downloadThreatAnalysisPdf(summaryData, threats, currentOptions);
    } catch (err) {
      console.error('Fout bij exporteren PDF:', err);
    } finally {
      setTimeout(() => setIsExporting(false), 500);
    }
  };

  const handlePrint = () => {
    try {
      const doc = generateThreatAnalysisPdf(summaryData, threats, currentOptions);
      doc.autoPrint();
      const blobUrl = doc.output('bloburl');
      const printWindow = window.open(blobUrl as unknown as string, '_blank');
      if (printWindow) {
        printWindow.focus();
      }
    } catch (err) {
      console.error('Fout bij printen PDF:', err);
    }
  };

  const tlpBadges = [
    { id: 'TLP:CLEAR', label: 'TLP:CLEAR', desc: 'Openbaar / Ongelimiteerd', color: 'border-slate-600 text-slate-200 bg-slate-800' },
    { id: 'TLP:GREEN', label: 'TLP:GREEN', desc: 'Brede sector & partners', color: 'border-emerald-600 text-emerald-300 bg-emerald-950/40' },
    { id: 'TLP:AMBER', label: 'TLP:AMBER', desc: 'Beperkt tot organisatie & vitale keten', color: 'border-amber-600 text-amber-300 bg-amber-950/40' },
    { id: 'TLP:RED', label: 'TLP:RED', desc: 'Strikt vertrouwelijk (alleen directie)', color: 'border-rose-600 text-rose-300 bg-rose-950/40' },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
      <div className="bg-slate-900 border border-slate-700/80 rounded-2xl w-full max-w-2xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Modal Header */}
        <div className="p-4 sm:p-5 border-b border-slate-800 bg-slate-950/70 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-400">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold text-white flex items-center gap-2">
                Exporteer Threat Briefing (PDF)
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-rose-950/80 text-rose-300 border border-rose-800/60">
                  CTI-REPORT
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                Genereer een directierapport voor verantwoording, CISO en toezichthouders.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab switch */}
        <div className="flex border-b border-slate-800 bg-slate-950/40 px-4 pt-2">
          <button
            onClick={() => setActiveTab('CONFIG')}
            className={`flex items-center gap-1.5 px-3 py-2 text-xs font-semibold border-b-2 transition-all ${
              activeTab === 'CONFIG'
                ? 'border-rose-500 text-white'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Sliders className="w-3.5 h-3.5" />
            <span>Rapport Instellingen</span>
          </button>
          <button
            onClick={() => setActiveTab('PREVIEW')}
            className={`flex items-center gap-1.5 px-3 py-2 text-xs font-semibold border-b-2 transition-all ${
              activeTab === 'PREVIEW'
                ? 'border-rose-500 text-white'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Eye className="w-3.5 h-3.5" />
            <span>Document Preview</span>
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-4 sm:p-5 overflow-y-auto space-y-4">
          {activeTab === 'CONFIG' ? (
            <>
              {/* Organization name */}
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                  <Building2 className="w-3.5 h-3.5 text-slate-400" />
                  Organisatie / Ministerie / Veiligheidsregio
                </label>
                <input
                  type="text"
                  value={orgName}
                  onChange={(e) => setOrgName(e.target.value)}
                  placeholder="Bijv. Havenbedrijf Rotterdam N.V. / CISO Office"
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-rose-500"
                />
              </div>

              {/* TLP Classification */}
              <div className="space-y-2">
                <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                  <Lock className="w-3.5 h-3.5 text-amber-400" />
                  TLP Classificatie (FIRST Standards)
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {tlpBadges.map((badge) => (
                    <button
                      key={badge.id}
                      type="button"
                      onClick={() => setClassification(badge.id as any)}
                      className={`p-2.5 rounded-xl border text-left transition-all cursor-pointer ${
                        classification === badge.id
                          ? `${badge.color} ring-1 ring-rose-500/50 shadow-md`
                          : 'border-slate-800 bg-slate-950/60 text-slate-400 hover:border-slate-700'
                      }`}
                    >
                      <div className="font-bold font-mono text-xs">{badge.label}</div>
                      <div className="text-[10px] text-slate-400 truncate">{badge.desc}</div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Author name */}
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-300">
                  Opgesteld door (Rapporteur / Analist)
                </label>
                <input
                  type="text"
                  value={authorName}
                  onChange={(e) => setAuthorName(e.target.value)}
                  placeholder="Bijv. Cyber Threat Intelligence Officer"
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-rose-500"
                />
              </div>

              {/* Included Sections */}
              <div className="space-y-2 pt-2 border-t border-slate-800">
                <div className="text-xs font-semibold text-slate-300">Onderdelen in het PDF-rapport:</div>
                <div className="space-y-2">
                  <label className="flex items-center gap-2.5 text-xs text-slate-300 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={includeSectorBreakdown}
                      onChange={(e) => setIncludeSectorBreakdown(e.target.checked)}
                      className="rounded border-slate-700 text-rose-600 focus:ring-0"
                    />
                    <span>Sectoranalyse Vitale Infrastructuur Nederland (Haven, Energie, Telecom, etc.)</span>
                  </label>
                  <label className="flex items-center gap-2.5 text-xs text-slate-300 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={includeRecommendations}
                      onChange={(e) => setIncludeRecommendations(e.target.checked)}
                      className="rounded border-slate-700 text-rose-600 focus:ring-0"
                    />
                    <span>Strategische & Directie Maatregelen (Prioriteiten NCSC-NL)</span>
                  </label>
                  <label className="flex items-center gap-2.5 text-xs text-slate-300 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={includeLiveIncidents}
                      onChange={(e) => setIncludeLiveIncidents(e.target.checked)}
                      className="rounded border-slate-700 text-rose-600 focus:ring-0"
                    />
                    <span>Selectie actieve live dreigingen en forensische IoCs</span>
                  </label>
                </div>
              </div>
            </>
          ) : (
            /* PREVIEW TAB */
            <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-3 font-sans text-xs">
              <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                <div className="flex items-center gap-2">
                  <span className="px-2 py-0.5 rounded font-mono font-bold text-[10px] bg-amber-500/20 text-amber-300 border border-amber-500/40">
                    {classification}
                  </span>
                  <span className="font-bold text-white uppercase text-[11px] tracking-wide">
                    {orgName}
                  </span>
                </div>
                <span className="text-[11px] text-slate-500">2 Pagina's A4</span>
              </div>

              <div className="p-3 rounded-lg bg-rose-950/20 border border-rose-800/40">
                <div className="text-[11px] font-bold text-rose-400">
                  DREIGINGSNIVEAU: {summaryData.threatLevel} (Score: {summaryData.threatLevelScore}/100)
                </div>
                <div className="text-xs font-semibold text-white mt-0.5">{summaryData.summaryTitle}</div>
              </div>

              <div>
                <span className="font-bold text-slate-300">Directiesamenvatting:</span>
                <p className="text-slate-400 text-[11px] mt-1 leading-relaxed line-clamp-4">
                  {summaryData.executiveBriefing}
                </p>
              </div>

              <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-800 text-[11px]">
                <div>
                  <span className="font-bold text-slate-300">Geraakte Doelwitten:</span>
                  <ul className="text-slate-400 mt-1 space-y-0.5">
                    {summaryData.criticalTargets.slice(0, 3).map((t, i) => (
                      <li key={i}>• {t}</li>
                    ))}
                  </ul>
                </div>
                <div>
                  <span className="font-bold text-slate-300">Actieve Actoren:</span>
                  <ul className="text-slate-400 mt-1 space-y-0.5">
                    {summaryData.activeActors.slice(0, 3).map((a, i) => (
                      <li key={i}>• {a.name} ({a.origin})</li>
                    ))}
                  </ul>
                </div>
              </div>

              <div className="pt-2 text-[10px] text-slate-500 italic">
                * Het gedownloade PDF-bestand bevat professionele vector-opmaak met NCSC watermerken en authenticatienummer.
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer actions */}
        <div className="p-4 sm:p-5 border-t border-slate-800 bg-slate-950/70 flex flex-col sm:flex-row items-center justify-between gap-3">
          <button
            onClick={handlePrint}
            className="w-full sm:w-auto inline-flex items-center justify-center gap-1.5 px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 transition-colors"
          >
            <Printer className="w-3.5 h-3.5 text-slate-400" />
            <span>Printoverzicht</span>
          </button>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            <button
              onClick={onClose}
              className="flex-1 sm:flex-initial px-3.5 py-2 rounded-xl bg-slate-800/80 hover:bg-slate-800 text-slate-300 text-xs font-semibold transition-colors"
            >
              Annuleren
            </button>
            <button
              onClick={handleDownload}
              disabled={isExporting}
              className="flex-1 sm:flex-initial inline-flex items-center justify-center gap-2 px-5 py-2 rounded-xl bg-gradient-to-r from-rose-600 to-rose-500 hover:from-rose-500 hover:to-rose-400 text-white text-xs font-bold transition-all shadow-md shadow-rose-950/40 active:scale-95 disabled:opacity-60 cursor-pointer"
            >
              <Download className="w-4 h-4" />
              <span>{isExporting ? 'Genereren...' : 'Download PDF Rapport'}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
