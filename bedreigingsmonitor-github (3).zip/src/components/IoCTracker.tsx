import React, { useState } from 'react';
import {
  FileCode,
  Search,
  Download,
  Copy,
  Check,
  ShieldAlert,
  Hash,
  Globe2,
  AlertTriangle,
} from 'lucide-react';
import { IoCEntry } from '../types/threat';
import { INITIAL_IOCS } from '../data/threatData';

export const IoCTracker: React.FC = () => {
  const [search, setSearch] = useState('');
  const [typeFilter, setTypeFilter] = useState<'ALL' | 'SHA256' | 'IP_ADRES' | 'CVE' | 'EXTENSIE'>('ALL');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const filteredIocs = INITIAL_IOCS.filter((ioc) => {
    if (typeFilter !== 'ALL' && ioc.type !== typeFilter) return false;
    if (search.trim()) {
      const q = search.toLowerCase();
      return (
        ioc.value.toLowerCase().includes(q) ||
        ioc.associatedThreat.toLowerCase().includes(q) ||
        ioc.actor.toLowerCase().includes(q) ||
        ioc.context.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleDownloadCsv = () => {
    const headers = 'ID,Type,Value,Actor,Threat,Severity,Context\n';
    const rows = filteredIocs
      .map(
        (i) =>
          `"${i.id}","${i.type}","${i.value}","${i.actor}","${i.associatedThreat}","${i.severity}","${i.context.replace(/"/g, '""')}"`
      )
      .join('\n');
    const blob = new Blob([headers + rows], { type: 'text/csv;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `bedreigingsmonitor-nl-iocs-${Date.now()}.csv`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const handleDownloadJson = () => {
    const jsonStr = JSON.stringify(filteredIocs, null, 2);
    const blob = new Blob([jsonStr], { type: 'application/json;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `bedreigingsmonitor-nl-iocs-${Date.now()}.json`;
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="bg-slate-900/90 border border-slate-800 rounded-xl sm:rounded-2xl p-3.5 sm:p-5 shadow-xl">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 sm:pb-4 border-b border-slate-800 gap-3">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-1.5 rounded-lg bg-cyan-950 text-cyan-400 border border-cyan-800">
              <FileCode className="w-4 h-4" />
            </span>
            <h2 className="text-sm sm:text-base font-bold text-white tracking-tight">
              Indicatoren van Inbreuk (IoC Database)
            </h2>
          </div>
          <p className="text-[11px] sm:text-xs text-slate-400 mt-0.5 sm:mt-1">
            Geverifieerde SHA-256 hashes, kwaadaardige C2 IP-adressen en actieve zero-day CVE's
          </p>
        </div>

        {/* Actions */}
        <div className="flex items-center gap-2 w-full sm:w-auto">
          <button
            onClick={handleDownloadCsv}
            className="flex-1 sm:flex-initial flex items-center justify-center gap-1.5 px-3 py-2 sm:py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 transition-colors min-h-[38px] sm:min-h-0"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Exporteer CSV</span>
          </button>
          <button
            onClick={handleDownloadJson}
            className="flex-1 sm:flex-initial flex items-center justify-center gap-1.5 px-3 py-2 sm:py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 transition-colors min-h-[38px] sm:min-h-0"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Exporteer JSON</span>
          </button>
        </div>
      </div>

      {/* Filters & Search */}
      <div className="mt-3 sm:mt-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800/80 pb-3">
        <div className="flex items-center gap-1.5 overflow-x-auto scrollbar-none py-0.5 max-w-full sm:flex-wrap">
          <button
            onClick={() => setTypeFilter('ALL')}
            className={`px-3 py-1 rounded-lg text-xs font-semibold transition-colors ${
              typeFilter === 'ALL'
                ? 'bg-cyan-600 text-white shadow-sm shadow-cyan-950'
                : 'bg-slate-950 text-slate-400 hover:text-white border border-slate-800'
            }`}
          >
            Alles ({INITIAL_IOCS.length})
          </button>
          <button
            onClick={() => setTypeFilter('CVE')}
            className={`px-3 py-1 rounded-lg text-xs font-semibold transition-colors ${
              typeFilter === 'CVE'
                ? 'bg-amber-600 text-white shadow-sm'
                : 'bg-slate-950 text-slate-400 hover:text-white border border-slate-800'
            }`}
          >
            CVE Kwetsbaarheden
          </button>
          <button
            onClick={() => setTypeFilter('SHA256')}
            className={`px-3 py-1 rounded-lg text-xs font-semibold transition-colors ${
              typeFilter === 'SHA256'
                ? 'bg-rose-600 text-white shadow-sm'
                : 'bg-slate-950 text-slate-400 hover:text-white border border-slate-800'
            }`}
          >
            Hashes (SHA-256)
          </button>
          <button
            onClick={() => setTypeFilter('IP_ADRES')}
            className={`px-3 py-1 rounded-lg text-xs font-semibold transition-colors ${
              typeFilter === 'IP_ADRES'
                ? 'bg-purple-600 text-white shadow-sm'
                : 'bg-slate-950 text-slate-400 hover:text-white border border-slate-800'
            }`}
          >
            C2 IP-Adressen
          </button>
        </div>

        <div className="relative min-w-[220px]">
          <Search className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Filter IoC waarde..."
            className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-8 pr-3 py-1 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-600 transition-colors"
          />
        </div>
      </div>

      {/* IoCs List */}
      <div className="mt-4 space-y-2.5">
        {filteredIocs.map((ioc) => (
          <div
            key={ioc.id}
            className="p-3 rounded-xl bg-slate-950/70 border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs"
          >
            <div className="space-y-1 min-w-0 flex-1">
              <div className="flex items-center gap-1.5 sm:gap-2 flex-wrap">
                <span className="px-2 py-0.5 rounded text-[10px] font-mono-code font-bold bg-slate-900 border border-slate-800 text-cyan-400">
                  {ioc.type}
                </span>
                <span className="font-mono-code font-bold text-white text-xs break-all">
                  {ioc.value}
                </span>
                <span className="text-[10px] font-mono-code text-rose-400 bg-rose-950/60 px-1.5 rounded">
                  {ioc.actor}
                </span>
              </div>
              <p className="text-slate-400 text-[11px] leading-relaxed">
                {ioc.context}
              </p>
            </div>

            <div className="flex items-center gap-2 shrink-0 self-end sm:self-center">
              <button
                onClick={() => handleCopy(ioc.id, ioc.value)}
                className="flex items-center justify-center gap-1 px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-300 text-[11px] font-semibold border border-slate-800 transition-colors min-h-[34px]"
              >
                {copiedId === ioc.id ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Gekopieerd</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>Kopieer</span>
                  </>
                )}
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
