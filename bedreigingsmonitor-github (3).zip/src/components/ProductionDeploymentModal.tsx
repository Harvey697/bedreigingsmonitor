import React, { useState } from 'react';
import {
  Globe,
  Server,
  Radio,
  ShieldCheck,
  Cpu,
  Copy,
  Check,
  ExternalLink,
  X,
  Terminal,
  Zap,
  Lock,
  RefreshCw,
  Bell,
  Code2,
  Database,
  ArrowRight,
  Layers,
  Download,
  Wrench,
  AlertTriangle,
  Eye,
  EyeOff,
  Share2,
} from 'lucide-react';
import { DnsTroubleshooter } from './DnsTroubleshooter';

interface ProductionDeploymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  showHeaderButton?: boolean;
  onToggleHeaderButton?: (show: boolean) => void;
  isOwnerMode?: boolean;
  onToggleOwnerMode?: () => void;
}

type TabKey =
  | 'PROVIDER_WIZARD'
  | 'DNS_TROUBLESHOOTER'
  | 'DOMEIN_DNS'
  | 'HOSTING_DEPLOY'
  | 'REALTIME_ENGINES'
  | 'PUSH_SERVICE';

type DutchProvider = 'TRANSIP' | 'MIJNDOMEIN' | 'HOSTNET' | 'CPANEL_CLOUD86' | 'STRATO';

export const ProductionDeploymentModal: React.FC<ProductionDeploymentModalProps> = ({
  isOpen,
  onClose,
  showHeaderButton = false,
  onToggleHeaderButton,
  isOwnerMode = false,
  onToggleOwnerMode,
}) => {
  const [activeTab, setActiveTab] = useState<TabKey>('DNS_TROUBLESHOOTER');
  const [selectedProvider, setSelectedProvider] = useState<DutchProvider>('MIJNDOMEIN');
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  if (!isOpen) return null;

  const copyToClipboard = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2500);
  };

  const downloadFile = (filename: string, content: string) => {
    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2.5 sm:p-5 bg-slate-950/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-700 rounded-xl sm:rounded-2xl max-w-4xl w-full p-3.5 sm:p-7 shadow-2xl relative overflow-hidden flex flex-col max-h-[92vh]">
        {/* Glow ambient background */}
        <div className="absolute -top-32 -right-32 w-64 h-64 bg-rose-600/15 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-32 -left-32 w-64 h-64 bg-cyan-600/15 rounded-full blur-3xl pointer-events-none" />

        {/* Modal Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-gradient-to-br from-rose-950 to-amber-950 border border-rose-800 text-rose-300">
              <Globe className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-mono-code font-extrabold bg-emerald-950 text-emerald-300 border border-emerald-800 px-2 py-0.5 rounded">
                  PRODUCTIE HANDLEIDING
                </span>
                <span className="text-xs font-mono-code text-slate-400">
                  bedreigingsmonitor.nl
                </span>
              </div>
              <h2 className="text-base sm:text-lg font-extrabold text-white mt-0.5">
                Online Zetten & DNS Troubleshooter
              </h2>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Visitor Privacy / Admin Mode Banner */}
        <div className="bg-slate-950/80 border border-slate-800/90 rounded-xl px-3.5 py-2.5 my-2.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
          <div className="flex items-start sm:items-center gap-2.5">
            <div className={`p-1.5 rounded-lg shrink-0 ${showHeaderButton ? 'bg-amber-950/80 text-amber-400 border border-amber-800/80' : 'bg-emerald-950/80 text-emerald-400 border border-emerald-800/80'}`}>
              {showHeaderButton ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-slate-200">Zichtbaarheid Setup-knop:</span>
                <span className={`text-[10px] font-mono-code font-bold px-2 py-0.5 rounded ${showHeaderButton ? 'bg-amber-950 text-amber-300 border border-amber-800' : 'bg-emerald-950 text-emerald-300 border border-emerald-800'}`}>
                  {showHeaderButton ? 'KNOP ZICHTBAAR IN HEADER' : 'VERBORGEN VOOR BEZOEKERS (AANBEVOLEN)'}
                </span>
              </div>
              <p className="text-[11px] text-slate-400 mt-0.5">
                {showHeaderButton
                  ? 'De "Online Zetten" knop staat nu aan in de bovenbalk. Bezoekers kunnen dit ook zien.'
                  : 'Bezoekers zien een strak publiek dashboard zonder setup-knoppen. Jij als beheerder opent dit scherm via de link onderin de footer of sneltoets Ctrl+Shift+D.'}
              </p>
            </div>
          </div>
          {onToggleHeaderButton && (
            <button
              onClick={() => onToggleHeaderButton(!showHeaderButton)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold shrink-0 transition-all border cursor-pointer ${
                showHeaderButton
                  ? 'bg-rose-950/60 hover:bg-rose-900/60 text-rose-300 border-rose-800'
                  : 'bg-emerald-950/70 hover:bg-emerald-900/70 text-emerald-300 border-emerald-800'
              }`}
            >
              {showHeaderButton ? 'Verberg knop voor bezoekers' : 'Toon knop in navigatie'}
            </button>
          )}
        </div>

        {/* Socials & Media Privacy Banner */}
        <div className="bg-slate-950/80 border border-slate-800/90 rounded-xl px-3.5 py-2.5 my-2 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
          <div className="flex items-start sm:items-center gap-2.5">
            <div className={`p-1.5 rounded-lg shrink-0 ${isOwnerMode ? 'bg-blue-950/80 text-blue-400 border border-blue-800/80' : 'bg-emerald-950/80 text-emerald-400 border border-emerald-800/80'}`}>
              <Share2 className="w-4 h-4" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <span className="font-bold text-slate-200">Deel op Socials (LinkedIn, X, WhatsApp, Redacties):</span>
                <span className="text-[10px] font-mono-code font-bold px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-800">
                  🔒 VERBORGEN VOOR BEZOEKERS • ALLEEN VOOR JOU
                </span>
              </div>
              <p className="text-[11px] text-slate-400 mt-0.5">
                {isOwnerMode
                  ? 'Eigenaarsmodus is ACTIEF op dit apparaat: jij ziet de "Deel op Socials"-knoppen overal. Externe bezoekers op je domein zien ze NIET.'
                  : 'Bezoekersmodus is ACTIEF: alle "Deel op Socials"-knoppen zijn nu verborgen om te zien wat gewone bezoekers ervaren.'}
              </p>
            </div>
          </div>
          {onToggleOwnerMode && (
            <button
              onClick={onToggleOwnerMode}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold shrink-0 transition-all border cursor-pointer ${
                isOwnerMode
                  ? 'bg-blue-950/70 hover:bg-blue-900/70 text-blue-300 border-blue-800'
                  : 'bg-emerald-950/70 hover:bg-emerald-900/70 text-emerald-300 border-emerald-800'
              }`}
            >
              {isOwnerMode ? 'Test Weergave als Bezoeker' : 'Activeer Eigenaarsmodus (Voor Mij)'}
            </button>
          )}
        </div>

        {/* Tabs Bar */}
        <div className="flex items-center space-x-1.5 overflow-x-auto py-2.5 sm:py-3 border-b border-slate-800/80 scrollbar-none text-xs font-semibold overscroll-x-contain touch-pan-x">
          <button
            onClick={() => setActiveTab('DNS_TROUBLESHOOTER')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl whitespace-nowrap transition-colors ${
              activeTab === 'DNS_TROUBLESHOOTER'
                ? 'bg-rose-600 text-white shadow-sm ring-1 ring-rose-400'
                : 'text-rose-300 bg-rose-950/40 hover:bg-rose-900/60 border border-rose-800/60'
            }`}
          >
            <Wrench className="w-3.5 h-3.5 text-rose-400 animate-pulse" />
            <span>DNS Troubleshooter (194.213.127.130)</span>
          </button>

          <button
            onClick={() => setActiveTab('PROVIDER_WIZARD')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl whitespace-nowrap transition-colors ${
              activeTab === 'PROVIDER_WIZARD'
                ? 'bg-amber-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Zap className="w-3.5 h-3.5 text-amber-300" />
            <span>🇳🇱 Gids per Provider</span>
          </button>

          <button
            onClick={() => setActiveTab('DOMEIN_DNS')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl whitespace-nowrap transition-colors ${
              activeTab === 'DOMEIN_DNS'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Globe className="w-3.5 h-3.5" />
            <span>DNS Records</span>
          </button>

          <button
            onClick={() => setActiveTab('HOSTING_DEPLOY')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl whitespace-nowrap transition-colors ${
              activeTab === 'HOSTING_DEPLOY'
                ? 'bg-slate-800 text-white shadow-sm'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Server className="w-3.5 h-3.5" />
            <span>Hosting & VPS</span>
          </button>

          <button
            onClick={() => setActiveTab('REALTIME_ENGINES')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl whitespace-nowrap transition-colors ${
              activeTab === 'REALTIME_ENGINES'
                ? 'bg-cyan-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Radio className="w-3.5 h-3.5" />
            <span>24/7 Realtime CTI</span>
          </button>

          <button
            onClick={() => setActiveTab('PUSH_SERVICE')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl whitespace-nowrap transition-colors ${
              activeTab === 'PUSH_SERVICE'
                ? 'bg-purple-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Bell className="w-3.5 h-3.5" />
            <span>Web Push & Alerting</span>
          </button>
        </div>

        {/* Modal Scrollable Body */}
        <div className="flex-1 overflow-y-auto py-4 space-y-5 pr-1 scrollbar-thin scrollbar-thumb-slate-800">
          {/* TAB: DNS TROUBLESHOOTER (NEW) */}
          {activeTab === 'DNS_TROUBLESHOOTER' && (
            <DnsTroubleshooter initialDomain="bedreigingsmonitor.nl" />
          )}

          {/* TAB 0: PROVIDER WIZARD */}
          {activeTab === 'PROVIDER_WIZARD' && (
            <div className="space-y-4">
              {/* Intro Banner */}
              <div className="p-4 rounded-xl bg-gradient-to-r from-rose-950/40 via-slate-900 to-amber-950/30 border border-rose-800/60 space-y-2">
                <div className="flex items-center justify-between flex-wrap gap-2">
                  <div className="flex items-center gap-2">
                    <span className="p-1 rounded bg-rose-600 text-white">
                      <Zap className="w-4 h-4" />
                    </span>
                    <h3 className="text-sm font-bold text-white">
                      Snel Online Gaan met bedreigingsmonitor.nl
                    </h3>
                  </div>
                  <span className="text-[11px] font-mono-code bg-emerald-950 text-emerald-300 border border-emerald-800 px-2 py-0.5 rounded font-bold">
                    KLAAR IN 3-5 MINUTEN
                  </span>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">
                  Je hebt het domein <strong>bedreigingsmonitor.nl</strong> al. Kies hieronder bij welke provider je domein staat voor de exacte stappen om de website live te zetten:
                </p>
              </div>

              {/* Provider Selection Buttons */}
              <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 text-xs font-semibold">
                {[
                  { id: 'MIJNDOMEIN', name: 'Mijndomein', sub: 'Mijn Account' },
                  { id: 'TRANSIP', name: 'TransIP', sub: 'Controlepaneel' },
                  { id: 'HOSTNET', name: 'Hostnet', sub: 'Mijn Hostnet' },
                  { id: 'CPANEL_CLOUD86', name: 'Cloud86 / Vimexx', sub: 'cPanel / DirectAdmin' },
                  { id: 'STRATO', name: 'Strato', sub: 'Klantenpaneel' },
                ].map((prov) => (
                  <button
                    key={prov.id}
                    onClick={() => setSelectedProvider(prov.id as DutchProvider)}
                    className={`p-2.5 rounded-xl border text-left transition-all ${
                      selectedProvider === prov.id
                        ? 'bg-rose-950/80 border-rose-500 text-white shadow-md shadow-rose-950/50'
                        : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white hover:border-slate-700'
                    }`}
                  >
                    <div className="font-bold text-xs">{prov.name}</div>
                    <div className="text-[10px] text-slate-500 font-normal">{prov.sub}</div>
                  </button>
                ))}
              </div>

              {/* Special Alert for Mijndomein users */}
              {selectedProvider === 'MIJNDOMEIN' && (
                <div className="p-3.5 rounded-xl bg-gradient-to-r from-rose-950/60 to-slate-900 border border-rose-700/80 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div className="flex items-start gap-2.5 text-xs">
                    <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                    <div>
                      <span className="text-rose-200 font-bold block">
                        Foutmelding "CNAME conflicteert met een ander record" of A-record op 194.213.127.130?
                      </span>
                      <span className="text-slate-300 text-[11px]">
                        Dit ontstaat omdat subdomein <code>www</code> al naar Mijndomein Hosting wijst. Gebruik onze interactieve troubleshooter!
                      </span>
                    </div>
                  </div>
                  <button
                    onClick={() => setActiveTab('DNS_TROUBLESHOOTER')}
                    className="px-3 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs whitespace-nowrap flex items-center justify-center gap-1.5 shadow-sm transition-colors shrink-0"
                  >
                    <Wrench className="w-3.5 h-3.5" />
                    <span>Open DNS Troubleshooter</span>
                  </button>
                </div>
              )}

              {/* Step-by-Step for Selected Provider */}
              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-4">
                <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                  <h4 className="text-sm font-bold text-white flex items-center gap-2">
                    <Globe className="w-4 h-4 text-rose-400" />
                    Handleiding voor {selectedProvider === 'TRANSIP' ? 'TransIP' : selectedProvider === 'MIJNDOMEIN' ? 'Mijndomein' : selectedProvider === 'HOSTNET' ? 'Hostnet' : selectedProvider === 'CPANEL_CLOUD86' ? 'Cloud86 / Vimexx / Antagonist' : 'Strato'}
                  </h4>
                  <span className="text-[11px] font-mono-code text-slate-400">Domein: bedreigingsmonitor.nl</span>
                </div>

                {/* Twee Smaken: Met Hosting vs. Zonder Hosting */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* OPTIE 1: Snelste Route (Doorsturen / DNS) */}
                  <div className="p-3.5 rounded-xl bg-slate-900/80 border border-slate-800 space-y-2.5">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-rose-300 flex items-center gap-1.5">
                        <Zap className="w-3.5 h-3.5 text-rose-400" /> ROUTE A: DE SNELSTE (DOORSTUREN)
                      </span>
                      <span className="text-[10px] bg-emerald-950 text-emerald-300 border border-emerald-800 px-1.5 py-0.5 rounded font-bold">
                        AANBEVOLEN
                      </span>
                    </div>
                    <p className="text-xs text-slate-300 leading-relaxed">
                      Zonder DNS-conflicten en zónder bestanden te hoeven uploaden:
                    </p>
                    <ol className="text-xs text-slate-300 space-y-1.5 list-decimal list-inside leading-relaxed">
                      {selectedProvider === 'MIJNDOMEIN' && (
                        <>
                          <li>Log in op <strong>Mijn Account</strong> bij Mijndomein.</li>
                          <li>Ga naar <strong>Domeinnamen</strong> → klik op <strong>bedreigingsmonitor.nl</strong>.</li>
                          <li>Kies <strong>Doorsturen</strong> (of <em>Domein doorsturen</em>).</li>
                          <li>Vul in: <code>https://ais-pre-ahzjb5b7uvilhl2lxtnytm-84827719818.europe-west2.run.app</code>.</li>
                          <li>Kies voor <strong>301 (Permanent)</strong> en vink aan dat <code>www</code> ook meegaat.</li>
                          <li>Klik op <strong>Opslaan</strong>. Geen CNAME conflict meer!</li>
                        </>
                      )}
                      {selectedProvider === 'TRANSIP' && (
                        <>
                          <li>Log in op <strong>TransIP Controlepaneel</strong>.</li>
                          <li>Klik op <strong>Domein & Hosting</strong> → kies <strong>bedreigingsmonitor.nl</strong>.</li>
                          <li>Scroll naar <strong>Geavanceerd domeinbeheer</strong> (of <strong>Doorsturen</strong>).</li>
                          <li>Stel een 301 redirect in naar je live applicatie URL.</li>
                        </>
                      )}
                      {selectedProvider === 'HOSTNET' && (
                        <>
                          <li>Log in op <strong>Mijn Hostnet</strong>.</li>
                          <li>Ga naar <strong>Diensten</strong> → klik op <strong>bedreigingsmonitor.nl</strong>.</li>
                          <li>Kies <strong>Doorsturen</strong> en voer de applicatie-URL in.</li>
                        </>
                      )}
                      {selectedProvider === 'CPANEL_CLOUD86' && (
                        <>
                          <li>Log in op je <strong>Klantenpaneel (Cloud86 of Vimexx)</strong>.</li>
                          <li>Klik op <strong>Domeinen</strong> → <strong>Doorsturen / Redirects</strong>.</li>
                          <li>Voeg de 301 redirect in voor <code>bedreigingsmonitor.nl</code>.</li>
                        </>
                      )}
                      {selectedProvider === 'STRATO' && (
                        <>
                          <li>Log in op het <strong>Strato Klantenpaneel</strong>.</li>
                          <li>Kies <strong>Domeinen</strong> → <strong>Domeinbeheer</strong>.</li>
                          <li>Kies <strong>Omleiding / Redirect</strong> en vul de URL in.</li>
                        </>
                      )}
                    </ol>
                  </div>

                  {/* OPTIE 2: Webhostingpakket met Bestandsbeheer / FTP */}
                  <div className="p-4 rounded-xl bg-gradient-to-r from-emerald-950/60 via-slate-900 to-slate-900 border border-emerald-700/80 space-y-3">
                    <div className="flex items-center justify-between flex-wrap gap-2">
                      <span className="text-xs font-bold text-emerald-300 flex items-center gap-1.5">
                        <Server className="w-4 h-4 text-emerald-400" /> ROUTE B: JE EIGEN WEBHOSTINGPAKKET (100% Jouw Domein)
                      </span>
                      <span className="text-[10px] bg-emerald-950 text-emerald-300 border border-emerald-800 px-2 py-0.5 rounded font-mono-code font-bold">
                        GEEN CLOUD RUN LINK • BLIJFT OP BEDREIGINGSMONITOR.NL
                      </span>
                    </div>
                    <p className="text-xs text-slate-200 leading-relaxed">
                      Nu je een hostingpakket hebt, kun je de complete Bedreigingsmonitor rechtstreeks op jouw server zetten. 
                      Bezoekers blijven op <strong>https://bedreigingsmonitor.nl</strong> en zien nooit de Google URL!
                    </p>

                    {/* Download Package Multi-Format Card */}
                    <div className="p-4 rounded-xl bg-slate-950/90 border border-emerald-800/60 space-y-3">
                      <div>
                        <div className="font-bold text-white text-xs flex items-center gap-1.5">
                          <Download className="w-4 h-4 text-emerald-400" />
                          <span>Kies jouw gewenste downloadformaat:</span>
                        </div>
                        <div className="text-[11px] text-slate-400 mt-1">
                          Als een ZIP-bestand beschadigd raakt op jouw systeem, kun je nu kiezen voor <strong>TAR.GZ</strong> (speciaal voor Mijn Domein / Linux servers) of direct het <strong>losse index.html bestand</strong> downloaden zonder dat je iets hoeft uit te pakken.
                        </div>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1">
                        {/* Format 1: TAR.GZ */}
                        <a
                          href="/api/download/hosting-tar"
                          download="bedreigingsmonitor-nl-hosting.tar.gz"
                          className="p-3 rounded-xl bg-emerald-950/80 hover:bg-emerald-900 border border-emerald-600/60 text-white font-medium text-xs flex items-center justify-between gap-2 shadow-md transition-all group"
                        >
                          <div className="flex items-center gap-2">
                            <span className="p-1.5 rounded-lg bg-emerald-600/30 text-emerald-400 font-mono text-[10px] font-bold">.TAR.GZ</span>
                            <div>
                              <div className="font-bold text-slate-100 group-hover:text-emerald-300">Linux Tarball (.tar.gz)</div>
                              <div className="text-[10px] text-slate-400">Ideaal voor Mijn Domein File Manager</div>
                            </div>
                          </div>
                          <Download className="w-4 h-4 text-emerald-400 shrink-0" />
                        </a>

                        {/* Format 2: ZIP */}
                        <a
                          href="/api/download/hosting-package"
                          download="bedreigingsmonitor-nl-hosting.zip"
                          className="p-3 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-white font-medium text-xs flex items-center justify-between gap-2 shadow-md transition-all group"
                        >
                          <div className="flex items-center gap-2">
                            <span className="p-1.5 rounded-lg bg-cyan-600/30 text-cyan-400 font-mono text-[10px] font-bold">.ZIP</span>
                            <div>
                              <div className="font-bold text-slate-100 group-hover:text-cyan-300">Standaard ZIP (.zip)</div>
                              <div className="text-[10px] text-slate-400">Hersteld & gevalideerd archief</div>
                            </div>
                          </div>
                          <Download className="w-4 h-4 text-cyan-400 shrink-0" />
                        </a>

                        {/* Format 3: Standalone index.html */}
                        <a
                          href="/api/download/index-html"
                          download="index.html"
                          className="p-3 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-white font-medium text-xs flex items-center justify-between gap-2 shadow-md transition-all group"
                        >
                          <div className="flex items-center gap-2">
                            <span className="p-1.5 rounded-lg bg-blue-600/30 text-blue-400 font-mono text-[10px] font-bold">.HTML</span>
                            <div>
                              <div className="font-bold text-slate-100 group-hover:text-blue-300">Losse index.html</div>
                              <div className="text-[10px] text-slate-400">Zonder ZIP: direct uploaden</div>
                            </div>
                          </div>
                          <Download className="w-4 h-4 text-blue-400 shrink-0" />
                        </a>

                        {/* Format 4: Drop-in Redirect HTML */}
                        <a
                          href="/api/download/redirect-html"
                          download="index.html"
                          className="p-3 rounded-xl bg-amber-950/40 hover:bg-amber-900/60 border border-amber-600/50 text-white font-medium text-xs flex items-center justify-between gap-2 shadow-md transition-all group"
                        >
                          <div className="flex items-center gap-2">
                            <span className="p-1.5 rounded-lg bg-amber-600/30 text-amber-400 font-mono text-[10px] font-bold">1-KLIK</span>
                            <div>
                              <div className="font-bold text-slate-100 group-hover:text-amber-300">Doorstuur-bestand (index.html)</div>
                              <div className="text-[10px] text-slate-400">Plaats in public_html: direct live</div>
                            </div>
                          </div>
                          <Download className="w-4 h-4 text-amber-400 shrink-0" />
                        </a>
                      </div>
                    </div>

                    <ol className="text-xs text-slate-300 space-y-2 list-decimal list-inside leading-relaxed bg-slate-950/60 p-3.5 rounded-xl border border-slate-800">
                      <li><strong>Kies een bestand:</strong> Download hierboven de <strong>.tar.gz</strong> (of het losse <strong>index.html</strong> bestand).</li>
                      <li><strong>Open Bestandsbeheer:</strong> Log in bij Mijn Domein → ga naar je hostingpakket → open <strong>Bestandsbeheer</strong> (File Manager).</li>
                      <li><strong>Map public_html:</strong> Open de map <code>public_html</code>.</li>
                      <li><strong>Uploaden:</strong> Upload het bestand. Als je de <code>.tar.gz</code> hebt geüpload, klik je met de rechtermuisknop op <strong>Uitpakken</strong> (Extract).</li>
                      <li><strong>Klaar!</strong> Bezoek <code>https://bedreigingsmonitor.nl</code>. De monitor draait nu direct!</li>
                    </ol>
                  </div>
                </div>

                {/* htaccess copy helper */}
                <div className="p-3.5 rounded-xl bg-slate-900/90 border border-slate-800 space-y-2">
                  <div className="flex items-center justify-between flex-wrap gap-2">
                    <span className="text-xs font-mono-code text-slate-300 font-bold flex items-center gap-1.5">
                      <Code2 className="w-3.5 h-3.5 text-cyan-400" /> Optioneel: .htaccess voor HTTPS & Schone URL's
                    </span>
                    <button
                      onClick={() =>
                        downloadFile(
                          '.htaccess',
                          `# Bedreigingsmonitor.nl - Apache Webhosting Configuratie
<IfModule mod_rewrite.c>
  RewriteEngine On
  RewriteBase /

  # Forceer HTTPS (automatisch groen slotje)
  RewriteCond %{HTTPS} off
  RewriteRule ^(.*)$ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]

  # Single Page Application routering
  RewriteRule ^index\\.html$ - [L]
  RewriteCond %{REQUEST_FILENAME} !-f
  RewriteCond %{REQUEST_FILENAME} !-d
  RewriteRule . /index.html [L]
</IfModule>
`
                        )
                      }
                      className="text-xs px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 flex items-center gap-1.5 font-bold transition-colors"
                      title="Download los .htaccess bestand (zit al in de zip)"
                    >
                      <Download className="w-3.5 h-3.5 text-cyan-400" /> Download losse .htaccess
                    </button>
                  </div>
                  <pre className="bg-slate-950 p-2.5 rounded-lg border border-slate-800 font-mono-code text-[11px] text-cyan-300 overflow-x-auto">{`<IfModule mod_rewrite.c>
  RewriteEngine On
  RewriteBase /
  RewriteCond %{HTTPS} off
  RewriteRule ^(.*)$ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]
  RewriteRule ^index\\.html$ - [L]
  RewriteCond %{REQUEST_FILENAME} !-f
  RewriteCond %{REQUEST_FILENAME} !-d
  RewriteRule . /index.html [L]
</IfModule>`}</pre>
                </div>
              </div>
            </div>
          )}

          {/* TAB 1: DOMEIN & DNS INSTELLINGEN */}
          {activeTab === 'DOMEIN_DNS' && (
            <div className="space-y-4">
              <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800 space-y-2">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-bold text-white flex items-center gap-2">
                    <Globe className="w-4 h-4 text-blue-400" />
                    Officiële DNS Records voor bedreigingsmonitor.nl
                  </h3>
                  <button
                    onClick={() => setActiveTab('DNS_TROUBLESHOOTER')}
                    className="px-2.5 py-1 rounded bg-rose-600 hover:bg-rose-500 text-white text-xs font-semibold flex items-center gap-1 shadow-sm"
                  >
                    <Wrench className="w-3.5 h-3.5" />
                    <span>Los Conflict op</span>
                  </button>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">
                  Hieronder vind je de referentie-instellingen voor de DNS-zone. Let op: voeg geen CNAME voor <code>www</code> toe als er al een A-record voor <code>www</code> aanwezig is!
                </p>
              </div>

              {/* DNS Table */}
              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-3">
                <table className="w-full text-left text-xs font-mono-code">
                  <thead>
                    <tr className="border-b border-slate-800 text-slate-400">
                      <th className="py-2.5 px-3">Type</th>
                      <th className="py-2.5 px-3">Naam</th>
                      <th className="py-2.5 px-3">Waarde / Inhoud</th>
                      <th className="py-2.5 px-3">TTL</th>
                      <th className="py-2.5 px-3 text-right">Kopieer</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/80 text-slate-200">
                    <tr>
                      <td className="py-2.5 px-3 text-rose-400 font-bold">A</td>
                      <td className="py-2.5 px-3">@</td>
                      <td className="py-2.5 px-3 text-slate-300">194.213.127.130 (Mijndomein Server 170)</td>
                      <td className="py-2.5 px-3 text-slate-500">3600</td>
                      <td className="py-2.5 px-3 text-right">
                        <button
                          onClick={() => copyToClipboard('194.213.127.130', 'dns-a')}
                          className="text-slate-400 hover:text-white"
                        >
                          {copiedKey === 'dns-a' ? <Check className="w-3.5 h-3.5 text-emerald-400 inline" /> : <Copy className="w-3.5 h-3.5 inline" />}
                        </button>
                      </td>
                    </tr>
                    <tr>
                      <td className="py-2.5 px-3 text-cyan-400 font-bold">Doorsturen</td>
                      <td className="py-2.5 px-3">*</td>
                      <td className="py-2.5 px-3 text-slate-300 truncate max-w-xs">https://ais-pre-ahzjb5b7uvilhl2lxtnytm-84827719818.europe-west2.run.app</td>
                      <td className="py-2.5 px-3 text-slate-500">301</td>
                      <td className="py-2.5 px-3 text-right">
                        <button
                          onClick={() => copyToClipboard('https://ais-pre-ahzjb5b7uvilhl2lxtnytm-84827719818.europe-west2.run.app', 'dns-fwd')}
                          className="text-slate-400 hover:text-white"
                        >
                          {copiedKey === 'dns-fwd' ? <Check className="w-3.5 h-3.5 text-emerald-400 inline" /> : <Copy className="w-3.5 h-3.5 inline" />}
                        </button>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>

              {/* Cloudflare tip */}
              <div className="p-4 rounded-xl bg-gradient-to-r from-orange-950/40 to-slate-950 border border-orange-800/60 flex items-start gap-3">
                <ShieldCheck className="w-5 h-5 text-orange-400 shrink-0 mt-0.5" />
                <div className="text-xs space-y-1">
                  <strong className="text-white font-bold block">Aanrader: Koppel Cloudflare DNS (Gratis)</strong>
                  <p className="text-slate-300 leading-relaxed">
                    Als je je domein nameservers omzet naar Cloudflare, krijg je automatisch gratis <strong>DDoS-bescherming</strong>, automatische <strong>SSL (HTTPS)</strong> en Web Application Firewall (WAF). Hierdoor is <em>bedreigingsmonitor.nl</em> zelf beschermd tegen vergeldings-DDoS aanvallen van pro-Kremlin hackersgroepen zoals NoName057(16).
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: HOSTING & CLOUD DEPLOY */}
          {activeTab === 'HOSTING_DEPLOY' && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Method 1: Google Cloud Run (Huidige Stack) */}
                <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-mono-code font-bold text-rose-400 flex items-center gap-1.5">
                      <Cpu className="w-4 h-4" /> METHODE A: GOOGLE CLOUD RUN
                    </span>
                    <span className="text-[10px] bg-rose-950 text-rose-300 border border-rose-800 px-1.5 py-0.2 rounded font-bold">
                      AANBEVOLEN
                    </span>
                  </div>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    Deze app draait momenteel al op <strong>Google Cloud Run</strong> in Europa (europe-west2).
                  </p>
                  <ol className="text-xs text-slate-300 space-y-1.5 list-decimal list-inside">
                    <li>Ga naar de <strong>Google Cloud Console → Cloud Run</strong>.</li>
                    <li>Selecteer de service van Bedreigingsmonitor.nl.</li>
                    <li>Klik op <strong>Custom Domains</strong> → <strong>Add Mapping</strong>.</li>
                    <li>Vul <code>bedreigingsmonitor.nl</code> in. Google geeft je direct de exacte CNAME- en A-records om in te voeren.</li>
                    <li>Google verzorgt automatisch een gratis beheerd SSL-certificaat!</li>
                  </ol>
                </div>

                {/* Method 2: VPS met Docker / Node.js & Nginx */}
                <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-mono-code font-bold text-amber-400 flex items-center gap-1.5">
                      <Terminal className="w-4 h-4" /> METHODE B: EIGEN VPS (TRANSIP / HETZNER)
                    </span>
                    <span className="text-[10px] bg-slate-900 text-slate-300 border border-slate-700 px-1.5 py-0.2 rounded font-mono-code">
                      VOLLEDIGE CONTROLE
                    </span>
                  </div>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    Draai de app op een eigen Linux VPS (Ubuntu 24.04 LTS) met Node 22 en PM2:
                  </p>
                  <div className="bg-slate-900 p-2.5 rounded-lg border border-slate-800 text-[11px] font-mono-code text-slate-300 space-y-1">
                    <div>git clone &lt;jouw-repo&gt; && cd app</div>
                    <div>npm install && npm run build</div>
                    <div>pm2 start server.ts --name "bedreigingsmonitor"</div>
                    <div>certbot --nginx -d bedreigingsmonitor.nl</div>
                  </div>
                </div>
              </div>

              {/* Docker container guide */}
              <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800 space-y-2">
                <h4 className="text-xs font-bold text-white flex items-center gap-2">
                  <Layers className="w-4 h-4 text-cyan-400" />
                  Eén-commando Dockerfile voor Productie
                </h4>
                <p className="text-xs text-slate-300">
                  De app kan als lichte Docker container verpakt worden en gedeployed worden op elke Docker host:
                </p>
                <div className="bg-slate-900 p-3 rounded-lg border border-slate-800 font-mono-code text-[11px] text-cyan-300 overflow-x-auto">
                  docker build -t bedreigingsmonitor . && docker run -d -p 3000:3000 --name soc-monitor bedreigingsmonitor
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: 24/7 REALTIME ENGINES */}
          {activeTab === 'REALTIME_ENGINES' && (
            <div className="space-y-4">
              <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800 space-y-2">
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <Radio className="w-4 h-4 text-cyan-400" />
                  Hoe zorg je dat alle cyberaanvallen 24/7 realtime binnenkomen?
                </h3>
                <p className="text-xs text-slate-300 leading-relaxed">
                  In een professionele SOC-omgeving haalt de backend data op uit live cyber-inlichtingenbronnen en pusht deze zonder vertraging naar bezoekers:
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                {/* Source 1 */}
                <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-1.5">
                  <div className="font-bold text-white flex items-center gap-2">
                    <span className="p-1 rounded bg-rose-950 text-rose-400 border border-rose-800">1</span>
                    Dark Web .onion Leak Scrapers
                  </div>
                  <p className="text-slate-300 text-[11px] leading-relaxed">
                    Een achtergrondworker in <code>server.ts</code> draait met een lokale Tor SOCKS5 proxy (<code>127.0.0.1:9050</code>) en pollt elke 3 minuten openbare Tor-lekblogs (LockBit, Akira, Black Basta, Qilin) voor nieuwe slachtoffers in de .NL zone.
                  </p>
                </div>

                {/* Source 2 */}
                <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-1.5">
                  <div className="font-bold text-white flex items-center gap-2">
                    <span className="p-1 rounded bg-amber-950 text-amber-400 border border-amber-800">2</span>
                    NCSC-NL & CSIRT Telemetrie Feeds
                  </div>
                  <p className="text-slate-300 text-[11px] leading-relaxed">
                    Koppel de officiële <strong>NCSC-NL RSS / Advisories API</strong> en <strong>CIRCL MISP / OpenCTI</strong> instanties om gevalideerde beveiligingsadviezen en vitale infrastructuur indicatoren (IoCs) direct in de database op te slaan.
                  </p>
                </div>

                {/* Source 3 */}
                <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-1.5">
                  <div className="font-bold text-white flex items-center gap-2">
                    <span className="p-1 rounded bg-purple-950 text-purple-400 border border-purple-800">3</span>
                    Telegram OSINT & Hacktivist Listener
                  </div>
                  <p className="text-slate-300 text-[11px] leading-relaxed">
                    Gebruik een Telegram client worker (via TDLib / Telethon) die pro-Kremlin kanalen (NoName057, CyberArmyofRussia) monitort op doelwitten in Nederland (zoals Albert Heijn, DigiD, Schiphol).
                  </p>
                </div>

                {/* Source 4 */}
                <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-1.5">
                  <div className="font-bold text-white flex items-center gap-2">
                    <span className="p-1 rounded bg-emerald-950 text-emerald-400 border border-emerald-800">4</span>
                    WebSockets & Server-Sent Events (SSE)
                  </div>
                  <p className="text-slate-300 text-[11px] leading-relaxed">
                    Zodra de backend een nieuw incident detecteert, stuurt <code>server.ts</code> via WebSockets direct een broadcast naar alle actieve bezoekers. Pagina's hoeven nooit te herladen!
                  </p>
                </div>
              </div>

              {/* Code snippet example */}
              <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
                <span className="text-[11px] font-mono-code text-slate-400 block font-bold">
                  VOORBEELD SERVER CRON INGESTION IN SERVER.TS:
                </span>
                <div className="bg-slate-900 p-2.5 rounded-lg border border-slate-800 font-mono-code text-[11px] text-amber-300 overflow-x-auto">
                  {`// server.ts achtergrond job (elke 60 sec)
setInterval(async () => {
  const newThreats = await fetchLiveThreatFeeds();
  if (newThreats.length > 0) {
    broadcastToAllClients(newThreats); // Realtime WebSocket Push
    triggerTier1PushNotification(newThreats[0]);
  }
}, 60000);`}
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: PUSH & SERVICE WORKER */}
          {activeTab === 'PUSH_SERVICE' && (
            <div className="space-y-4">
              <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800 space-y-2">
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <Bell className="w-4 h-4 text-purple-400" />
                  Pushmeldingen op Achtergrond (Web Push Protocol)
                </h3>
                <p className="text-xs text-slate-300 leading-relaxed">
                  Om te zorgen dat journalisten, CISO's en beveiligingsteams pushberichten op hun telefoon of Mac/PC ontvangen <em>zelfs als de website gesloten is</em>:
                </p>
              </div>

              <div className="space-y-3 text-xs">
                <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-1.5">
                  <strong className="text-white block font-bold">1. VAPID Keys Genereren</strong>
                  <p className="text-slate-300">
                    Genereer een publieke en private VAPID-sleutelset op je server met de <code>web-push</code> package:
                  </p>
                  <div className="bg-slate-900 p-2 rounded-lg font-mono-code text-[11px] text-purple-300">
                    npx web-push generate-vapid-keys
                  </div>
                </div>

                <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-1.5">
                  <strong className="text-white block font-bold">2. Service Worker Registratie</strong>
                  <p className="text-slate-300">
                    De browser van de bezoeker registreert een service worker die luistert naar inkomende pushberichten van Google Cloud Messaging / Apple Push Notification Service.
                  </p>
                </div>

                <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-1.5">
                  <strong className="text-white block font-bold">3. Noodalarm voor Tier 1 NL Vitale Dreigingen</strong>
                  <p className="text-slate-300">
                    Bij incidenten zoals de Albert Heijn supply chain aanval of TenneT energienetwerk verstoring wordt automatisch het Tier 1 akoestische alarmsignaal afgespeeld en een prioriteitsbericht afgeleverd.
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="pt-4 border-t border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
          <div className="text-slate-400 flex items-center gap-1.5 font-mono-code">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>Klaar voor productie op <strong>bedreigingsmonitor.nl</strong></span>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => copyToClipboard('https://bedreigingsmonitor.nl', 'url')}
              className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-semibold transition-colors flex items-center gap-1.5"
            >
              {copiedKey === 'url' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>Kopieer Domeinnaam</span>
            </button>
            <button
              onClick={onClose}
              className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-semibold transition-colors"
            >
              Sluiten
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
