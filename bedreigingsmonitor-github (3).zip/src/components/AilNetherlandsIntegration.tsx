import React, { useState, useMemo } from 'react';
import {
  ShieldAlert,
  Search,
  FileCode,
  Download,
  CheckCircle2,
  AlertTriangle,
  Copy,
  Check,
  Terminal,
  Database,
  Globe,
  Lock,
  Cpu,
  Layers,
  ExternalLink,
  Sparkles,
  Play,
  RefreshCw,
  Server,
} from 'lucide-react';

interface DetectedEntity {
  id: string;
  type:
    | 'NL_BSN_ELFPROEF'
    | 'NL_IBAN_BANK'
    | 'NL_OVERHEID_EMAIL'
    | 'NL_VITAAL_EMAIL'
    | 'SESSION_COOKIE_TOKEN'
    | 'API_SECRET_KEY'
    | 'TOR_ONION_ENDPOINT'
    | 'CVE_EXPLOIT_MARKER';
  label: string;
  value: string;
  maskedValue: string;
  validationDetail: string;
  severity: 'KRITIEK' | 'HOOG' | 'MIDDEL';
  targetOrgOrSector: string;
  mispAttributeType: string;
}

interface YaraRuleMatch {
  ruleName: string;
  description: string;
  tlp: 'TLP:RED' | 'TLP:AMBER+STRICT' | 'TLP:AMBER';
  targetRecipient: string;
  matchedIndicatorsCount: number;
}

interface SamplePasteScenario {
  id: string;
  title: string;
  badge: string;
  sourceChannel: string;
  description: string;
  sampleText: string;
}

const SAMPLE_NL_SCENARIOS: SamplePasteScenario[] = [
  {
    id: 'laundry-bear-politie',
    title: 'Scenario 1: Overheid & Politie Infostealer + Session Cookie Dump (Laundry Bear)',
    badge: 'AIVD / NCSC-NL CASE',
    sourceChannel: 'AIL Feeder: Infostealer Log / Telegram Stream',
    description:
      'Simuleert een onderschept RedLine/Lumma infostealer-log met geëxfiltreerde Entra ID / GalToken sessiecookies en werkgerelateerde e-mailadressen van de Politie en Rijksoverheid.',
    sampleText: `[AIL-FEEDER-TELEGRAM] Intercepted Stealer Log #NL-88412 (Host: WKS-POL-EENHEID-09)
Target-Country: NL | Stealer: LummaC2 v4.8 | Timestamp: 2026-04-20T09:14:22Z

[CREDENTIALS & GAL ADDRESS BOOK]
user_principal: j.vanderberg@politie.nl
backup_contact: ciso-loket@rijksoverheid.nl
keten_partner: meldkamer-noordzee@defensie.nl
dienst_bsn_ref: 111222333

[CAPTURED SESSION COOKIES - PASS-THE-COOKIE]
Domain: login.microsoftonline.com
Cookie: ESTSAUTHPERSISTENT=0.AX8A9zK_LaundryBear_SessionToken_PolitieNL_99481aBcDeFgHiJkLmNoPqRsTuVwXyZ; HttpOnly; Secure
Cookie:BreezeSessionCookie=GalToken_Exfil_Politie_2026_8841a9f0c2e4

[NETWORK & C2]
Exfil-Onion: http://laundryb7x9k2m4p8q1w3e5r7t9y2u4i6o8p0a2s4d6f8g0h2j4k6l8.onion/upload.php
Exploit-Ref: CVE-2026-109618`,
  },
  {
    id: 'zcert-zorg-bsn-iban',
    title: 'Scenario 2: Zorgsector (Z-CERT) Patiënten- & Financiële Dump (BSN 11-proef + IBAN)',
    badge: 'Z-CERT / AP MELDPLICHT',
    sourceChannel: 'AIL Feeder: Pystemon Paste Scraper',
    description:
      'Simuleert een gelekte CSV/SQL-dump uit de Nederlandse zorgketen met Burgerservicenummers (getoetst op de 11-proef) en Nederlandse bankrekeningnummers (ING, Rabobank, ABN AMRO).',
    sampleText: `-- SQL DUMP EXFILTRATION: ZORGPORTAAL REGIO RANDSTAD (TLP:RED)
-- Source: pystemon://paste.ee/p/x9K2mL
INSERT INTO patient_declarations (patient_email, bsn_nummer, iban_rekening, zorgverzekeraar_api) VALUES
('p.janssen@lumc.nl', '111222333', 'NL91ABNA0417164300', 'sk_live_99a8b7c6d5e4f3g2h1j0k9l8m7n6'),
('m.de.vries@erasmusmc.nl', '123456782', 'NL20INGB0001234567', 'ghp_77x88y99z00a11b22c33d44e55f66g77h88i'),
('k.bakker@z-cert.nl', '987654321', 'NL44RABO0123456789', 'AIzaSyD-99887766554433221100aabbccddeeff');
-- Note: 987654321 fails 11-proef (false positive test), while 111222333 and 123456782 pass!`,
  },
  {
    id: 'brainport-vital-infra',
    title: 'Scenario 3: Vitale Infra (Brainport / Haven Rotterdam / PHP2Shell .env Leak)',
    badge: 'DIVD / VITALE INFRA',
    sourceChannel: 'AIL Crawler: Lacus Tor .onion & GitHub Gist',
    description:
      'Simuleert een onderschept .env configuratiebestand van een Nederlandse toeleverancier na misbruik van het PHP2Shell-lek (CVE-2026-109618) met OT/SCADA- en cloud-sleutels.',
    sampleText: `# LEAKED PRODUCTION .ENV - NL SUPPLY CHAIN NODE (EINDHOVEN / ROTTERDAM)
APP_ENV=production
VULN_VECTOR=CVE-2026-109618 (PHP2Shell RCE)
ADMIN_CONTACT=ot-security@portofrotterdam.com
ENGINEERING_LEAD=litho-ops@asml.com
GRID_TELEMETRY_CONTACT=scada-noc@tennet.eu

# FINANCIAL & CLEARING
TREASURY_IBAN=NL02ABNA0123456789
AWS_ACCESS_KEY_ID=AKIAIOSFODNN7EXAMPLE
SESSION_JWT=eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJOTF9WSVRBTF9TQ0FEQV9hZG1pbiIsImlzcyI6Im5jc2MubmwifQ
RANSOMWARE_NEGOTIATION_ONION=http://clop7x8m2n4b6v8c0x2z4a6s8d0f2g4h6j8k0l2q4w6e8r0t2y4u6i.onion`,
  },
];

/**
 * Officiële Nederlandse Elfproef (11-proef) voor een 9-cijferig Burgerservicenummer (BSN)
 */
function isValidDutchBSN(candidate: string): boolean {
  const clean = candidate.replace(/\D/g, '');
  if (clean.length !== 9) return false;
  if (/^0+$/.test(clean)) return false;

  const digits = clean.split('').map(Number);
  const sum =
    9 * digits[0] +
    8 * digits[1] +
    7 * digits[2] +
    6 * digits[3] +
    5 * digits[4] +
    4 * digits[5] +
    3 * digits[6] +
    2 * digits[7] -
    1 * digits[8];

  return sum > 0 && sum % 11 === 0;
}

function maskSensitiveValue(val: string): string {
  if (val.length <= 8) return val;
  return `${val.slice(0, 4)}••••${val.slice(-4)}`;
}

export const AilNetherlandsIntegration: React.FC = () => {
  const [selectedScenarioId, setSelectedScenarioId] = useState<string>(SAMPLE_NL_SCENARIOS[0].id);
  const [inputText, setInputText] = useState<string>(SAMPLE_NL_SCENARIOS[0].sampleText);
  const [copiedConfig, setCopiedConfig] = useState<string | null>(null);
  const [showUnmasked, setShowUnmasked] = useState<boolean>(false);
  const [activeSubView, setActiveSubView] = useState<
    'SANDBOX_ANALYZER' | 'ARCHITECTUUR_NL' | 'YARA_EN_CONFIG'
  >('SANDBOX_ANALYZER');

  const handleLoadScenario = (scenario: SamplePasteScenario) => {
    setSelectedScenarioId(scenario.id);
    setInputText(scenario.sampleText);
  };

  // Real-time AIL-NL Engine Analyse in de browser
  const analysisResult = useMemo(() => {
    const entities: DetectedEntity[] = [];
    const seen = new Set<string>();

    const addEntity = (entity: Omit<DetectedEntity, 'id'>) => {
      const key = `${entity.type}:${entity.value}`;
      if (seen.has(key)) return;
      seen.add(key);
      entities.push({
        ...entity,
        id: `ent-${entities.length + 1}`,
      });
    };

    // 1. Nederlandse BSN (9 cijfers + 11-proef)
    const bsnMatches = inputText.match(/\b\d{9}\b/g) || [];
    bsnMatches.forEach((candidate) => {
      if (isValidDutchBSN(candidate)) {
        addEntity({
          type: 'NL_BSN_ELFPROEF',
          label: 'Nederlands BSN (11-proef Geverifieerd)',
          value: candidate,
          maskedValue: `${candidate.slice(0, 2)}•••••${candidate.slice(-2)}`,
          validationDetail: 'Wiskundige 11-proef (Elfproef) = GELDIG (AVG Art. 33 / AP Meldplicht)',
          severity: 'KRITIEK',
          targetOrgOrSector: 'Autoriteit Persoonsgegevens (AP) / Z-CERT / RVIG',
          mispAttributeType: 'person-national-id',
        });
      }
    });

    // 2. Nederlandse IBAN rekeningen (NLkk BANK 10 cijfers)
    const ibanMatches =
      inputText.match(/\bNL\d{2}\s?[A-Z]{4}\s?\d{4}\s?\d{4}\s?\d{2}\b/gi) || [];
    ibanMatches.forEach((rawIban) => {
      const normalized = rawIban.replace(/\s+/g, '').toUpperCase();
      const bankCode = normalized.slice(4, 8);
      const bankMap: Record<string, string> = {
        ABNA: 'ABN AMRO Bank',
        INGB: 'ING Bank Nederland',
        RABO: 'Rabobank',
        SNSB: 'SNS / de Volksbank',
        TRIO: 'Triodos Bank',
        BUNQ: 'bunq Bank',
        KNAB: 'Knab',
        BNGH: 'BNG Bank (Overheid/Gemeenten)',
      };
      const bankName = bankMap[bankCode] || `NL Bank (${bankCode})`;
      addEntity({
        type: 'NL_IBAN_BANK',
        label: `Nederlandse IBAN (${bankName})`,
        value: normalized,
        maskedValue: `${normalized.slice(0, 8)}••••••${normalized.slice(-4)}`,
        validationDetail: `NL-IBAN Structuur + BIC (${bankCode}) geverifieerd`,
        severity: 'HOOG',
        targetOrgOrSector: `Financiële Sector (FI-ISAC / ${bankName})`,
        mispAttributeType: 'iban',
      });
    });

    // 3. E-mailadressen (.nl, Rijksoverheid, Politie, Defensie, Vitale Infra)
    const emailMatches =
      inputText.match(/\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b/g) || [];
    emailMatches.forEach((email) => {
      const lower = email.toLowerCase();
      const isGovOrPolice =
        lower.endsWith('@politie.nl') ||
        lower.endsWith('@rijksoverheid.nl') ||
        lower.endsWith('@defensie.nl') ||
        lower.endsWith('@minbuza.nl') ||
        lower.endsWith('@ncsc.nl') ||
        lower.endsWith('@rechtspraak.nl');

      if (isGovOrPolice) {
        addEntity({
          type: 'NL_OVERHEID_EMAIL',
          label: 'Gelekte Overheid / Politie / Defensie Account',
          value: lower,
          maskedValue: lower,
          validationDetail: 'Kritiek Nederlands Overheidsdomein (.nl Rijksoverheid/Politie)',
          severity: 'KRITIEK',
          targetOrgOrSector: 'NCSC-NL / AIVD / MIVD / PDC Politie',
          mispAttributeType: 'email-dst',
        });
      } else if (
        lower.endsWith('.nl') ||
        lower.endsWith('@asml.com') ||
        lower.endsWith('@portofrotterdam.com') ||
        lower.endsWith('@tennet.eu') ||
        lower.endsWith('@kpn.com') ||
        lower.endsWith('@philips.com')
      ) {
        addEntity({
          type: 'NL_VITAAL_EMAIL',
          label: 'Nederlands .NL / Vitale Sector E-mailadres',
          value: lower,
          maskedValue: lower,
          validationDetail: 'Gekoppeld aan Nederlandse NIS2 / Vitale Keten',
          severity: 'HOOG',
          targetOrgOrSector: 'DIVD CSIRT / Z-CERT / NCSC-NL',
          mispAttributeType: 'email-src',
        });
      }
    });

    // 4. Pass-the-Cookie / Entra ID / Session Tokens
    const cookiePatterns =
      inputText.match(
        /\b(ESTSAUTHPERSISTENT|BreezeSessionCookie|SESSION_JWT|GalToken)[=:]\s*([^\s;]+)/gi
      ) || [];
    cookiePatterns.forEach((match) => {
      addEntity({
        type: 'SESSION_COOKIE_TOKEN',
        label: 'Gelekte Sessiecookie / Pass-the-Cookie Token (MFA-Bypass)',
        value: match,
        maskedValue: maskSensitiveValue(match),
        validationDetail:
          'Actieve sessietoken geeft aanvaller toegang zonder wachtwoord/MFA (zoals bij Laundry Bear)',
        severity: 'KRITIEK',
        targetOrgOrSector: 'NCSC-NL / SOC Directe Token-Revocatie Vereist',
        mispAttributeType: 'cookie',
      });
    });

    // 5. API Keys & Cloud Secrets
    const secretMatches =
      inputText.match(
        /\b(AKIA[0-9A-Z]{16}|ghp_[A-Za-z0-9]{30,}|sk_live_[A-Za-z0-9]{20,}|AIza[0-9A-Za-z-_]{30,})\b/g
      ) || [];
    secretMatches.forEach((sec) => {
      addEntity({
        type: 'API_SECRET_KEY',
        label: 'Gelekte Cloud / API Private Key',
        value: sec,
        maskedValue: maskSensitiveValue(sec),
        validationDetail: 'Hoog-entropie API-sleutel (AWS / GitHub PAT / Stripe / Google Cloud)',
        severity: 'KRITIEK',
        targetOrgOrSector: 'DIVD CSIRT / DevSecOps Key Rotation',
        mispAttributeType: 'text',
      });
    });

    // 6. Tor .onion URLs
    const onionMatches =
      inputText.match(/https?:\/\/[a-z2-7]{16,56}\.onion[^\s"']*/gi) || [];
    onionMatches.forEach((onion) => {
      addEntity({
        type: 'TOR_ONION_ENDPOINT',
        label: 'Tor .Onion Exfiltratie / Ransomware Endpoint',
        value: onion,
        maskedValue: onion,
        validationDetail: 'Gedetecteerd door AIL Lacus Tor-module',
        severity: 'HOOG',
        targetOrgOrSector: 'Team High Tech Crime (THTC) / NCSC-NL',
        mispAttributeType: 'url',
      });
    });

    // 7. CVE Referenties
    const cveMatches = inputText.match(/\bCVE-\d{4}-\d{4,7}\b/gi) || [];
    cveMatches.forEach((cve) => {
      addEntity({
        type: 'CVE_EXPLOIT_MARKER',
        label: 'Actief Misbruikte CVE-Kwetsbaarheid in Dump',
        value: cve.toUpperCase(),
        maskedValue: cve.toUpperCase(),
        validationDetail: 'Gekoppeld aan NCSC-NL / CISA KEV Waarschuwing',
        severity: 'KRITIEK',
        targetOrgOrSector: 'NCSC-NL / DIVD CSIRT',
        mispAttributeType: 'vulnerability',
      });
    });

    // YARA Rules Evaluatie
    const yaraMatches: YaraRuleMatch[] = [];
    const overheidHits = entities.filter(
      (e) => e.type === 'NL_OVERHEID_EMAIL' || e.type === 'SESSION_COOKIE_TOKEN'
    ).length;
    if (overheidHits > 0) {
      yaraMatches.push({
        ruleName: 'rule NL_Overheid_Politie_Session_Exfil_2026',
        description:
          'Detecteert gelekte Rijksoverheid/Politie/Defensie accounts in combinatie met Pass-the-Cookie / Entra ID tokens (Laundry Bear TTP).',
        tlp: 'TLP:RED',
        targetRecipient: 'NCSC-NL & AIVD / PDC Politie CSIRT',
        matchedIndicatorsCount: overheidHits,
      });
    }

    const bsnOrIbanHits = entities.filter(
      (e) => e.type === 'NL_BSN_ELFPROEF' || e.type === 'NL_IBAN_BANK'
    ).length;
    if (bsnOrIbanHits > 0) {
      yaraMatches.push({
        ruleName: 'rule NL_BSN_Elfproef_En_IBAN_PII_Leak',
        description:
          'Detecteert gevalideerde Nederlandse Burgerservicenummers (11-proef) en Nederlandse IBAN-bankrekeningen in pastes of SQL-dumps.',
        tlp: 'TLP:AMBER+STRICT',
        targetRecipient: 'Autoriteit Persoonsgegevens (AP), Z-CERT & FI-ISAC',
        matchedIndicatorsCount: bsnOrIbanHits,
      });
    }

    const vitalOrSecretHits = entities.filter(
      (e) =>
        e.type === 'NL_VITAAL_EMAIL' ||
        e.type === 'API_SECRET_KEY' ||
        e.type === 'CVE_EXPLOIT_MARKER'
    ).length;
    if (vitalOrSecretHits > 0) {
      yaraMatches.push({
        ruleName: 'rule NL_Vital_Infra_NIS2_SupplyChain_Secrets',
        description:
          'Detecteert gelekte .env configuraties, API-keys en vitale infrastructuur contactpunten (ASML, Haven Rotterdam, TenneT, PHP2Shell).',
        tlp: 'TLP:AMBER',
        targetRecipient: 'DIVD CSIRT & Digital Trust Center (DTC)',
        matchedIndicatorsCount: vitalOrSecretHits,
      });
    }

    const riskScore = Math.min(
      100,
      entities.reduce(
        (acc, item) => acc + (item.severity === 'KRITIEK' ? 28 : item.severity === 'HOOG' ? 16 : 8),
        0
      )
    );

    return {
      entities,
      yaraMatches,
      riskScore,
    };
  }, [inputText]);

  // Exporteer gevonden resultaten als officieel MISP Event JSON-bestand (CIRCL / NCSC-NL standaard)
  const handleDownloadMispJson = () => {
    const mispEvent = {
      Event: {
        info: `[AIL-NL Bedreigingsmonitor.nl] Gedetecteerd Nederlands Datalek / Paste Incident (${analysisResult.entities.length} IoC's)`,
        date: new Date().toISOString().split('T')[0],
        threat_level_id: analysisResult.riskScore >= 70 ? '1' : '2',
        analysis: '2',
        distribution: '1',
        Orgc: {
          name: 'Bedreigingsmonitor.nl — AIL-NL Node',
          uuid: '5b9e8a12-4c3d-4f1a-9b2e-8d7c6b5a4f3e',
        },
        Tag: [
          { name: 'tlp:amber+strict' },
          { name: 'ail-project:leak-detection="netherlands"' },
          { name: 'ncsc-nl:vital-infrastructure' },
          { name: 'nis2:incident-notification' },
        ],
        Attribute: analysisResult.entities.map((ent, idx) => ({
          uuid: `attr-nl-ail-${Date.now()}-${idx}`,
          type: ent.mispAttributeType,
          category:
            ent.mispAttributeType === 'cookie' || ent.mispAttributeType === 'url'
              ? 'Network activity'
              : 'Targeting data',
          to_ids: ent.severity === 'KRITIEK',
          value: ent.value,
          comment: `${ent.label} — ${ent.validationDetail} (Bestemd voor: ${ent.targetOrgOrSector})`,
        })),
      },
    };

    const blob = new Blob([JSON.stringify(mispEvent, null, 2)], {
      type: 'application/json',
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `AIL-NL-MISP-Event-${new Date().toISOString().slice(0, 10)}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleCopyText = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedConfig(id);
    setTimeout(() => setCopiedConfig(null), 2500);
  };

  const nlYaraRulesSnippet = `// AIL-Project (CIRCL) — Nederlandse YARA Retro-Hunt Bundel (etc/yara/nl_vital_leaks.yar)
rule NL_Overheid_En_Politie_Credential_Of_Cookie_Leak {
    meta:
        author = "Bedreigingsmonitor.nl / CSIRT-NL Integratie"
        description = "Detecteert gelekte Rijksoverheid/Politie/Defensie credentials & Pass-the-Cookie tokens"
        tlp = "TLP:RED"
        misp_galaxy = "Laundry Bear / Void Blizzard / Infostealers"
    strings:
        $gov1 = "@politie.nl" nocase
        $gov2 = "@rijksoverheid.nl" nocase
        $gov3 = "@defensie.nl" nocase
        $gov4 = "@minbuza.nl" nocase
        $gov5 = "@rechtspraak.nl" nocase
        $cookie1 = "ESTSAUTHPERSISTENT=" nocase
        $cookie2 = "BreezeSessionCookie=" nocase
        $cookie3 = "GalToken" nocase
    condition:
        any of ($gov*) and (any of ($cookie*) or filesize < 5MB)
}

rule NL_Vitale_Infrastructuur_NIS2_SupplyChain {
    meta:
        author = "Bedreigingsmonitor.nl"
        description = "Detecteert gelekte .env secrets en gegevens van Nederlandse NIS2 vitale aanbieders"
        tlp = "TLP:AMBER"
    strings:
        $v1 = "@portofrotterdam.com" nocase
        $v2 = "@tennet.eu" nocase
        $v3 = "@asml.com" nocase
        $v4 = "@schiphol.nl" nocase
        $v5 = "@kpn.com" nocase
        $iban_nl = /NL[0-9]{2}(ABNA|INGB|RABO|BNGH)[0-9]{10}/
    condition:
        any of ($v*) or #iban_nl > 3
}`;

  return (
    <div className="space-y-6">
      {/* Top Hero Banner: AIL-Project (CIRCL) gericht op Nederland */}
      <div className="bg-gradient-to-br from-cyan-950/50 via-slate-900 to-slate-950 border border-cyan-600/80 rounded-2xl p-5 sm:p-6 shadow-xl">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-slate-800 pb-4">
          <div className="space-y-2">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="bg-cyan-500 text-slate-950 text-[10px] font-mono-code font-extrabold px-2.5 py-0.5 rounded uppercase">
                🇪🇺 CIRCL / EU CEF TELECOM STANDAARD
              </span>
              <span className="bg-emerald-950 text-emerald-300 border border-emerald-700 text-[10px] font-mono-code font-bold px-2.5 py-0.5 rounded">
                🇳🇱 AIL-PROJECT NEDERLAND MODULE ACTIEF
              </span>
              <span className="bg-purple-950 text-purple-300 border border-purple-700 text-[10px] font-mono-code font-bold px-2 py-0.5 rounded">
                BSN 11-PROEF • NL-IBAN • MISP EXPORT
              </span>
            </div>

            <h2 className="text-lg sm:text-2xl font-black text-white tracking-tight">
              AIL-Project Integratie Nederland (Analysis of Information Leaks)
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 max-w-4xl leading-relaxed">
              Het open-source{' '}
              <strong className="text-cyan-300">
                AIL Framework (github.com/ail-project/ail-framework)
              </strong>{' '}
              van <strong className="text-white">CIRCL Luxemburg</strong> is dé Europese CSIRT-standaard
              (naast MISP) voor het automatisch doorzoeken van ongestructureerde datalekken, Pastebin-dumps,
              Telegram-streams, infostealer-logs en Tor <code className="text-purple-300">.onion</code>{' '}
              sites. Hieronder vindt u zowel het{' '}
              <strong className="text-emerald-300">volledige haalbaarheidsonderzoek voor Nederland</strong>{' '}
              als een{' '}
              <strong className="text-amber-300">
                werkende AIL-NL Leak & Paste Analyzer (met echte BSN 11-proef & MISP-export)
              </strong>{' '}
              die 100% zelfstandig in uw portaal draait.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row lg:flex-col gap-2 shrink-0">
            <a
              href="https://github.com/ail-project/ail-framework"
              target="_blank"
              rel="noopener noreferrer"
              className="px-3.5 py-2 rounded-xl bg-slate-950 hover:bg-slate-800 text-cyan-300 border border-cyan-700/80 text-xs font-bold flex items-center justify-center gap-1.5 transition-all"
            >
              <span>🐙 Officiële AIL-Project GitHub</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
            <button
              type="button"
              onClick={handleDownloadMispJson}
              className="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center justify-center gap-1.5 shadow-md transition-all cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Exporteer MISP JSON (NCSC/DIVD)</span>
            </button>
          </div>
        </div>

        {/* Sub-navigation pills */}
        <div className="pt-4 flex items-center gap-2 flex-wrap">
          <button
            type="button"
            onClick={() => setActiveSubView('SANDBOX_ANALYZER')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
              activeSubView === 'SANDBOX_ANALYZER'
                ? 'bg-cyan-600 text-white shadow-md shadow-cyan-950'
                : 'bg-slate-950 text-slate-300 hover:text-white border border-slate-800'
            }`}
          >
            <Play className="w-3.5 h-3.5" />
            <span>1. Live AIL-NL Dump & Paste Analyzer (BSN 11-proef / IBAN / Cookies)</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveSubView('ARCHITECTUUR_NL')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
              activeSubView === 'ARCHITECTUUR_NL'
                ? 'bg-emerald-600 text-white shadow-md shadow-emerald-950'
                : 'bg-slate-950 text-slate-300 hover:text-white border border-slate-800'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>2. Onderzoeksrapport: Hoe AIL-Project werkt voor Nederland</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveSubView('YARA_EN_CONFIG')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
              activeSubView === 'YARA_EN_CONFIG'
                ? 'bg-purple-600 text-white shadow-md shadow-purple-950'
                : 'bg-slate-950 text-slate-300 hover:text-white border border-slate-800'
            }`}
          >
            <FileCode className="w-3.5 h-3.5" />
            <span>3. Kopieerbare NL YARA-Regels & AIL Feeder Configuratie</span>
          </button>
        </div>
      </div>

      {/* VIEW 1: INTERACTIEVE AIL-NL DUMP & PASTE ANALYZER */}
      {activeSubView === 'SANDBOX_ANALYZER' && (
        <div className="space-y-5">
          {/* Scenario selector cards */}
          <div className="bg-slate-900/95 border border-slate-800 rounded-2xl p-4 sm:p-5 space-y-3">
            <div className="flex items-center justify-between gap-2 flex-wrap">
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-cyan-400" />
                <h3 className="text-sm sm:text-base font-bold text-white">
                  Kies een Nederlands Lek-Scenario of plak hieronder uw eigen Paste / Logbestand
                </h3>
              </div>
              <span className="text-[11px] font-mono-code text-emerald-400 bg-emerald-950/70 border border-emerald-800 px-2.5 py-0.5 rounded">
                100% Client-Side Browser Analyse (Geen data verlaat uw scherm)
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              {SAMPLE_NL_SCENARIOS.map((scen) => (
                <button
                  key={scen.id}
                  type="button"
                  onClick={() => handleLoadScenario(scen)}
                  className={`p-3.5 rounded-xl border text-left transition-all cursor-pointer flex flex-col justify-between gap-2 ${
                    selectedScenarioId === scen.id
                      ? 'bg-cyan-950/40 border-cyan-500 ring-1 ring-cyan-500/40'
                      : 'bg-slate-950/90 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <div>
                    <div className="flex items-center justify-between gap-2 mb-1">
                      <span className="text-[10px] font-mono-code font-bold bg-cyan-950 text-cyan-300 border border-cyan-800 px-2 py-0.5 rounded">
                        {scen.badge}
                      </span>
                      <span className="text-[10px] font-mono-code text-slate-400 truncate">
                        {scen.sourceChannel}
                      </span>
                    </div>
                    <div className="text-xs font-bold text-white leading-snug">{scen.title}</div>
                    <p className="text-[11px] text-slate-400 mt-1 line-clamp-2 leading-relaxed">
                      {scen.description}
                    </p>
                  </div>
                  <div className="text-[11px] font-bold text-cyan-400 flex items-center gap-1 pt-1">
                    <span>Inladen in AIL-NL Engine</span>
                    <span>→</span>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Main 2-column Split: Left = Raw Paste Input, Right = Live AIL-NL Decoders Output */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
            {/* Left Column: Raw Stream / Paste Input */}
            <div className="lg:col-span-5 bg-slate-900/95 border border-slate-800 rounded-2xl p-4 sm:p-5 flex flex-col justify-between space-y-3">
              <div className="space-y-2">
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <Terminal className="w-4 h-4 text-cyan-400" />
                    <h4 className="text-xs sm:text-sm font-bold text-white uppercase font-mono-code">
                      Inkomende AIL Feeder Stream / Paste
                    </h4>
                  </div>
                  <button
                    type="button"
                    onClick={() => setInputText('')}
                    className="text-[11px] text-slate-400 hover:text-white px-2 py-0.5 rounded bg-slate-950 border border-slate-800 cursor-pointer"
                  >
                    Wissen
                  </button>
                </div>
                <p className="text-[11px] text-slate-400">
                  Plak hier een ruwe Pastebin-tekst, Telegram-dump, SQL-fragment of{' '}
                  <code className="text-cyan-300">.env</code> bestand. De Nederlandse AIL-decoders
                  toetsen elk 9-cijferig getal direct aan de{' '}
                  <strong className="text-white">wiskundige BSN 11-proef</strong> en controleren
                  NL-IBANs, overheidsdomeinen en sessiecookies.
                </p>
                <textarea
                  value={inputText}
                  onChange={(e) => setInputText(e.target.value)}
                  rows={14}
                  placeholder="Plak hier ruwe tekst, logregels, BSN-nummers, NL-IBANs of e-mailadressen..."
                  className="w-full rounded-xl bg-slate-950 border border-slate-800 focus:border-cyan-500 focus:outline-none p-3 text-xs font-mono-code text-emerald-300 leading-relaxed"
                />
              </div>

              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between gap-2 text-xs">
                <div>
                  <span className="text-slate-400 block text-[10px] font-mono-code">
                    AIL-NL RISICOSCORE (0-100)
                  </span>
                  <span
                    className={`text-base font-black font-mono-code ${
                      analysisResult.riskScore >= 70
                        ? 'text-rose-400'
                        : analysisResult.riskScore >= 40
                        ? 'text-amber-400'
                        : 'text-emerald-400'
                    }`}
                  >
                    {analysisResult.riskScore} / 100 —{' '}
                    {analysisResult.riskScore >= 70
                      ? 'KRITIEK DATALEK (DIRECTE CSIRT MELDING)'
                      : analysisResult.riskScore >= 40
                      ? 'VERHOOGD RISICO'
                      : 'LAAG RISICO'}
                  </span>
                </div>

                <button
                  type="button"
                  onClick={() => setShowUnmasked(!showUnmasked)}
                  className="px-2.5 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-200 border border-slate-700 text-[11px] font-bold cursor-pointer"
                >
                  {showUnmasked ? '🙈 Verberg Gevoelige Data' : '👁️ Toon Volledige Waarden'}
                </button>
              </div>
            </div>

            {/* Right Column: Extracted Dutch Entities + YARA Matches */}
            <div className="lg:col-span-7 bg-slate-900/95 border border-slate-800 rounded-2xl p-4 sm:p-5 space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
                <div>
                  <h4 className="text-sm sm:text-base font-extrabold text-white flex items-center gap-2">
                    <ShieldAlert className="w-4 h-4 text-rose-400" />
                    <span>
                      Gedetecteerde Nederlandse Indicatoren ({analysisResult.entities.length})
                    </span>
                  </h4>
                  <p className="text-[11px] text-slate-400">
                    Gevalideerd door de AIL-NL Decoders (Elfproef BSN, Bank-BIC, Overheidsdomeinen &
                    Session Tokens)
                  </p>
                </div>

                <button
                  type="button"
                  onClick={handleDownloadMispJson}
                  className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer shrink-0"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download MISP Event (.json)</span>
                </button>
              </div>

              {/* Triggered Dutch YARA Rules */}
              {analysisResult.yaraMatches.length > 0 && (
                <div className="space-y-2">
                  <div className="text-[10px] font-mono-code font-bold text-purple-300 uppercase">
                    🎯 Aangeslagen Nederlandse YARA Retro-Hunt Regels ({analysisResult.yaraMatches.length})
                  </div>
                  <div className="grid grid-cols-1 gap-2">
                    {analysisResult.yaraMatches.map((ym) => (
                      <div
                        key={ym.ruleName}
                        className="p-3 rounded-xl bg-purple-950/30 border border-purple-700/80 flex flex-col sm:flex-row sm:items-center justify-between gap-2"
                      >
                        <div className="space-y-0.5">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="text-xs font-mono-code font-bold text-purple-200">
                              {ym.ruleName}
                            </span>
                            <span className="text-[10px] font-mono-code font-bold bg-rose-950 text-rose-300 border border-rose-800 px-1.5 py-0.2 rounded">
                              {ym.tlp}
                            </span>
                          </div>
                          <p className="text-[11px] text-slate-300">{ym.description}</p>
                        </div>
                        <div className="text-[10px] font-mono-code text-emerald-300 bg-emerald-950/80 border border-emerald-800 px-2.5 py-1 rounded shrink-0">
                          Bestemd voor: <strong>{ym.targetRecipient}</strong>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Extracted Entities List */}
              {analysisResult.entities.length === 0 ? (
                <div className="p-8 rounded-xl bg-slate-950 border border-slate-800 text-center space-y-2">
                  <Search className="w-6 h-6 text-slate-500 mx-auto" />
                  <div className="text-sm font-bold text-slate-300">
                    Geen Nederlandse BSN, IBAN, .nl-credentials of sessietokens gedetecteerd
                  </div>
                  <p className="text-xs text-slate-500">
                    Kies hierboven een van de drie Nederlandse scenario&apos;s of plak tekst met een
                    geldig 9-cijferig BSN of NL-IBAN.
                  </p>
                </div>
              ) : (
                <div className="space-y-2.5 max-h-[430px] overflow-y-auto pr-1">
                  {analysisResult.entities.map((ent) => (
                    <div
                      key={ent.id}
                      className="p-3 rounded-xl bg-slate-950 border border-slate-800 hover:border-cyan-700/70 transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-2.5"
                    >
                      <div className="space-y-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span
                            className={`text-[10px] font-mono-code font-bold px-2 py-0.5 rounded border ${
                              ent.severity === 'KRITIEK'
                                ? 'bg-rose-950 text-rose-300 border-rose-800'
                                : 'bg-amber-950 text-amber-300 border-amber-800'
                            }`}
                          >
                            {ent.severity}
                          </span>
                          <span className="text-xs font-bold text-white">{ent.label}</span>
                          <span className="text-[10px] font-mono-code text-cyan-400 bg-cyan-950/60 border border-cyan-900 px-1.5 py-0.2 rounded">
                            MISP: {ent.mispAttributeType}
                          </span>
                        </div>

                        <div className="text-xs font-mono-code text-emerald-300 bg-slate-900 px-2.5 py-1 rounded border border-slate-800 break-all">
                          {showUnmasked ? ent.value : ent.maskedValue}
                        </div>

                        <div className="text-[11px] text-slate-400 flex items-center gap-1.5 flex-wrap">
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                          <span>{ent.validationDetail}</span>
                        </div>
                      </div>

                      <div className="text-left sm:text-right shrink-0">
                        <span className="text-[10px] font-mono-code text-slate-400 block">
                          MELDING / ROUTERING:
                        </span>
                        <span className="text-[11px] font-bold text-amber-300">
                          {ent.targetOrgOrSector}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* VIEW 2: HAALBAARHEIDSONDERZOEK & ARCHITECTUUR VOOR NEDERLAND */}
      {activeSubView === 'ARCHITECTUUR_NL' && (
        <div className="space-y-5">
          <div className="bg-slate-900/95 border border-emerald-700/80 rounded-2xl p-5 space-y-4">
            <div className="border-b border-slate-800 pb-3">
              <span className="text-[10px] font-mono-code font-bold uppercase bg-emerald-950 text-emerald-300 border border-emerald-800 px-2.5 py-0.5 rounded">
                ARCHITECTUUR- & HAALBAARHEIDSONDERZOEK
              </span>
              <h3 className="text-base sm:text-xl font-black text-white mt-1.5">
                Hoe het AIL-Project (CIRCL) gericht op Nederland kan worden ingezet
              </h3>
              <p className="text-xs sm:text-sm text-slate-300 mt-1 leading-relaxed">
                Uit ons technisch onderzoek naar de codebase van{' '}
                <code className="text-cyan-300">ail-project/ail-framework</code> blijkt dat AIL
                modulair is opgebouwd (in Python, Redis/Kvrocks en ZMQ-streams) en uitstekend kan
                worden toegespitst op het Nederlandse dreigingslandschap via{' '}
                <strong className="text-white">vier specifieke lagen</strong>:
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Laag 1 */}
              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
                <div className="flex items-center gap-2 text-cyan-400 font-bold text-sm">
                  <Globe className="w-4 h-4" />
                  <span>1. Ingestie & Feeders gericht op .NL & Darknet</span>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">
                  AIL gebruikt losse <em>Feeders</em> die data via ZMQ/REST naar de AIL-core sturen.
                  Voor Nederland zijn de volgende 4 officiële AIL-feeders essentieel:
                </p>
                <ul className="text-xs text-slate-300 space-y-1.5 list-disc list-inside">
                  <li>
                    <strong className="text-white">Pystemon / Paste Feeder:</strong> Monitort
                    Pastebin, Ghostbin, Rentry en GitHub Gists op <code className="text-cyan-300">.nl</code>,{' '}
                    <code className="text-cyan-300">.overheid.nl</code> en Nederlandse bedrijfsnamen.
                  </li>
                  <li>
                    <strong className="text-white">ail-feeder-telegram & Discord:</strong> Volgt
                    pro-Russische hacktivisten (NoName057(16), DDoSia) en infostealer-kanalen waar
                    Nederlandse logs worden gedeeld.
                  </li>
                  <li>
                    <strong className="text-white">Lacus & AIL Tor Crawler:</strong> Bezoekt
                    geautomatiseerd <code className="text-purple-300">.onion</code> ransomware-leksites
                    (Cl0p, LockBit, Akira, Play) om Nederlandse slachtoffers (zoals Philips of MKB)
                    vroegtijdig te signaleren.
                  </li>
                </ul>
              </div>

              {/* Laag 2 */}
              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
                <div className="flex items-center gap-2 text-emerald-400 font-bold text-sm">
                  <Cpu className="w-4 h-4" />
                  <span>2. Nederlandse Decoders (BSN 11-proef, NL-IBAN & Cookies)</span>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">
                  Standaard zoekt AIL naar creditcards (Luhn-check) en algemene e-mailadressen. Voor
                  Nederland voegen we drie cruciale decoders toe (die we hierboven al live in uw
                  portaal hebben ingebouwd!):
                </p>
                <ul className="text-xs text-slate-300 space-y-1.5 list-disc list-inside">
                  <li>
                    <strong className="text-white">Nederlandse BSN 11-proef Module:</strong> Voorkomt
                    valse meldingen door elk 9-cijferig nummer te toetsen aan de wettelijke{' '}
                    <em>Elfproef</em>. Cruciaal voor AP-meldplicht en Z-CERT (zorg).
                  </li>
                  <li>
                    <strong className="text-white">NL-IBAN & Bank-BIC Module:</strong> Herkent direct
                    rekeningen van ING, Rabobank, ABN AMRO, bunq en BNG Bank (gemeenten).
                  </li>
                  <li>
                    <strong className="text-white">Pass-the-Cookie / Entra ID Detector:</strong>{' '}
                    Zoekt specifiek naar geëxfiltreerde sessiecookies waarmee groepen als{' '}
                    <em>Laundry Bear</em> (AIVD-rapportage) MFA omzeilen.
                  </li>
                </ul>
              </div>

              {/* Laag 3 */}
              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
                <div className="flex items-center gap-2 text-purple-400 font-bold text-sm">
                  <Database className="w-4 h-4" />
                  <span>3. Uitwisseling met NCSC-NL, DIVD & Z-CERT via MISP</span>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">
                  Omdat AIL en MISP allebei door CIRCL zijn ontwikkeld, ondersteunt AIL standaard{' '}
                  <strong className="text-white">PyMISP</strong>. Wanneer AIL een Nederlands lek
                  ontdekt, maakt het automatisch een gestructureerd MISP-event aan dat gedeeld kan
                  worden met:
                </p>
                <ul className="text-xs text-slate-300 space-y-1.5 list-disc list-inside">
                  <li>
                    <strong className="text-white">NCSC-NL & CSIRT-DSP:</strong> Voor vitale
                    aanbieders en de Rijksoverheid onder de Cyberbeveiligingswet (NIS2).
                  </li>
                  <li>
                    <strong className="text-white">DIVD CSIRT:</strong> Voor het waarschuwen van
                    eigenaren van gelekte <code className="text-cyan-300">.env</code> bestanden of
                    kwetsbare PHP-servers (PHP2Shell).
                  </li>
                  <li>
                    <strong className="text-white">Z-CERT & CERT-WM:</strong> Voor ziekenhuizen,
                    GGZ-instellingen en waterschappen.
                  </li>
                </ul>
              </div>

              {/* Laag 4: Hosting & Praktische Inzet voor Bedreigingsmonitor.nl */}
              <div className="p-4 rounded-xl bg-slate-950 border border-amber-700/80 space-y-2">
                <div className="flex items-center gap-2 text-amber-400 font-bold text-sm">
                  <Server className="w-4 h-4" />
                  <span>4. Wat betekent dit voor úw hosting (Mijndomein vs. VPS)?</span>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">
                  De volledige achterliggende AIL-server van CIRCL vereist Linux, Docker, Redis/Kvrocks
                  en minimaal 8 tot 16 GB RAM. Daarom hebben wij een{' '}
                  <strong className="text-emerald-300">slimme hybride oplossing</strong> gebouwd:
                </p>
                <ul className="text-xs text-slate-300 space-y-1.5 list-disc list-inside">
                  <li>
                    <strong className="text-emerald-300">
                      Op uw standaard webhosting (1-bestand index.html):
                    </strong>{' '}
                    Draait onze ingebouwde{' '}
                    <strong>Client-Side AIL-NL Analyzer & MISP Exporter</strong> (tabblad 1 hierboven)
                    100% zelfstandig in de browser, zonder dat u een zware server hoeft te beheren!
                  </li>
                  <li>
                    <strong className="text-cyan-300">Optioneel op een latere VPS / Docker:</strong>{' '}
                    Kunt u de volledige AIL Docker-stack draaien met onze kant-en-klare Nederlandse
                    YARA-regels (tabblad 3).
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* VIEW 3: KOPIEERBARE NL YARA-REGELS & AIL CONFIG */}
      {activeSubView === 'YARA_EN_CONFIG' && (
        <div className="bg-slate-900/95 border border-purple-700/80 rounded-2xl p-5 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
            <div>
              <h3 className="text-base sm:text-lg font-extrabold text-white">
                Nederlandse YARA-Regels voor AIL-Project (`nl_vital_leaks.yar`)
              </h3>
              <p className="text-xs text-slate-300">
                Direct te importeren in een AIL-Project instantie onder{' '}
                <code className="text-purple-300">AIL_HOME/etc/yara/</code> of in MISP / TheHive.
              </p>
            </div>

            <button
              type="button"
              onClick={() => handleCopyText('yara-nl', nlYaraRulesSnippet)}
              className="px-3.5 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer shrink-0"
            >
              {copiedConfig === 'yara-nl' ? (
                <>
                  <Check className="w-3.5 h-3.5" />
                  <span>Gekopieerd naar Klembord!</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  <span>Kopieer NL YARA-Regels</span>
                </>
              )}
            </button>
          </div>

          <pre className="p-4 rounded-xl bg-slate-950 border border-slate-800 text-xs font-mono-code text-purple-200 overflow-x-auto leading-relaxed">
            {nlYaraRulesSnippet}
          </pre>
        </div>
      )}
    </div>
  );
};
