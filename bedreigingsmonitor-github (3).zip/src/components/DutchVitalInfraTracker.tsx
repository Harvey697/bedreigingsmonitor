import React, { useState } from 'react';
import {
  ShieldAlert,
  Anchor,
  Zap,
  Waves,
  Wifi,
  HeartPulse,
  CreditCard,
  Building2,
  Apple,
  Plane,
  Cpu,
  FlaskConical,
  GraduationCap,
  CheckCircle2,
  AlertTriangle,
  Info,
  ChevronDown,
  ChevronUp,
  Search,
  Filter,
} from 'lucide-react';
import { VitalSectorNL } from '../types/threat';
import { VITAL_SECTORS_NL } from '../data/threatData';

export const DutchVitalInfraTracker: React.FC = () => {
  const [expandedSector, setExpandedSector] = useState<VitalSectorNL | null>('HAVEN_EN_LOGISTIEK');
  const [searchQuery, setSearchQuery] = useState('');
  const [levelFilter, setLevelFilter] = useState<'ALL' | 'KRITIEK' | 'HOOG'>('ALL');

  const toggleSector = (id: VitalSectorNL) => {
    setExpandedSector(expandedSector === id ? null : id);
  };

  const filteredSectors = VITAL_SECTORS_NL.filter((sector) => {
    if (levelFilter === 'KRITIEK' && sector.threatLevel !== 'KRITIEK') return false;
    if (levelFilter === 'HOOG' && sector.threatLevel !== 'KRITIEK' && sector.threatLevel !== 'HOOG') return false;

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchName = sector.name.toLowerCase().includes(q);
      const matchDesc = sector.description.toLowerCase().includes(q);
      const matchEntities = sector.keyEntities.some((e) => e.toLowerCase().includes(q));
      const matchVectors = sector.primaryVectors.some((v) => v.toLowerCase().includes(q));
      return matchName || matchDesc || matchEntities || matchVectors;
    }
    return true;
  });

  const getSectorIcon = (id: string) => {
    switch (id) {
      case 'HAVEN_EN_LOGISTIEK':
        return <Anchor className="w-4 h-4 text-cyan-400" />;
      case 'ENERGIE_EN_NETBEHEER':
        return <Zap className="w-4 h-4 text-amber-400" />;
      case 'WATERBEHEER_EN_DIJKEN':
        return <Waves className="w-4 h-4 text-blue-400" />;
      case 'TELECOM_EN_INTERNET':
        return <Wifi className="w-4 h-4 text-purple-400" />;
      case 'ZORG_EN_ZIEKENHUIZEN':
        return <HeartPulse className="w-4 h-4 text-rose-400" />;
      case 'FINANCIELE_SECTOR':
        return <CreditCard className="w-4 h-4 text-emerald-400" />;
      case 'RIJKSOVERHEID_EN_DEFENSIE':
        return <ShieldAlert className="w-4 h-4 text-red-400" />;
      case 'VOEDSEL_EN_AGRO':
        return <Apple className="w-4 h-4 text-orange-400" />;
      case 'TRANSPORT_EN_LUCHTVAART':
        return <Plane className="w-4 h-4 text-sky-400" />;
      case 'HIGHTECH_EN_CHIPS':
        return <Cpu className="w-4 h-4 text-emerald-300" />;
      case 'CHEMIE_EN_INDUSTRIE':
        return <FlaskConical className="w-4 h-4 text-teal-400" />;
      case 'ONDERWIJS_EN_WETENSCHAP':
        return <GraduationCap className="w-4 h-4 text-indigo-400" />;
      default:
        return <Building2 className="w-4 h-4 text-slate-400" />;
    }
  };

  return (
    <div className="bg-slate-900/90 border border-slate-800 rounded-xl sm:rounded-2xl p-3.5 sm:p-5 shadow-xl">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 sm:pb-4 border-b border-slate-800 gap-3">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-1.5 rounded-lg bg-amber-950 text-amber-400 border border-amber-800">
              <ShieldAlert className="w-4 h-4" />
            </span>
            <h2 className="text-sm sm:text-base font-bold text-white tracking-tight">
              Nederlandse Vitale Infrastructuur (NCSC & NIS2 Sector Monitor)
            </h2>
          </div>
          <p className="text-[11px] sm:text-xs text-slate-400 mt-0.5 sm:mt-1">
            Gedetailleerd overzicht van alle beschermde vitale sectoren, sleutelorganisaties en NIS2 compliancestatus
          </p>
        </div>

        <span className="px-3 py-1 rounded-xl bg-amber-950/60 border border-amber-800/80 text-amber-300 font-mono-code text-xs font-bold whitespace-nowrap self-start sm:self-auto">
          🇳🇱 ALLE 12 VITALE & ESSENTIËLE SECTOREN
        </span>
      </div>

      {/* Filter & Search Bar */}
      <div className="mt-3 sm:mt-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800/80 pb-3">
        <div className="flex items-center gap-1.5 overflow-x-auto scrollbar-none py-0.5 max-w-full sm:flex-wrap">
          <button
            onClick={() => setLevelFilter('ALL')}
            className={`px-3 py-1 rounded-lg text-xs font-semibold transition-colors shrink-0 ${
              levelFilter === 'ALL'
                ? 'bg-amber-600 text-white shadow-sm'
                : 'bg-slate-950 text-slate-400 hover:text-white border border-slate-800'
            }`}
          >
            Alle ({VITAL_SECTORS_NL.length})
          </button>
          <button
            onClick={() => setLevelFilter('KRITIEK')}
            className={`px-3 py-1 rounded-lg text-xs font-semibold transition-colors flex items-center gap-1.5 shrink-0 ${
              levelFilter === 'KRITIEK'
                ? 'bg-rose-950 text-rose-300 border border-rose-700'
                : 'bg-slate-950 text-slate-400 hover:text-white border border-slate-800'
            }`}
          >
            <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping" />
            Alleen Kritiek
          </button>
          <button
            onClick={() => setLevelFilter('HOOG')}
            className={`px-3 py-1 rounded-lg text-xs font-semibold transition-colors shrink-0 ${
              levelFilter === 'HOOG'
                ? 'bg-amber-950 text-amber-300 border border-amber-700'
                : 'bg-slate-950 text-slate-400 hover:text-white border border-slate-800'
            }`}
          >
            Kritiek + Hoog
          </button>
        </div>

        <div className="relative w-full sm:w-auto sm:min-w-[240px]">
          <Search className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Zoek sector, entiteit (ASML, AH)..."
            className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-9 pr-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-600 transition-colors"
          />
        </div>
      </div>

      {/* Sector List Accordion */}
      <div className="mt-4 space-y-2.5 sm:space-y-3">
        {filteredSectors.map((sector) => {
          const isExpanded = expandedSector === sector.id;
          return (
            <div
              key={sector.id}
              className={`rounded-xl border transition-all overflow-hidden ${
                isExpanded
                  ? 'bg-slate-950/90 border-slate-700'
                  : 'bg-slate-950/50 border-slate-800/80 hover:border-slate-700'
              }`}
            >
              <button
                onClick={() => toggleSector(sector.id)}
                className="w-full text-left p-3 sm:p-4 flex items-center justify-between gap-2.5 sm:gap-3"
              >
                <div className="flex items-center gap-2.5 sm:gap-3 min-w-0">
                  <div className="p-2 rounded-lg bg-slate-900 border border-slate-800 shrink-0">
                    {getSectorIcon(sector.id)}
                  </div>

                  <div className="min-w-0">
                    <div className="flex items-center gap-1.5 sm:gap-2 flex-wrap">
                      <span className="font-bold text-xs sm:text-sm text-white truncate">{sector.name}</span>
                      <span
                        className={`text-[9px] sm:text-[10px] font-mono-code font-bold px-1.5 sm:px-2 py-0.5 rounded border ${
                          sector.threatLevel === 'KRITIEK'
                            ? 'bg-rose-950 text-rose-300 border-rose-800 animate-pulse'
                            : 'bg-amber-950 text-amber-300 border-amber-800'
                        }`}
                      >
                        {sector.threatLevel}
                      </span>
                    </div>
                    <div className="text-[11px] sm:text-xs text-slate-400 line-clamp-1 mt-0.5">
                      {sector.description}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2 sm:gap-3 shrink-0">
                  <div className="text-right">
                    <div className="hidden sm:block">
                      <span className="text-[11px] text-slate-400 block font-mono-code">AANVALSENERGY</span>
                      <strong className="text-xs text-rose-400 font-mono-code">{sector.activeAttacksCount} incidenten</strong>
                    </div>
                    <span className="sm:hidden text-[10px] font-mono-code font-bold bg-rose-950 text-rose-300 border border-rose-900 px-1.5 py-0.5 rounded">
                      {sector.activeAttacksCount}⚡
                    </span>
                  </div>
                  {isExpanded ? <ChevronUp className="w-4 h-4 text-slate-400" /> : <ChevronDown className="w-4 h-4 text-slate-400" />}
                </div>
              </button>

              {isExpanded && (
                <div className="px-4 pb-4 pt-1 border-t border-slate-900/80 text-xs space-y-3">
                  {/* Key Protected Entities */}
                  <div>
                    <span className="text-[11px] font-mono-code text-slate-400 block mb-1">
                      SLEUTELENTITEITEN & VITALE BEDRIJVEN:
                    </span>
                    <div className="flex flex-wrap gap-1.5">
                      {sector.keyEntities.map((entity) => (
                        <span
                          key={entity}
                          className="px-2.5 py-1 rounded-lg bg-slate-900 border border-slate-800 text-slate-200 font-semibold text-[11px]"
                        >
                          {entity}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Primary Vectors */}
                  <div>
                    <span className="text-[11px] font-mono-code text-rose-400 block mb-1">
                      VOORNAAMSTE AANVALSVECTOREN (OBSERVEERD):
                    </span>
                    <div className="flex flex-wrap gap-1.5">
                      {sector.primaryVectors.map((vec) => (
                        <span
                          key={vec}
                          className="px-2 py-0.5 rounded text-[11px] font-mono-code bg-rose-950/60 border border-rose-900/70 text-rose-300"
                        >
                          {vec}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* NCSC Recommended Action */}
                  <div className="p-3 rounded-xl bg-slate-900/90 border border-slate-800 flex items-start gap-2.5">
                    <Info className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                    <div>
                      <span className="font-bold text-amber-300 text-xs block">
                        Dringend Beveiligingsadvies (NCSC / NIS2 Protocol):
                      </span>
                      <p className="text-slate-300 mt-0.5 text-xs leading-relaxed">
                        {sector.recommendedAction}
                      </p>
                    </div>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
