import React from 'react';
import {
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  X,
  ExternalLink,
  Lock,
  Layers,
  Sparkles,
  Radio,
  FileCheck2,
} from 'lucide-react';
import { ThreatItem, VerificationSource } from '../types/threat';

interface MultiSourceVerificationModalProps {
  threat: ThreatItem | null;
  isOpen: boolean;
  onClose: () => void;
}

export const MultiSourceVerificationModal: React.FC<MultiSourceVerificationModalProps> = ({
  threat,
  isOpen,
  onClose,
}) => {
  if (!isOpen || !threat) return null;

  const sources = threat.verificationSources || [];
  const verifiedCount = sources.filter((s) => s.verified).length;
  const score = threat.verificationConfidenceScore || 90;

  const getSourceIcon = (type: string) => {
    switch (type) {
      case 'OVERHEID_CSIRT':
        return '🇳🇱 NCSC';
      case 'INLICHTINGENDIENST':
        return '🛡️ MIVD';
      case 'DARKWEB_CRAWLER':
        return '🧅 TOR';
      case 'EUROPESE_UNIE':
        return '🇪🇺 EU';
      default:
        return '⚡ INTEL';
    }
  };

  return (
    <div
      onClick={onClose}
      className="fixed inset-0 z-[75] flex items-center justify-center p-2.5 sm:p-4 bg-slate-950/85 backdrop-blur-sm animate-in fade-in duration-150"
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="bg-slate-900 border border-slate-700 rounded-xl sm:rounded-2xl max-w-xl w-full p-3.5 sm:p-6 shadow-2xl relative overflow-hidden flex flex-col max-h-[92vh]"
      >
        {/* Ambient glow */}
        <div className="absolute -top-20 -right-20 w-44 h-44 bg-emerald-600/15 rounded-full blur-3xl pointer-events-none" />

        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-emerald-950/80 border border-emerald-800 text-emerald-400">
              <FileCheck2 className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-bold text-white">Meervoudige Bronverificatie</h2>
                <span className="text-[10px] font-mono-code font-bold bg-emerald-950 text-emerald-300 border border-emerald-800 px-2 py-0.5 rounded">
                  {score}% CONSENSUS
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                Onafhankelijke verificatieresultaten voor {threat.targetVictim}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Verification summary score card */}
        <div className="mt-4 p-4 rounded-xl bg-slate-950/80 border border-slate-800 flex items-center justify-between">
          <div>
            <div className="text-xs text-slate-400">Status van Verificatie</div>
            <div className="text-sm font-extrabold text-white mt-0.5 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              <span>{verifiedCount} van de {sources.length} onafhankelijke bronnen bevestigd</span>
            </div>
          </div>
          <div className="text-right font-mono-code">
            <div className="text-[11px] text-slate-400">Cryptografische Hash</div>
            <div className="text-xs font-bold text-emerald-400">CSIRT-NL-OK</div>
          </div>
        </div>

        {/* Sources list */}
        <div className="mt-4 flex-1 overflow-y-auto space-y-3">
          {sources.map((source) => (
            <div
              key={source.id}
              className={`p-3.5 rounded-xl border ${
                source.verified
                  ? 'bg-slate-950/70 border-slate-800'
                  : 'bg-slate-950/40 border-slate-900 opacity-60'
              }`}
            >
              <div className="flex items-center justify-between mb-1.5">
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-mono-code font-bold bg-slate-900 px-2 py-0.5 rounded border border-slate-800 text-slate-300">
                    {getSourceIcon(source.type)}
                  </span>
                  <span className="text-xs font-bold text-white">
                    {source.sourceName}
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-mono-code text-slate-400">
                    {source.timestamp} CET
                  </span>
                  {source.verified ? (
                    <span className="text-[10px] font-mono-code font-bold text-emerald-400 bg-emerald-950/60 border border-emerald-800/80 px-2 py-0.2 rounded flex items-center gap-1">
                      <CheckCircle2 className="w-3 h-3" /> BEVESTIGD
                    </span>
                  ) : (
                    <span className="text-[10px] font-mono-code text-amber-400">
                      IN ONDERZOEK
                    </span>
                  )}
                </div>
              </div>

              <div className="text-xs text-slate-300 pl-1 mt-1 leading-relaxed">
                {source.evidenceSummary}
              </div>

              <div className="mt-2 pl-1 flex items-center gap-2 text-[10px] font-mono-code text-slate-400">
                <span>Betrouwbaarheidsniveau:</span>
                <strong className="text-amber-400">{source.confidence.replace('_', ' ')}</strong>
              </div>
            </div>
          ))}
        </div>

        {/* Footer */}
        <div className="mt-4 pt-3 border-t border-slate-800 flex items-center justify-between text-xs">
          <span className="text-slate-400">
            NCSC Sensornetwerk: Actieve telemetrie-audit
          </span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-semibold transition-colors"
          >
            Sluiten
          </button>
        </div>
      </div>
    </div>
  );
};
