import React, { useState, useMemo } from 'react';
import {
  Pill,
  Layers,
  CreditCard,
  Terminal,
  Network,
  GitBranch,
  ShieldAlert,
  Anchor,
  Coins,
  ArrowRight,
  Search,
  ExternalLink,
  Lock,
  AlertTriangle,
  CheckCircle2,
  Workflow,
  FileText,
  ChevronRight,
  Info,
  SlidersHorizontal,
  Scale,
  RefreshCw,
  Eye,
  Key,
  Flame,
  Radio,
  X,
} from 'lucide-react';
import {
  CrimeCaseStudy,
  CrimeChainSimulation,
  CrimeDomainId,
  CrimeNexusLink,
} from '../types/threat';
import {
  CRIME_DOMAINS,
  CRIME_NEXUS_LINKS,
  CRIME_CASE_STUDIES,
  CRIME_CHAIN_SIMULATIONS,
} from '../data/crimeNexusData';

interface CrimeNexusMatrixProps {
  onNavigateToTab?: (tab: string) => void;
  onOpenAiAnalysis?: (topic: string) => void;
}

export const CrimeNexusMatrix: React.FC<CrimeNexusMatrixProps> = ({
  onNavigateToTab,
}) => {
  const [activeDomainFilter, setActiveDomainFilter] = useState<CrimeDomainId | 'ALL'>('ALL');
  const [selectedLink, setSelectedLink] = useState<CrimeNexusLink | null>(CRIME_NEXUS_LINKS[0]);
  const [detailModalLink, setDetailModalLink] = useState<CrimeNexusLink | null>(null);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [activeTab, setActiveTab] = useState<'VERBANDEN' | 'KETEN_SIMULATOR' | 'CASE_STUDIES' | 'MITIGATIE'>('VERBANDEN');

  // Simulation state
  const [activeSimIndex, setActiveSimIndex] = useState<number>(0);
  const [activeSimStep, setActiveSimStep] = useState<number>(0);

  // Selected Case Study state
  const [selectedCaseStudy, setSelectedCaseStudy] = useState<CrimeCaseStudy | null>(CRIME_CASE_STUDIES[0]);

  // Filter links
  const filteredLinks = useMemo(() => {
    return CRIME_NEXUS_LINKS.filter((link) => {
      const matchesDomain =
        activeDomainFilter === 'ALL' ||
        link.sourceDomain === activeDomainFilter ||
        link.targetDomain === activeDomainFilter;

      if (!matchesDomain) return false;

      if (!searchQuery.trim()) return true;

      const q = searchQuery.toLowerCase();
      return (
        link.title.toLowerCase().includes(q) ||
        link.shortSummary.toLowerCase().includes(q) ||
        link.realWorldExample.toLowerCase().includes(q) ||
        link.tags.some((t) => t.toLowerCase().includes(q)) ||
        link.technicalVectors.some((v) => v.toLowerCase().includes(q))
      );
    });
  }, [activeDomainFilter, searchQuery]);

  const currentSimulation = CRIME_CHAIN_SIMULATIONS[activeSimIndex];

  const getDomainIcon = (domain: CrimeDomainId) => {
    switch (domain) {
      case 'DRUGSHANDEL':
        return <Pill className="w-4 h-4 text-emerald-400" />;
      case 'DARKNETMARKTEN':
        return <Layers className="w-4 h-4 text-purple-400" />;
      case 'FRAUDE':
        return <CreditCard className="w-4 h-4 text-amber-400" />;
      case 'CYBERCRIME':
        return <Terminal className="w-4 h-4 text-rose-400" />;
    }
  };

  const getDomainBadge = (domain: CrimeDomainId) => {
    switch (domain) {
      case 'DRUGSHANDEL':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-bold bg-emerald-950 text-emerald-300 border border-emerald-800">
            <Pill className="w-3 h-3" />
            Drugshandel
          </span>
        );
      case 'DARKNETMARKTEN':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-bold bg-purple-950 text-purple-300 border border-purple-800">
            <Layers className="w-3 h-3" />
            Darknetmarkten
          </span>
        );
      case 'FRAUDE':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-bold bg-amber-950 text-amber-300 border border-amber-800">
            <CreditCard className="w-3 h-3" />
            Fraude
          </span>
        );
      case 'CYBERCRIME':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-bold bg-rose-950 text-rose-300 border border-rose-800">
            <Terminal className="w-3 h-3" />
            Cybercrime
          </span>
        );
    }
  };

  return (
    <div className="space-y-6">
      {/* Hero Executive Header */}
      <div className="bg-gradient-to-br from-slate-900 via-slate-900/95 to-slate-950 border border-slate-800 rounded-2xl p-5 sm:p-7 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-gradient-to-bl from-emerald-500/10 via-purple-500/10 to-transparent blur-3xl pointer-events-none" />

        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 relative z-10">
          <div className="space-y-2 max-w-3xl">
            <div className="flex flex-wrap items-center gap-2">
              <span className="px-2.5 py-1 rounded-md bg-emerald-950/80 text-emerald-300 border border-emerald-700/80 text-xs font-mono font-bold flex items-center gap-1.5 shadow-sm">
                <Network className="w-3.5 h-3.5 text-emerald-400" />
                CRIMINOLOGISCHE NEXUS MATRIX
              </span>
              <span className="px-2.5 py-1 rounded-md bg-purple-950/80 text-purple-300 border border-purple-700/80 text-xs font-mono font-bold">
                THTC × FIOD × NCSC ANALYSE
              </span>
              <span className="px-2 py-0.5 rounded text-[11px] font-mono bg-rose-950 text-rose-300 border border-rose-800">
                ONDERMIJNING & HYBRIDE CRIMINALITEIT
              </span>
            </div>

            <h1 className="text-xl sm:text-3xl font-black text-white tracking-tight leading-tight">
              Het Verweven Web: <span className="text-emerald-400">Drugshandel</span>,{' '}
              <span className="text-purple-400">Darknetmarkten</span>,{' '}
              <span className="text-amber-400">Fraude</span> &{' '}
              <span className="text-rose-400">Cybercriminaliteit</span>
            </h1>

            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
              In de georganiseerde misdaad bestaan geen geïsoleerde silo's meer. Criminelen opereren in een
              syndicaat-ecosysteem waarin fysieke narcotica-invoer in de <strong className="text-white">Rotterdamse haven</strong> leunt
              op <strong className="text-rose-400">cyberinbraken</strong> bij terminals, <strong className="text-amber-400">fraudesyndicaten</strong> rekeningen
              plunderen met infostealer-data van <strong className="text-purple-400">darknetmarkten</strong>, en ransomware-miljoenen worden gewit via
              ondergrondse cash-swaps met drugskartels.
            </p>
          </div>

          {/* Quick Metrics Bar */}
          <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-2 gap-2.5 shrink-0">
            <div className="bg-slate-950/80 border border-emerald-900/60 rounded-xl p-3 text-center">
              <div className="text-lg sm:text-2xl font-black text-emerald-400 font-mono">4 Hubs</div>
              <div className="text-[10px] text-slate-400 font-medium">Verbonden Pijlers</div>
            </div>
            <div className="bg-slate-950/80 border border-purple-900/60 rounded-xl p-3 text-center">
              <div className="text-lg sm:text-2xl font-black text-purple-400 font-mono">{CRIME_NEXUS_LINKS.length} Chokepoints</div>
              <div className="text-[10px] text-slate-400 font-medium">Geverifieerde Verbanden</div>
            </div>
            <div className="bg-slate-950/80 border border-amber-900/60 rounded-xl p-3 text-center">
              <div className="text-lg sm:text-2xl font-black text-amber-400 font-mono">€4.8 Mld+</div>
              <div className="text-[10px] text-slate-400 font-medium">NL Witwas- en Schadevolume</div>
            </div>
            <div className="bg-slate-950/80 border border-rose-900/60 rounded-xl p-3 text-center">
              <div className="text-lg sm:text-2xl font-black text-rose-400 font-mono">{CRIME_CASE_STUDIES.length} Operaties</div>
              <div className="text-[10px] text-slate-400 font-medium">Politie & Justitie Zaken</div>
            </div>
          </div>
        </div>
      </div>

      {/* 4 Core Pillars Interactive Hub Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {CRIME_DOMAINS.map((domain) => {
          const isSelected = activeDomainFilter === domain.id;
          return (
            <div
              key={domain.id}
              onClick={() => setActiveDomainFilter(isSelected ? 'ALL' : domain.id)}
              className={`rounded-2xl p-4.5 border transition-all cursor-pointer flex flex-col justify-between relative overflow-hidden group shadow-md ${
                isSelected
                  ? `${domain.bgColor} ${domain.borderColor} ring-2 ring-offset-2 ring-offset-slate-950 ring-${domain.textColor}`
                  : 'bg-slate-900 border-slate-800 hover:border-slate-700'
              }`}
            >
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <div
                    className={`w-10 h-10 rounded-xl flex items-center justify-center font-bold text-white shadow-md ${
                      domain.id === 'DRUGSHANDEL'
                        ? 'bg-emerald-600'
                        : domain.id === 'DARKNETMARKTEN'
                        ? 'bg-purple-600'
                        : domain.id === 'FRAUDE'
                        ? 'bg-amber-600'
                        : 'bg-rose-600'
                    }`}
                  >
                    {getDomainIcon(domain.id)}
                  </div>

                  <span
                    className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded border ${
                      isSelected
                        ? 'bg-white/10 text-white border-white/20'
                        : 'bg-slate-950 text-slate-400 border-slate-800'
                    }`}
                  >
                    {isSelected ? 'Geselecteerd' : 'Klik om te focussen'}
                  </span>
                </div>

                <div>
                  <h3 className="font-extrabold text-white text-base tracking-tight group-hover:text-slate-100 transition-colors">
                    {domain.name}
                  </h3>
                  <p className="text-xs text-slate-400 mt-0.5 line-clamp-2">
                    {domain.subtitle}
                  </p>
                </div>

                <div className="bg-slate-950/60 rounded-xl p-2.5 border border-slate-800/80 space-y-1">
                  <div className="text-[10px] text-slate-400 uppercase font-mono tracking-wider">
                    Volume & Omvang NL
                  </div>
                  <div className={`text-xs font-bold font-mono ${domain.textColor}`}>
                    {domain.estimatedVolumeNL}
                  </div>
                </div>

                <div className="space-y-1.5 pt-1">
                  <div className="text-[10px] uppercase font-mono text-slate-400">
                    Sleutelactoren & methoden:
                  </div>
                  <ul className="text-[11px] text-slate-300 space-y-1">
                    {domain.keyActors.slice(0, 2).map((actor, idx) => (
                      <li key={idx} className="flex items-start gap-1.5">
                        <span className="text-slate-500 mt-1">•</span>
                        <span>{actor}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between text-xs font-semibold">
                <span className={domain.textColor}>
                  {CRIME_NEXUS_LINKS.filter(
                    (l) => l.sourceDomain === domain.id || l.targetDomain === domain.id
                  ).length}{' '}
                  actieve dwarsverbanden
                </span>
                <ChevronRight className="w-4 h-4 text-slate-400 group-hover:translate-x-1 transition-transform" />
              </div>
            </div>
          );
        })}
      </div>

      {/* Interactive Relational Nexus Diagram (Interactive SVG Map) */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <span className="p-1.5 rounded-lg bg-emerald-950 text-emerald-400 border border-emerald-800">
              <Workflow className="w-4 h-4" />
            </span>
            <div>
              <h2 className="text-base sm:text-lg font-black text-white">
                Interactief Verbanden-Diagram (Nexus Map)
              </h2>
              <p className="text-xs text-slate-400">
                Visualiseert de realtime kruisbestuiving en geldstromen tussen de 4 criminele domeinen
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {activeDomainFilter !== 'ALL' && (
              <button
                onClick={() => setActiveDomainFilter('ALL')}
                className="text-xs text-slate-300 hover:text-white bg-slate-800 px-3 py-1.5 rounded-lg border border-slate-700 flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                <RefreshCw className="w-3 h-3" />
                <span>Toon alle verbindingen</span>
              </button>
            )}
          </div>
        </div>

        {/* Visual Network Schematic with clickable connection links */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
          {/* Left / Center Diagram Canvas */}
          <div className="lg:col-span-7 bg-slate-950 rounded-2xl border border-slate-800 p-4 sm:p-6 relative overflow-hidden flex flex-col items-center justify-center min-h-[380px]">
            {/* Ambient Background Grid */}
            <div
              className="absolute inset-0 opacity-15 pointer-events-none"
              style={{
                backgroundImage:
                  'radial-gradient(#10b981 1px, transparent 1px), radial-gradient(#a855f7 1px, transparent 1px)',
                backgroundSize: '24px 24px',
                backgroundPosition: '0 0, 12px 12px',
              }}
            />

            {/* Central Convergence Badge */}
            <div className="relative z-10 text-center my-4">
              <div className="inline-flex flex-col items-center p-3 rounded-2xl bg-slate-900/90 border border-slate-700 backdrop-blur-md shadow-2xl">
                <span className="text-[10px] uppercase font-mono tracking-widest text-slate-400 font-bold">
                  Centrale Criminelen Hub
                </span>
                <span className="text-xs font-black text-white flex items-center gap-1.5 mt-0.5">
                  <ShieldAlert className="w-3.5 h-3.5 text-rose-500 animate-pulse" />
                  Syndicaat Convergentie
                </span>
                <span className="text-[10px] text-emerald-400 font-mono mt-0.5">
                  Haven RTM × Tor × SEPA × RaaS
                </span>
              </div>
            </div>

            {/* 4 Quadrants Interactive Network */}
            <div className="w-full max-w-lg grid grid-cols-2 gap-4 sm:gap-6 relative z-10">
              {/* Node 1: Drugshandel */}
              <div
                onClick={() => setActiveDomainFilter('DRUGSHANDEL')}
                className={`p-3.5 rounded-xl border transition-all cursor-pointer text-left ${
                  activeDomainFilter === 'DRUGSHANDEL' || activeDomainFilter === 'ALL'
                    ? 'bg-emerald-950/60 border-emerald-600 shadow-lg shadow-emerald-950/50'
                    : 'bg-slate-900/40 border-slate-800 opacity-40'
                }`}
              >
                <div className="flex items-center gap-2">
                  <span className="p-1.5 rounded-lg bg-emerald-600 text-white">
                    <Pill className="w-4 h-4" />
                  </span>
                  <div>
                    <div className="text-xs font-black text-emerald-300">DRUGSHANDEL</div>
                    <div className="text-[10px] text-slate-400">Haven & Containers</div>
                  </div>
                </div>
                <div className="mt-2 text-[10px] text-slate-300 leading-tight">
                  Behoefte: Terminal uitrijcodes, witwassen van miljarden contanten, stealth drops.
                </div>
              </div>

              {/* Node 2: Darknetmarkten */}
              <div
                onClick={() => setActiveDomainFilter('DARKNETMARKTEN')}
                className={`p-3.5 rounded-xl border transition-all cursor-pointer text-left ${
                  activeDomainFilter === 'DARKNETMARKTEN' || activeDomainFilter === 'ALL'
                    ? 'bg-purple-950/60 border-purple-600 shadow-lg shadow-purple-950/50'
                    : 'bg-slate-900/40 border-slate-800 opacity-40'
                }`}
              >
                <div className="flex items-center gap-2">
                  <span className="p-1.5 rounded-lg bg-purple-600 text-white">
                    <Layers className="w-4 h-4" />
                  </span>
                  <div>
                    <div className="text-xs font-black text-purple-300">DARKNETMARKTEN</div>
                    <div className="text-[10px] text-slate-400">Tor & Escrow Shops</div>
                  </div>
                </div>
                <div className="mt-2 text-[10px] text-slate-300 leading-tight">
                  Behoefte: Monero betalingen, verkoop van infostealer logs, drugsretail via PostNL.
                </div>
              </div>

              {/* Node 3: Fraude */}
              <div
                onClick={() => setActiveDomainFilter('FRAUDE')}
                className={`p-3.5 rounded-xl border transition-all cursor-pointer text-left ${
                  activeDomainFilter === 'FRAUDE' || activeDomainFilter === 'ALL'
                    ? 'bg-amber-950/60 border-amber-600 shadow-lg shadow-amber-950/50'
                    : 'bg-slate-900/40 border-slate-800 opacity-40'
                }`}
              >
                <div className="flex items-center gap-2">
                  <span className="p-1.5 rounded-lg bg-amber-600 text-white">
                    <CreditCard className="w-4 h-4" />
                  </span>
                  <div>
                    <div className="text-xs font-black text-amber-300">FINANCIËLE FRAUDE</div>
                    <div className="text-[10px] text-slate-400">Geldezels & Helpdesk</div>
                  </div>
                </div>
                <div className="mt-2 text-[10px] text-slate-300 leading-tight">
                  Behoefte: Gestolen banktokens, Telegram jongeren-ronseling, SEPA cash-out.
                </div>
              </div>

              {/* Node 4: Cybercrime */}
              <div
                onClick={() => setActiveDomainFilter('CYBERCRIME')}
                className={`p-3.5 rounded-xl border transition-all cursor-pointer text-left ${
                  activeDomainFilter === 'CYBERCRIME' || activeDomainFilter === 'ALL'
                    ? 'bg-rose-950/60 border-rose-600 shadow-lg shadow-rose-950/50'
                    : 'bg-slate-900/40 border-slate-800 opacity-40'
                }`}
              >
                <div className="flex items-center gap-2">
                  <span className="p-1.5 rounded-lg bg-rose-600 text-white">
                    <Terminal className="w-4 h-4" />
                  </span>
                  <div>
                    <div className="text-xs font-black text-rose-300">CYBERCRIMINALITEIT</div>
                    <div className="text-[10px] text-slate-400">Ransomware & IAB</div>
                  </div>
                </div>
                <div className="mt-2 text-[10px] text-slate-300 leading-tight">
                  Behoefte: Toegang verkopen, losgeld witwassen via drugscash, offshore hosting.
                </div>
              </div>
            </div>

            {/* Direct Connectors list */}
            <div className="mt-4 pt-3 border-t border-slate-800 w-full flex flex-wrap items-center justify-center gap-2 text-[11px]">
              <span className="text-slate-400 font-mono">Selecteer een kruisverband:</span>
              {CRIME_NEXUS_LINKS.slice(0, 4).map((link) => (
                <button
                  key={link.id}
                  onClick={() => setSelectedLink(link)}
                  className={`px-2.5 py-1 rounded-lg border text-[11px] font-semibold transition-all cursor-pointer ${
                    selectedLink?.id === link.id
                      ? 'bg-rose-900 border-rose-500 text-white'
                      : 'bg-slate-900 border-slate-700 text-slate-300 hover:text-white'
                  }`}
                >
                  {link.title.split('&')[0]}
                </button>
              ))}
            </div>
          </div>

          {/* Right Selected Nexus Detail View */}
          <div className="lg:col-span-5 bg-slate-950/90 rounded-2xl border border-slate-800 p-5 space-y-4">
            {selectedLink ? (
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    {getDomainBadge(selectedLink.sourceDomain)}
                    <ArrowRight className="w-3.5 h-3.5 text-slate-400" />
                    {getDomainBadge(selectedLink.targetDomain)}
                  </div>
                  <span
                    className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded ${
                      selectedLink.severity === 'KRITIEK'
                        ? 'bg-rose-950 text-rose-300 border border-rose-800'
                        : 'bg-amber-950 text-amber-300 border border-amber-800'
                    }`}
                  >
                    {selectedLink.severity}
                  </span>
                </div>

                <div>
                  <h3 className="text-base sm:text-lg font-black text-white">
                    {selectedLink.title}
                  </h3>
                  <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                    {selectedLink.shortSummary}
                  </p>
                </div>

                {/* Real-world Example Box */}
                <div className="p-3.5 rounded-xl bg-slate-900/90 border border-slate-800 space-y-1.5">
                  <div className="flex items-center gap-1.5 text-emerald-400 text-xs font-bold">
                    <Scale className="w-3.5 h-3.5" />
                    <span>Praktijkcase uit Nederland & Politiedossiers</span>
                  </div>
                  <p className="text-[11px] text-slate-300 leading-relaxed">
                    {selectedLink.realWorldExample}
                  </p>
                  {selectedLink.policeOperationRef && (
                    <div className="text-[10px] font-mono text-slate-400 pt-1 border-t border-slate-800">
                      Opsporingsonderzoek:{' '}
                      <strong className="text-white">{selectedLink.policeOperationRef}</strong>
                    </div>
                  )}
                </div>

                {/* Key Technical Vectors */}
                <div className="space-y-1.5">
                  <div className="text-[10px] uppercase font-mono text-slate-400">
                    Gebruikte Technische Vectoren:
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    {selectedLink.technicalVectors.map((v, i) => (
                      <span
                        key={i}
                        className="px-2 py-0.5 bg-slate-900 border border-slate-700 text-slate-300 rounded text-[10px] font-mono"
                      >
                        {v}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="pt-2">
                  <button
                    onClick={() => setActiveTab('KETEN_SIMULATOR')}
                    className="w-full py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-md transition-all cursor-pointer"
                  >
                    <Workflow className="w-4 h-4" />
                    <span>Bekijk in Keten-Simulator (Stap-voor-stap)</span>
                  </button>
                </div>
              </div>
            ) : (
              <div className="text-center py-10 space-y-3">
                <div className="w-12 h-12 rounded-2xl bg-slate-900 border border-slate-800 mx-auto flex items-center justify-center text-slate-400">
                  <Network className="w-6 h-6 text-emerald-400" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-white">Selecteer een Verband</h4>
                  <p className="text-xs text-slate-400 max-w-xs mx-auto mt-1">
                    Klik op een van de knoppen of domeinen links om het specifieke criminologische verband te ontleden.
                  </p>
                </div>
                <button
                  onClick={() => setSelectedLink(CRIME_NEXUS_LINKS[0])}
                  className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-white border border-slate-700 cursor-pointer"
                >
                  Toon Haven Infiltratie & Container PIN-Diefstal
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Sub-Navigation Tabs */}
      <div className="flex border-b border-slate-800 space-x-2 overflow-x-auto pb-1 text-xs font-semibold">
        <button
          onClick={() => setActiveTab('VERBANDEN')}
          className={`px-4 py-2 rounded-xl flex items-center gap-2 transition-all cursor-pointer whitespace-nowrap ${
            activeTab === 'VERBANDEN'
              ? 'bg-emerald-600 text-white shadow-md font-bold'
              : 'text-slate-400 hover:text-white hover:bg-slate-900'
          }`}
        >
          <Network className="w-4 h-4" />
          <span>Alle Geverifieerde Verbanden ({filteredLinks.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('KETEN_SIMULATOR')}
          className={`px-4 py-2 rounded-xl flex items-center gap-2 transition-all cursor-pointer whitespace-nowrap ${
            activeTab === 'KETEN_SIMULATOR'
              ? 'bg-purple-600 text-white shadow-md font-bold'
              : 'text-slate-400 hover:text-white hover:bg-slate-900'
          }`}
        >
          <Workflow className="w-4 h-4" />
          <span>Keten-Simulator ({CRIME_CHAIN_SIMULATIONS.length} Scenario's)</span>
        </button>

        <button
          onClick={() => setActiveTab('CASE_STUDIES')}
          className={`px-4 py-2 rounded-xl flex items-center gap-2 transition-all cursor-pointer whitespace-nowrap ${
            activeTab === 'CASE_STUDIES'
              ? 'bg-amber-600 text-white shadow-md font-bold'
              : 'text-slate-400 hover:text-white hover:bg-slate-900'
          }`}
        >
          <Scale className="w-4 h-4" />
          <span>Politie & Justitie Dossiers ({CRIME_CASE_STUDIES.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('MITIGATIE')}
          className={`px-4 py-2 rounded-xl flex items-center gap-2 transition-all cursor-pointer whitespace-nowrap ${
            activeTab === 'MITIGATIE'
              ? 'bg-rose-600 text-white shadow-md font-bold'
              : 'text-slate-400 hover:text-white hover:bg-slate-900'
          }`}
        >
          <ShieldAlert className="w-4 h-4" />
          <span>Handreikingen & NIS2 Mitigatie</span>
        </button>
      </div>

      {/* TAB 1: Alle Geverifieerde Verbanden Grid */}
      {activeTab === 'VERBANDEN' && (
        <div className="space-y-4">
          {/* Search & Domain Filter Bar */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-3 flex flex-col sm:flex-row items-center justify-between gap-3">
            <div className="relative w-full sm:w-80">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Zoek op haven, geldezel, Monero, Lumma, PostNL..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-9 pr-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
              />
            </div>

            <div className="flex items-center gap-1.5 w-full sm:w-auto overflow-x-auto">
              <span className="text-[11px] text-slate-400 font-mono shrink-0">Filter Pijler:</span>
              <button
                onClick={() => setActiveDomainFilter('ALL')}
                className={`px-2.5 py-1 rounded-lg text-xs font-semibold cursor-pointer ${
                  activeDomainFilter === 'ALL'
                    ? 'bg-slate-800 text-white border border-slate-700'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                Alles
              </button>
              <button
                onClick={() => setActiveDomainFilter('DRUGSHANDEL')}
                className={`px-2.5 py-1 rounded-lg text-xs font-semibold cursor-pointer ${
                  activeDomainFilter === 'DRUGSHANDEL'
                    ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                    : 'text-slate-400 hover:text-emerald-400'
                }`}
              >
                Drugshandel
              </button>
              <button
                onClick={() => setActiveDomainFilter('DARKNETMARKTEN')}
                className={`px-2.5 py-1 rounded-lg text-xs font-semibold cursor-pointer ${
                  activeDomainFilter === 'DARKNETMARKTEN'
                    ? 'bg-purple-950 text-purple-300 border border-purple-800'
                    : 'text-slate-400 hover:text-purple-400'
                }`}
              >
                Darknet
              </button>
              <button
                onClick={() => setActiveDomainFilter('FRAUDE')}
                className={`px-2.5 py-1 rounded-lg text-xs font-semibold cursor-pointer ${
                  activeDomainFilter === 'FRAUDE'
                    ? 'bg-amber-950 text-amber-300 border border-amber-800'
                    : 'text-slate-400 hover:text-amber-400'
                }`}
              >
                Fraude
              </button>
              <button
                onClick={() => setActiveDomainFilter('CYBERCRIME')}
                className={`px-2.5 py-1 rounded-lg text-xs font-semibold cursor-pointer ${
                  activeDomainFilter === 'CYBERCRIME'
                    ? 'bg-rose-950 text-rose-300 border border-rose-800'
                    : 'text-slate-400 hover:text-rose-400'
                }`}
              >
                Cybercrime
              </button>
            </div>
          </div>

          {/* Links Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {filteredLinks.map((link) => (
              <div
                key={link.id}
                onClick={() => {
                  setSelectedLink(link);
                  setDetailModalLink(link);
                }}
                className={`bg-slate-900 border rounded-2xl p-5 shadow-lg flex flex-col justify-between space-y-4 transition-all cursor-pointer group ${
                  selectedLink?.id === link.id
                    ? 'border-emerald-500 ring-1 ring-emerald-500'
                    : 'border-slate-800 hover:border-emerald-600/70'
                }`}
              >
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-1.5 flex-wrap">
                      {getDomainBadge(link.sourceDomain)}
                      <ArrowRight className="w-3.5 h-3.5 text-slate-400" />
                      {getDomainBadge(link.targetDomain)}
                    </div>
                    <span
                      className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded ${
                        link.severity === 'KRITIEK'
                          ? 'bg-rose-950 text-rose-300 border border-rose-800'
                          : 'bg-amber-950 text-amber-300 border border-amber-800'
                      }`}
                    >
                      {link.severity}
                    </span>
                  </div>

                  <div>
                    <h3 className="font-extrabold text-white text-base group-hover:text-emerald-400 transition-colors">
                      {link.title}
                    </h3>
                    <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                      {link.shortSummary}
                    </p>
                  </div>

                  {/* Bullet Mechanisms */}
                  <div className="space-y-1.5 bg-slate-950/60 p-3 rounded-xl border border-slate-800">
                    <div className="text-[10px] font-mono uppercase text-slate-400 font-bold">
                      Hoe grijpen ze in elkaar:
                    </div>
                    <ul className="text-[11px] text-slate-300 space-y-1">
                      {link.mechanisms.slice(0, 2).map((m, idx) => (
                        <li key={idx} className="flex items-start gap-1.5">
                          <CheckCircle2 className="w-3 h-3 text-emerald-400 shrink-0 mt-0.5" />
                          <span>{m}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Real World Snippet */}
                  <div className="text-[11px] text-slate-400 italic bg-slate-950/30 p-2.5 rounded-lg border border-slate-800/60">
                    <strong className="text-slate-300 not-italic">Zaak: </strong>
                    {link.realWorldExample.slice(0, 160)}...
                  </div>
                </div>

                <div className="pt-3 border-t border-slate-800 flex items-center justify-between gap-2 text-xs">
                  <div className="flex flex-wrap gap-1">
                    {link.tags.slice(0, 3).map((t, i) => (
                      <span
                        key={i}
                        className="px-2 py-0.5 rounded text-[10px] font-mono bg-slate-950 text-slate-400 border border-slate-800"
                      >
                        #{t}
                      </span>
                    ))}
                  </div>

                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      setSelectedLink(link);
                      setDetailModalLink(link);
                    }}
                    className="px-3 py-1.5 rounded-xl bg-emerald-950/90 hover:bg-emerald-800 text-emerald-300 hover:text-white border border-emerald-700 font-bold flex items-center gap-1.5 transition-all shadow-sm cursor-pointer shrink-0"
                  >
                    <Eye className="w-3.5 h-3.5" />
                    <span>Details</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 2: Keten Simulator (Interactive Stepper) */}
      {activeTab === 'KETEN_SIMULATOR' && (
        <div className="space-y-6">
          {/* Scenario Selector */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            {CRIME_CHAIN_SIMULATIONS.map((sim, idx) => (
              <button
                key={sim.id}
                onClick={() => {
                  setActiveSimIndex(idx);
                  setActiveSimStep(0);
                }}
                className={`p-4 rounded-xl border text-left transition-all cursor-pointer flex flex-col justify-between ${
                  activeSimIndex === idx
                    ? 'bg-purple-950/60 border-purple-500 shadow-lg shadow-purple-950/40'
                    : 'bg-slate-900 border-slate-800 hover:border-slate-700'
                }`}
              >
                <div>
                  <span className="text-[10px] font-mono text-purple-400 uppercase font-bold">
                    Scenario {idx + 1}
                  </span>
                  <div className="font-extrabold text-white text-sm mt-0.5">{sim.title}</div>
                  <p className="text-xs text-slate-400 mt-1 line-clamp-2">{sim.threatScenario}</p>
                </div>
                <div className="mt-3 text-[11px] font-mono text-amber-300 font-semibold">
                  Schade: {sim.estimatedFinancialDamage.split('+')[0]}
                </div>
              </button>
            ))}
          </div>

          {/* Active Simulation Walkthrough */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-7 shadow-xl space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
              <div>
                <span className="text-xs font-mono font-bold text-purple-400">
                  INTERACTIEVE CRIMINELE KETEN ANALYSE
                </span>
                <h3 className="text-lg sm:text-2xl font-black text-white mt-0.5">
                  {currentSimulation.title}
                </h3>
                <p className="text-xs sm:text-sm text-slate-300 mt-1">
                  {currentSimulation.threatScenario}
                </p>
              </div>

              <div className="bg-slate-950 px-4 py-2 rounded-xl border border-slate-800 text-center shrink-0">
                <div className="text-[10px] uppercase font-mono text-slate-400">Geraamde Schade / Opbrengst</div>
                <div className="text-xs sm:text-sm font-black font-mono text-amber-400">
                  {currentSimulation.estimatedFinancialDamage}
                </div>
              </div>
            </div>

            {/* Stepper Progress Bar */}
            <div className="relative">
              <div className="flex items-center justify-between relative z-10">
                {currentSimulation.steps.map((step, idx) => {
                  const isCurrent = activeSimStep === idx;
                  const isPast = activeSimStep > idx;
                  return (
                    <button
                      key={idx}
                      onClick={() => setActiveSimStep(idx)}
                      className="flex flex-col items-center gap-1.5 group cursor-pointer focus:outline-none"
                    >
                      <div
                        className={`w-9 h-9 sm:w-11 sm:h-11 rounded-full flex items-center justify-center font-bold text-xs sm:text-sm transition-all shadow-md ${
                          isCurrent
                            ? 'bg-purple-600 text-white ring-4 ring-purple-950 border border-purple-400 scale-110'
                            : isPast
                            ? 'bg-emerald-600 text-white'
                            : 'bg-slate-800 text-slate-400 hover:bg-slate-700'
                        }`}
                      >
                        {isPast ? <CheckCircle2 className="w-5 h-5" /> : idx + 1}
                      </div>
                      <span
                        className={`text-[10px] sm:text-xs font-mono max-w-[80px] sm:max-w-[120px] text-center truncate ${
                          isCurrent ? 'text-purple-300 font-bold' : 'text-slate-400'
                        }`}
                      >
                        {step.domain}
                      </span>
                    </button>
                  );
                })}
              </div>

              {/* Connecting Bar */}
              <div className="absolute top-4 sm:top-5 left-6 right-6 h-0.5 bg-slate-800 -z-0" />
            </div>

            {/* Current Step Detailed Card */}
            {currentSimulation.steps[activeSimStep] && (
              <div className="bg-slate-950 rounded-2xl border border-purple-900/60 p-5 sm:p-6 space-y-4">
                <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 pb-3">
                  <div className="flex items-center gap-2">
                    <span className="w-7 h-7 rounded-lg bg-purple-900/80 text-purple-300 font-mono font-bold flex items-center justify-center text-xs">
                      #{currentSimulation.steps[activeSimStep].stepNumber}
                    </span>
                    <h4 className="text-base sm:text-lg font-black text-white">
                      {currentSimulation.steps[activeSimStep].title}
                    </h4>
                  </div>

                  <div>{getDomainBadge(currentSimulation.steps[activeSimStep].domain)}</div>
                </div>

                <p className="text-xs sm:text-sm text-slate-200 leading-relaxed">
                  {currentSimulation.steps[activeSimStep].description}
                </p>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-2">
                  <div className="bg-slate-900/90 rounded-xl p-3 border border-slate-800 space-y-1">
                    <div className="text-[10px] font-mono uppercase text-slate-400 font-bold flex items-center gap-1.5">
                      <Terminal className="w-3.5 h-3.5 text-purple-400" />
                      <span>Technische Uitvoering & Vectoren</span>
                    </div>
                    <div className="text-xs font-mono text-slate-300">
                      {currentSimulation.steps[activeSimStep].technicalDetails}
                    </div>
                  </div>

                  <div className="bg-slate-900/90 rounded-xl p-3 border border-slate-800 space-y-1">
                    <div className="text-[10px] font-mono uppercase text-slate-400 font-bold flex items-center gap-1.5">
                      <FileText className="w-3.5 h-3.5 text-emerald-400" />
                      <span>Bewijsstuk / Onderschept Artefact</span>
                    </div>
                    <div className="text-xs font-mono text-emerald-300">
                      {currentSimulation.steps[activeSimStep].evidenceArtifact}
                    </div>
                  </div>
                </div>

                {/* Step Navigation Controls */}
                <div className="flex items-center justify-between pt-3 border-t border-slate-800">
                  <button
                    onClick={() => setActiveSimStep(Math.max(0, activeSimStep - 1))}
                    disabled={activeSimStep === 0}
                    className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 disabled:opacity-40 disabled:cursor-not-allowed text-xs font-semibold text-white transition-all cursor-pointer"
                  >
                    Vorige stap
                  </button>

                  <div className="text-xs font-mono text-slate-400">
                    Stap {activeSimStep + 1} van {currentSimulation.steps.length}
                  </div>

                  <button
                    onClick={() =>
                      setActiveSimStep(
                        Math.min(currentSimulation.steps.length - 1, activeSimStep + 1)
                      )
                    }
                    disabled={activeSimStep === currentSimulation.steps.length - 1}
                    className="px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 disabled:opacity-40 disabled:cursor-not-allowed text-xs font-semibold text-white transition-all cursor-pointer flex items-center gap-1.5 shadow-md"
                  >
                    <span>Volgende stap</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 3: Politie & Justitie Case Studies */}
      {activeTab === 'CASE_STUDIES' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* List of Case Studies */}
          <div className="lg:col-span-5 space-y-3">
            {CRIME_CASE_STUDIES.map((study) => (
              <div
                key={study.id}
                onClick={() => setSelectedCaseStudy(study)}
                className={`p-4.5 rounded-2xl border transition-all cursor-pointer text-left ${
                  selectedCaseStudy?.id === study.id
                    ? 'bg-amber-950/60 border-amber-500 shadow-lg shadow-amber-950/40 ring-1 ring-amber-500'
                    : 'bg-slate-900 border-slate-800 hover:border-slate-700'
                }`}
              >
                <div className="flex items-center justify-between mb-1.5">
                  <span className="text-[10px] font-mono text-amber-400 font-bold">
                    {study.dateOrYear}
                  </span>
                  <span
                    className={`text-[10px] font-mono px-2 py-0.5 rounded ${
                      study.status === 'AFGEROND_VONNIS'
                        ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                        : 'bg-rose-950 text-rose-300 border border-rose-800'
                    }`}
                  >
                    {study.status.replace('_', ' ')}
                  </span>
                </div>

                <h4 className="font-extrabold text-white text-base">{study.title}</h4>
                <p className="text-xs text-slate-400 mt-1 line-clamp-2">{study.subtitle}</p>

                <div className="flex flex-wrap gap-1 mt-3">
                  {study.domainsCovered.map((d) => (
                    <span key={d}>{getDomainBadge(d)}</span>
                  ))}
                </div>
              </div>
            ))}
          </div>

          {/* Case Study Details View */}
          <div className="lg:col-span-7">
            {selectedCaseStudy && (
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 sm:p-7 shadow-xl space-y-5">
                <div className="space-y-2 border-b border-slate-800 pb-4">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="px-2.5 py-1 rounded bg-amber-950 text-amber-300 border border-amber-800 text-xs font-mono font-bold">
                      {selectedCaseStudy.dateOrYear}
                    </span>
                    <span className="text-xs text-slate-400 font-mono">
                      Betrokken diensten:{' '}
                      <strong className="text-white">
                        {selectedCaseStudy.involvedAgencies.join(' • ')}
                      </strong>
                    </span>
                  </div>

                  <h3 className="text-xl sm:text-2xl font-black text-white">
                    {selectedCaseStudy.title}
                  </h3>
                  <p className="text-xs sm:text-sm text-slate-300 font-medium">
                    {selectedCaseStudy.subtitle}
                  </p>
                </div>

                {/* Domains Covered */}
                <div className="space-y-1.5">
                  <div className="text-[10px] font-mono uppercase text-slate-400 font-bold">
                    Onderzochte Domeinen in dit Dossier:
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {selectedCaseStudy.domainsCovered.map((d) => (
                      <span key={d}>{getDomainBadge(d)}</span>
                    ))}
                  </div>
                </div>

                {/* Summary */}
                <div className="space-y-1.5">
                  <h4 className="text-xs font-mono uppercase text-slate-400 font-bold">
                    Samenvatting van het Opsporingsonderzoek
                  </h4>
                  <p className="text-xs sm:text-sm text-slate-200 leading-relaxed bg-slate-950/70 p-4 rounded-xl border border-slate-800">
                    {selectedCaseStudy.summary}
                  </p>
                </div>

                {/* Key Finding */}
                <div className="p-4 rounded-xl bg-amber-950/40 border border-amber-800/80 space-y-1.5">
                  <div className="flex items-center gap-2 text-amber-300 text-xs font-bold">
                    <Scale className="w-4 h-4" />
                    <span>Cruciale Criminologische Ontdekking</span>
                  </div>
                  <p className="text-xs text-slate-200 leading-relaxed font-medium">
                    {selectedCaseStudy.keyFinding}
                  </p>
                </div>

                {/* Tactical Lessons */}
                <div className="space-y-2">
                  <h4 className="text-xs font-mono uppercase text-slate-400 font-bold">
                    Lessen voor Cybersecurity & Rechtshandhaving
                  </h4>
                  <ul className="space-y-2">
                    {selectedCaseStudy.tacticalLessons.map((lesson, idx) => (
                      <li
                        key={idx}
                        className="flex items-start gap-2.5 text-xs text-slate-300 bg-slate-950/50 p-3 rounded-lg border border-slate-800"
                      >
                        <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                        <span>{lesson}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 4: Handreikingen & NIS2 Mitigatie */}
      {activeTab === 'MITIGATIE' && (
        <div className="space-y-6">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 sm:p-7 shadow-xl space-y-4">
            <div className="flex items-center gap-2">
              <span className="p-2 rounded-xl bg-rose-950 text-rose-400 border border-rose-800">
                <ShieldAlert className="w-5 h-5" />
              </span>
              <div>
                <h3 className="text-lg sm:text-xl font-black text-white">
                  Mitigatie & Ketenaanpak voor Vitale Sectoren (NIS2 & NCSC)
                </h3>
                <p className="text-xs sm:text-sm text-slate-400">
                  Concrete maatregelen om de synergie tussen fysieke misdaad en cybercriminaliteit te doorbreken
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
              {/* Haven & Maritieme Logistiek */}
              <div className="bg-slate-950 rounded-xl p-5 border border-slate-800 space-y-3">
                <div className="flex items-center gap-2 text-emerald-400 font-bold text-sm">
                  <Anchor className="w-4 h-4" />
                  <span>Havenbedrijven, Rederijen & Terminals</span>
                </div>
                <ul className="text-xs text-slate-300 space-y-2 leading-relaxed">
                  <li className="flex items-start gap-2">
                    <span className="text-emerald-400 font-bold">•</span>
                    <span>
                      <strong>Vertrouwensketen Implementeren:</strong> Vervang statische containercodes (pincodes) door cryptografisch getekende digitale autorisaties gekoppeld aan geverifieerde chauffeurs.
                    </span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-emerald-400 font-bold">•</span>
                    <span>
                      <strong>Hardware MFA (FIDO2/YubiKey):</strong> Geen wachtwoorden of SMS-2FA meer voor toegang tot havenapplicaties (Portbase, TOS).
                    </span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-emerald-400 font-bold">•</span>
                    <span>
                      <strong>Fysieke Poortcontrole & USB-blokkades:</strong> Blokkeer ongeautoriseerde hardware keyloggers en mini-routers op kantoorwerkstations.
                    </span>
                  </li>
                </ul>
              </div>

              {/* Financiële Instellingen & Banken */}
              <div className="bg-slate-950 rounded-xl p-5 border border-slate-800 space-y-3">
                <div className="flex items-center gap-2 text-amber-400 font-bold text-sm">
                  <CreditCard className="w-4 h-4" />
                  <span>Banken & Betalingsverkeer</span>
                </div>
                <ul className="text-xs text-slate-300 space-y-2 leading-relaxed">
                  <li className="flex items-start gap-2">
                    <span className="text-amber-400 font-bold">•</span>
                    <span>
                      <strong>Detectie Anti-Detect Browsers:</strong> Detecteer afwijkende sessies waarin gekloonde cookies (Dolphin Anty) worden ingeladen zonder hardware-consistentie.
                    </span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-amber-400 font-bold">•</span>
                    <span>
                      <strong>Geldezel Monitoring & AI Patroonherkenning:</strong> Vroegtijdige bevriezing van rekeningen van jongeren die plotseling hoge SEPA-overschrijvingen ontvangen.
                    </span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-amber-400 font-bold">•</span>
                    <span>
                      <strong>Spoofing-filter Telecom Providers:</strong> Strikte handhaving tegen ongeautoriseerde Call Line Identification (CLI) spoofing van banknummers.
                    </span>
                  </li>
                </ul>
              </div>

              {/* Post & Logistieke Koeriers */}
              <div className="bg-slate-950 rounded-xl p-5 border border-slate-800 space-y-3">
                <div className="flex items-center gap-2 text-purple-400 font-bold text-sm">
                  <Layers className="w-4 h-4" />
                  <span>Post- & Pakketdiensten (PostNL, DHL)</span>
                </div>
                <ul className="text-xs text-slate-300 space-y-2 leading-relaxed">
                  <li className="flex items-start gap-2">
                    <span className="text-purple-400 font-bold">•</span>
                    <span>
                      <strong>Cameratoezicht op Drop-boxes:</strong> Slimme monitoring bij brievenbussen in verdachte regio's (Brabant/Limburg) waar vendors massaal postorders dumpen.
                    </span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-purple-400 font-bold">•</span>
                    <span>
                      <strong>Geavanceerde Gas- en Röntgenscanners:</strong> Snelle detectie van vacuümverpakte verdovende middelen bestemd voor het buitenland.
                    </span>
                  </li>
                </ul>
              </div>

              {/* MKB & Zorg (Ransomware Protectie) */}
              <div className="bg-slate-950 rounded-xl p-5 border border-slate-800 space-y-3">
                <div className="flex items-center gap-2 text-rose-400 font-bold text-sm">
                  <Terminal className="w-4 h-4" />
                  <span>MKB, Zorg & Industrie</span>
                </div>
                <ul className="text-xs text-slate-300 space-y-2 leading-relaxed">
                  <li className="flex items-start gap-2">
                    <span className="text-rose-400 font-bold">•</span>
                    <span>
                      <strong>Patchbeleid Externe Gateways:</strong> Dicht Citrix Bleed, Fortinet en Ivanti kwetsbaarheden binnen 24 uur na openbaarmaking.
                    </span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-rose-400 font-bold">•</span>
                    <span>
                      <strong>Geen Losgeld Betalen:</strong> Betaling financiert direct drugskartels en terrorisme; overleg altijd direct met politie en verzekeraar.
                    </span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-rose-400 font-bold">•</span>
                    <span>
                      <strong>Onveranderbare (Immutable) Offline Back-ups:</strong> Garandeer herstel binnen 12 uur zonder losgeld te overwegen.
                    </span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Dedicated Crime Nexus Detail Dossier Modal */}
      {detailModalLink && (
        <div
          onClick={() => setDetailModalLink(null)}
          className="fixed inset-0 z-[70] flex items-center justify-center p-2.5 sm:p-4 bg-slate-950/85 backdrop-blur-sm animate-in fade-in duration-150"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="bg-slate-900 border border-emerald-700/80 rounded-2xl max-w-2xl w-full p-4 sm:p-6 shadow-2xl relative overflow-hidden flex flex-col max-h-[92vh]"
          >
            <div className="flex items-start justify-between gap-3 pb-4 border-b border-slate-800">
              <div className="space-y-1.5">
                <div className="flex items-center gap-2 flex-wrap">
                  {getDomainBadge(detailModalLink.sourceDomain)}
                  <ArrowRight className="w-3.5 h-3.5 text-slate-400" />
                  {getDomainBadge(detailModalLink.targetDomain)}
                  <span
                    className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded ${
                      detailModalLink.severity === 'KRITIEK'
                        ? 'bg-rose-950 text-rose-300 border border-rose-800'
                        : 'bg-amber-950 text-amber-300 border border-amber-800'
                    }`}
                  >
                    {detailModalLink.severity}
                  </span>
                </div>
                <h2 className="text-base sm:text-xl font-black text-white">
                  {detailModalLink.title}
                </h2>
              </div>

              <button
                type="button"
                onClick={() => setDetailModalLink(null)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="mt-4 flex-1 overflow-y-auto space-y-4 pr-1 text-xs">
              {/* Summary */}
              <div className="p-3.5 rounded-xl bg-slate-950/80 border border-slate-800">
                <div className="text-[10px] font-mono uppercase text-emerald-400 font-bold mb-1">
                  Samenvatting Criminologisch Verband
                </div>
                <p className="text-slate-200 leading-relaxed text-xs sm:text-sm">
                  {detailModalLink.shortSummary}
                </p>
              </div>

              {/* All Mechanisms */}
              <div className="p-3.5 rounded-xl bg-slate-950/80 border border-slate-800 space-y-2">
                <div className="text-[10px] font-mono uppercase text-slate-400 font-bold">
                  Volledige Modus Operandi & Schakels ({detailModalLink.mechanisms.length} Stappen)
                </div>
                <ul className="space-y-2">
                  {detailModalLink.mechanisms.map((m, idx) => (
                    <li key={idx} className="flex items-start gap-2 text-slate-200 leading-relaxed">
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                      <span>{m}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Real World Example & Police Operation */}
              <div className="p-3.5 rounded-xl bg-emerald-950/30 border border-emerald-800/70 space-y-2">
                <div className="flex items-center justify-between gap-2 flex-wrap">
                  <span className="flex items-center gap-1.5 text-emerald-300 font-bold">
                    <Scale className="w-4 h-4" />
                    <span>Geverifieerde Praktijkzaak (Politie / THTC / FIOD)</span>
                  </span>
                  {detailModalLink.policeOperationRef && (
                    <span className="text-[10px] font-mono bg-slate-950 text-emerald-300 px-2 py-0.5 rounded border border-emerald-800">
                      {detailModalLink.policeOperationRef}
                    </span>
                  )}
                </div>
                <p className="text-slate-200 leading-relaxed">
                  {detailModalLink.realWorldExample}
                </p>
              </div>

              {/* Impact on Netherlands */}
              <div className="p-3.5 rounded-xl bg-rose-950/30 border border-rose-800/70 space-y-1">
                <div className="text-[10px] font-mono uppercase text-rose-300 font-bold">
                  Impact op Nederland & Vitale Infrastructuur
                </div>
                <p className="text-slate-200 leading-relaxed font-medium">
                  {detailModalLink.dutchImpact}
                </p>
              </div>

              {/* Technical Vectors & Tags */}
              <div className="p-3.5 rounded-xl bg-slate-950/80 border border-slate-800 space-y-2.5">
                <div>
                  <div className="text-[10px] font-mono uppercase text-slate-400 font-bold mb-1.5">
                    Gebruikte Technische Vectoren & TTP's
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    {detailModalLink.technicalVectors.map((v, i) => (
                      <span
                        key={i}
                        className="px-2.5 py-1 rounded bg-slate-900 border border-slate-700 text-rose-300 font-mono text-[11px]"
                      >
                        {v}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="pt-2 border-t border-slate-800/80 flex flex-wrap gap-1.5">
                  {detailModalLink.tags.map((t, i) => (
                    <span
                      key={i}
                      className="px-2 py-0.5 rounded text-[10px] font-mono bg-slate-900 text-slate-400 border border-slate-800"
                    >
                      #{t}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            <div className="mt-4 pt-3 border-t border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
              <button
                type="button"
                onClick={() => {
                  setDetailModalLink(null);
                  setActiveTab('KETEN_SIMULATOR');
                }}
                className="flex items-center justify-center gap-1.5 px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold transition-colors cursor-pointer"
              >
                <Workflow className="w-4 h-4" />
                <span>Open in Keten-Simulator (Stap-voor-stap)</span>
              </button>

              <button
                type="button"
                onClick={() => setDetailModalLink(null)}
                className="px-5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold transition-colors cursor-pointer"
              >
                Sluiten
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
