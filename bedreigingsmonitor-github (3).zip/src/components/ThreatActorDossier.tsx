import React, { useState } from 'react';
import {
  Skull,
  Globe2,
  ShieldAlert,
  Terminal,
  ExternalLink,
  ChevronRight,
  Flame,
  Search,
  Filter,
} from 'lucide-react';
import { ThreatActorProfile, ThreatOrigin } from '../types/threat';
import { THREAT_ACTORS } from '../data/threatData';

interface ThreatActorDossierProps {
  onSelectActorForAi: (actor: ThreatActorProfile) => void;
}

export const ThreatActorDossier: React.FC<ThreatActorDossierProps> = ({
  onSelectActorForAi,
}) => {
  const [selectedActor, setSelectedActor] = useState<ThreatActorProfile>(THREAT_ACTORS[0]);
  const [filterOrigin, setFilterOrigin] = useState<'ALL' | ThreatOrigin>('ALL');

  const filteredActors = THREAT_ACTORS.filter((actor) => {
    if (filterOrigin === 'ALL') return true;
    return actor.origin === filterOrigin;
  });

  return (
    <div className="bg-slate-900/90 border border-slate-800 rounded-xl sm:rounded-2xl p-3.5 sm:p-5 shadow-xl">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 sm:pb-4 border-b border-slate-800 gap-3">
        <div>
          <h2 className="text-sm sm:text-base font-bold text-white flex items-center gap-2">
            <span className="p-1.5 rounded-lg bg-rose-950 text-rose-400 border border-rose-800">
              <Skull className="w-4 h-4" />
            </span>
            Dreigingsactoren Dossiers (Rusland, China, Noord-Korea, Iran & Dark Web)
          </h2>
          <p className="text-[11px] sm:text-xs text-slate-400 mt-0.5 sm:mt-1">
            Profielen van staatsgesponsorde APT-commando's en ransomware-syndicaten gericht op westerse infrastructuur
          </p>
        </div>

        {/* Filter buttons */}
        <div className="flex items-center gap-1.5 p-1 bg-slate-950 rounded-xl border border-slate-800 text-xs overflow-x-auto scrollbar-none max-w-full">
          <button
            onClick={() => setFilterOrigin('ALL')}
            className={`px-3 py-1 rounded-lg font-medium transition-colors ${
              filterOrigin === 'ALL' ? 'bg-slate-800 text-white font-bold' : 'text-slate-400 hover:text-white'
            }`}
          >
            Alle ({THREAT_ACTORS.length})
          </button>
          <button
            onClick={() => setFilterOrigin('RUSLAND')}
            className={`px-3 py-1 rounded-lg font-medium transition-colors flex items-center gap-1 ${
              filterOrigin === 'RUSLAND' ? 'bg-rose-950 text-rose-300 font-bold border border-rose-800' : 'text-slate-400 hover:text-white'
            }`}
          >
            <span>🇷🇺</span> Rusland
          </button>
          <button
            onClick={() => setFilterOrigin('CHINA')}
            className={`px-3 py-1 rounded-lg font-medium transition-colors flex items-center gap-1 ${
              filterOrigin === 'CHINA' ? 'bg-amber-950 text-amber-300 font-bold border border-amber-800' : 'text-slate-400 hover:text-white'
            }`}
          >
            <span>🇨🇳</span> China
          </button>
          <button
            onClick={() => setFilterOrigin('NOORD_KOREA')}
            className={`px-3 py-1 rounded-lg font-medium transition-colors flex items-center gap-1 ${
              filterOrigin === 'NOORD_KOREA' ? 'bg-red-950 text-red-300 font-bold border border-red-800' : 'text-slate-400 hover:text-white'
            }`}
          >
            <span>🇰🇵</span> Noord-Korea
          </button>
          <button
            onClick={() => setFilterOrigin('IRAN')}
            className={`px-3 py-1 rounded-lg font-medium transition-colors flex items-center gap-1 ${
              filterOrigin === 'IRAN' ? 'bg-emerald-950 text-emerald-300 font-bold border border-emerald-800' : 'text-slate-400 hover:text-white'
            }`}
          >
            <span>🇮🇷</span> Iran
          </button>
        </div>
      </div>

      {/* Main Grid: Actor Selection List (4 cols) & Detail Card (8 cols) */}
      <div className="mt-4 grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Actors list */}
        <div className="lg:col-span-5 space-y-2 max-h-[500px] overflow-y-auto pr-1">
          {filteredActors.map((actor) => {
            const isSelected = selectedActor.id === actor.id;
            return (
              <button
                key={actor.id}
                onClick={() => setSelectedActor(actor)}
                className={`w-full text-left p-3.5 rounded-xl border transition-all flex items-center justify-between ${
                  isSelected
                    ? 'bg-rose-950/40 border-rose-600 shadow-md shadow-rose-950/40 ring-1 ring-rose-500'
                    : 'bg-slate-950/60 border-slate-800 hover:border-slate-700 hover:bg-slate-950/90'
                }`}
              >
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-sm">
                      {actor.origin === 'RUSLAND' ? '🇷🇺' : actor.origin === 'CHINA' ? '🇨🇳' : actor.origin === 'NOORD_KOREA' ? '🇰🇵' : actor.origin === 'IRAN' ? '🇮🇷' : '🏴‍☠️'}
                    </span>
                    <span className="font-bold text-xs text-white">{actor.name}</span>
                  </div>
                  <div className="text-[11px] text-slate-400 mt-0.5 line-clamp-1">
                    {actor.sponsorship}
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <span
                    className={`text-[10px] font-mono-code font-bold px-2 py-0.5 rounded border ${
                      actor.threatLevel === 'KRITIEK'
                        ? 'bg-rose-950 text-rose-300 border-rose-800'
                        : 'bg-amber-950 text-amber-300 border-amber-800'
                    }`}
                  >
                    {actor.threatLevel}
                  </span>
                  <ChevronRight className="w-4 h-4 text-slate-600" />
                </div>
              </button>
            );
          })}
        </div>

        {/* Selected Actor Detail Dossier */}
        <div className="lg:col-span-7 bg-slate-950/80 rounded-xl sm:rounded-2xl border border-slate-800 p-3.5 sm:p-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <span className="text-base sm:text-lg">
                  {selectedActor.origin === 'RUSLAND' ? '🇷🇺' : selectedActor.origin === 'CHINA' ? '🇨🇳' : selectedActor.origin === 'NOORD_KOREA' ? '🇰🇵' : selectedActor.origin === 'IRAN' ? '🇮🇷' : '🏴‍☠️'}
                </span>
                <div>
                  <h3 className="text-sm sm:text-base font-extrabold text-white">
                    {selectedActor.name}
                  </h3>
                  <div className="text-[10px] sm:text-[11px] text-slate-400">
                    Aliassen: {selectedActor.aliases.join(', ')}
                  </div>
                </div>
              </div>

              <span className="px-2 sm:px-2.5 py-0.5 sm:py-1 rounded text-[10px] sm:text-xs font-mono-code font-bold bg-rose-950 text-rose-300 border border-rose-800 animate-pulse">
                {selectedActor.threatLevel}
              </span>
            </div>

            <p className="mt-3 text-xs text-slate-300 leading-relaxed">
              {selectedActor.description}
            </p>

            {/* Granular details grid */}
            <div className="mt-4 space-y-2.5 text-xs">
              <div className="p-2.5 sm:p-3 rounded-xl bg-slate-900 border border-slate-800">
                <span className="text-[10px] font-mono-code text-slate-400 block">STAATSSPORING & OPDRACHTGEVER</span>
                <span className="font-bold text-white mt-0.5 block">{selectedActor.sponsorship}</span>
              </div>

              <div className="p-2.5 sm:p-3 rounded-xl bg-slate-900 border border-slate-800">
                <span className="text-[10px] font-mono-code text-amber-400 block">FOCUS OP NEDERLANDSE INFRASTRUCTUUR</span>
                <span className="text-slate-200 mt-0.5 block leading-relaxed">{selectedActor.focusOnNetherlands}</span>
              </div>

              <div className="p-2.5 sm:p-3 rounded-xl bg-slate-900 border border-slate-800">
                <span className="text-[10px] font-mono-code text-slate-400 block">KENMERKENDE MALWARE & IMPLANTS</span>
                <div className="flex flex-wrap gap-1.5 mt-1">
                  {selectedActor.signatureMalware.map((mal) => (
                    <span key={mal} className="px-2 py-0.5 rounded text-[11px] font-mono-code bg-slate-950 border border-slate-800 text-rose-300">
                      {mal}
                    </span>
                  ))}
                </div>
              </div>

              <div className="p-2.5 sm:p-3 rounded-xl bg-slate-900 border border-slate-800">
                <span className="text-[10px] font-mono-code text-slate-400 block">GEËXPLOITEERDE KWETSBAARHEDEN (CVE'S)</span>
                <div className="flex flex-wrap gap-1.5 mt-1">
                  {selectedActor.cvesExploited.map((cve) => (
                    <span key={cve} className="px-2 py-0.5 rounded text-[11px] font-mono-code bg-slate-950 border border-slate-800 text-amber-300">
                      {cve}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </div>

          <div className="mt-4 sm:mt-5 pt-3 border-t border-slate-800 flex items-center justify-between gap-2">
            <span className="text-[11px] text-slate-400">Actief sinds: {selectedActor.activeSince}</span>
            <button
              onClick={() => onSelectActorForAi(selectedActor)}
              className="px-3.5 py-2 sm:py-1.5 rounded-lg bg-gradient-to-r from-rose-600 to-amber-600 hover:from-rose-500 hover:to-amber-500 text-white font-semibold text-xs transition-all shadow-md shadow-rose-950/40 min-h-[38px] sm:min-h-0"
            >
              Analyseer met AI
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
