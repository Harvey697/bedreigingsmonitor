import React from 'react';
import {
  ShieldAlert,
  Zap,
  Anchor,
  Waves,
  Wifi,
  HeartPulse,
  CreditCard,
  Building2,
  Apple,
  AlertOctagon,
  ChevronRight,
  Info,
  Plane,
  Cpu,
  FlaskConical,
  GraduationCap,
} from 'lucide-react';
import { VitalSectorDetail, VitalSectorNL } from '../types/threat';
import { VITAL_SECTORS_NL } from '../data/threatData';

interface ThreatBarometerProps {
  selectedSector: VitalSectorNL | 'ALL';
  onSelectSector: (sector: VitalSectorNL | 'ALL') => void;
}

export const ThreatBarometer: React.FC<ThreatBarometerProps> = ({
  selectedSector,
  onSelectSector,
}) => {
  const getSectorIcon = (iconName: string) => {
    switch (iconName) {
      case 'Anchor':
        return <Anchor className="w-4 h-4 text-cyan-400" />;
      case 'Zap':
        return <Zap className="w-4 h-4 text-amber-400" />;
      case 'Waves':
        return <Waves className="w-4 h-4 text-blue-400" />;
      case 'Wifi':
        return <Wifi className="w-4 h-4 text-purple-400" />;
      case 'HeartPulse':
        return <HeartPulse className="w-4 h-4 text-rose-400" />;
      case 'CreditCard':
        return <CreditCard className="w-4 h-4 text-emerald-400" />;
      case 'ShieldAlert':
        return <ShieldAlert className="w-4 h-4 text-red-400" />;
      case 'Apple':
        return <Apple className="w-4 h-4 text-orange-400" />;
      case 'Plane':
        return <Plane className="w-4 h-4 text-sky-400" />;
      case 'Cpu':
        return <Cpu className="w-4 h-4 text-emerald-300" />;
      case 'FlaskConical':
        return <FlaskConical className="w-4 h-4 text-teal-400" />;
      case 'GraduationCap':
        return <GraduationCap className="w-4 h-4 text-indigo-400" />;
      default:
        return <Building2 className="w-4 h-4 text-slate-400" />;
    }
  };

  const getSeverityBadge = (level: string) => {
    switch (level) {
      case 'KRITIEK':
        return 'bg-rose-950/80 text-rose-300 border-rose-800 animate-pulse';
      case 'HOOG':
        return 'bg-amber-950/80 text-amber-300 border-amber-800';
      case 'VERHOOGD':
        return 'bg-yellow-950/70 text-yellow-300 border-yellow-800';
      default:
        return 'bg-slate-800 text-slate-300 border-slate-700';
    }
  };

  return (
    <div className="bg-slate-900/90 border border-slate-800/90 rounded-xl p-3 sm:p-4 shadow-lg">
      {/* Compact Barometer header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-2.5 border-b border-slate-800 gap-2">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-1 rounded-md bg-rose-950 border border-rose-800 text-rose-400">
              <AlertOctagon className="w-3.5 h-3.5" />
            </span>
            <h2 className="text-xs sm:text-sm font-bold text-white tracking-tight">
              Nationaal Dreigingsbeeld Vitale Infrastructuur (NCSC Barometer)
            </h2>
          </div>
          <p className="text-[10px] sm:text-[11px] text-slate-400 mt-0.5">
            Realtime status van alle 12 beschermde vitale sectoren van Nederland (NIS2 Essentieel & Belangrijk)
          </p>
        </div>

        {/* Compact Barometer Scale Indicator */}
        <div className="grid grid-cols-4 sm:flex items-center gap-1 p-1 bg-slate-950 rounded-lg border border-slate-800 text-[9px] sm:text-[10px] font-mono-code text-center shrink-0">
          <div className="px-1.5 py-0.5 rounded text-slate-500">1. Normaal</div>
          <div className="px-1.5 py-0.5 rounded text-yellow-500 bg-yellow-950/40">2. Verhoogd</div>
          <div className="px-1.5 py-0.5 rounded font-bold text-amber-400 bg-amber-950/80 border border-amber-800/80">
            3. Ernstig
          </div>
          <div className="px-1.5 py-0.5 rounded font-extrabold text-rose-300 bg-rose-950 border border-rose-700/80 animate-pulse">
            4. KRITIEK
          </div>
        </div>
      </div>

      {/* Compact Sector Pills Grid (6 cols on desktop) */}
      <div className="mt-2.5">
        {selectedSector !== 'ALL' && (
          <div className="flex items-center justify-between gap-2 mb-2">
            <span className="text-[11px] font-semibold text-slate-400">
              Gefilterd op sector:
            </span>
            <button
              onClick={() => onSelectSector('ALL')}
              className="text-[11px] text-rose-400 hover:text-rose-300 font-semibold transition-colors cursor-pointer"
            >
              ✕ Reset filter
            </button>
          </div>
        )}

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-2">
          {VITAL_SECTORS_NL.map((sector) => {
            const isSelected = selectedSector === sector.id;
            return (
              <button
                key={sector.id}
                onClick={() => onSelectSector(isSelected ? 'ALL' : sector.id)}
                className={`text-left p-2 rounded-lg border transition-all relative overflow-hidden group flex flex-col justify-between cursor-pointer ${
                  isSelected
                    ? 'bg-rose-950/40 border-rose-600 shadow-md ring-1 ring-rose-500'
                    : 'bg-slate-950/60 border-slate-800/80 hover:border-slate-700 hover:bg-slate-950/90'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <div className="p-1 rounded bg-slate-900 border border-slate-800">
                      {getSectorIcon(sector.iconName)}
                    </div>
                    <span
                      className={`text-[8px] sm:text-[9px] font-mono-code font-bold px-1.5 py-0.2 rounded border ${getSeverityBadge(
                        sector.threatLevel
                      )}`}
                    >
                      {sector.threatLevel}
                    </span>
                  </div>

                  <div className="font-bold text-[11px] text-white truncate" title={sector.name}>
                    {sector.name}
                  </div>
                </div>

                <div className="mt-1.5 pt-1 border-t border-slate-900 flex items-center justify-between text-[9px]">
                  <span className="text-slate-400">
                    Aanvallen: <strong className="text-rose-400 font-mono-code">{sector.activeAttacksCount}</strong>
                  </span>
                  <span className="text-amber-400/90 font-mono-code font-semibold truncate">
                    NIS2
                  </span>
                </div>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
