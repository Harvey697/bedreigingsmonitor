import React, { useState } from 'react';
import {
  Skull,
  Search,
  Filter,
  Flame,
  Globe2,
  Clock,
  Coins,
  HardDrive,
  FileCode,
  ShieldCheck,
  ExternalLink,
  Sparkles,
  ChevronRight,
  AlertTriangle,
  Eye,
  Radio,
  RefreshCw,
} from 'lucide-react';
import { ThreatItem, ThreatOrigin, VitalSectorNL } from '../types/threat';
import { VITAL_SECTORS_NL } from '../data/threatData';

interface LiveDarkwebFeedProps {
  threats: ThreatItem[];
  selectedSector: VitalSectorNL | 'ALL';
  onSelectSector?: (sector: VitalSectorNL | 'ALL') => void;
  onSelectThreatForAi: (threat: ThreatItem) => void;
  onOpenDetailsModal: (threat: ThreatItem) => void;
  lastLiveSyncTime?: string;
  isSyncingLiveFeeds?: boolean;
  onSyncLiveFeeds?: () => void;
}

export const LiveDarkwebFeed: React.FC<LiveDarkwebFeedProps> = ({
  threats,
  selectedSector,
  onSelectSector,
  onSelectThreatForAi,
  onOpenDetailsModal,
  lastLiveSyncTime,
  isSyncingLiveFeeds = false,
  onSyncLiveFeeds,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [originFilter, setOriginFilter] = useState<'ALL' | 'ALBERT_HEIJN' | 'RUSLAND' | 'CHINA' | 'NOORD_KOREA' | 'IRAN' | 'DARKWEB_SYNDICAAT' | 'NL_ONLY'>('ALL');
  const [categoryFilter, setCategoryFilter] = useState<'ALL' | 'NIS2' | 'GENERAL'>('ALL');
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [itemsPerPage, setItemsPerPage] = useState<number>(8);

  const isNis2Threat = (threat: ThreatItem): boolean => {
    return threat.isDutchVitalInfra || (threat.targetSector !== 'EUROPA_BREED' && threat.targetSector !== 'INTERNATIONAAL');
  };

  const getSectorLabel = (sector: string): string => {
    switch (sector) {
      case 'HAVEN_EN_LOGISTIEK':
        return 'Haven & Maritiem (Rotterdam)';
      case 'ENERGIE_EN_NETBEHEER':
        return 'Energie & Gas (TenneT)';
      case 'WATERBEHEER_EN_DIJKEN':
        return 'Waterkeringen & Dijken';
      case 'TELECOM_EN_INTERNET':
        return 'Telecom & Datacenters (AMS-IX)';
      case 'ZORG_EN_ZIEKENHUIZEN':
        return 'Zorg & Ziekenhuizen';
      case 'FINANCIELE_SECTOR':
        return 'Financiën & Betaalverkeer (iDEAL)';
      case 'RIJKSOVERHEID_EN_DEFENSIE':
        return 'Rijksoverheid & Defensie (DigiD)';
      case 'VOEDSEL_EN_AGRO':
        return 'Voedsel & Supermarkten (Albert Heijn)';
      case 'TRANSPORT_EN_LUCHTVAART':
        return 'Transport & Luchtvaart (Schiphol)';
      case 'HIGHTECH_EN_CHIPS':
        return 'High-Tech & Chips (ASML)';
      case 'CHEMIE_EN_INDUSTRIE':
        return 'Chemie & Petrochemie (Chemelot)';
      case 'ONDERWIJS_EN_WETENSCHAP':
        return 'Onderwijs & Universiteiten (SURF)';
      default:
        return sector.replace(/_/g, ' ');
    }
  };

  const getSectorEmoji = (sectorId: string): string => {
    switch (sectorId) {
      case 'HAVEN_EN_LOGISTIEK': return '⚓';
      case 'ENERGIE_EN_NETBEHEER': return '⚡';
      case 'WATERBEHEER_EN_DIJKEN': return '🌊';
      case 'TELECOM_EN_INTERNET': return '📡';
      case 'ZORG_EN_ZIEKENHUIZEN': return '🏥';
      case 'FINANCIELE_SECTOR': return '💳';
      case 'RIJKSOVERHEID_EN_DEFENSIE': return '🛡️';
      case 'VOEDSEL_EN_AGRO': return '🛒';
      case 'TRANSPORT_EN_LUCHTVAART': return '✈️';
      case 'HIGHTECH_EN_CHIPS': return '🔬';
      case 'CHEMIE_EN_INDUSTRIE': return '🧪';
      case 'ONDERWIJS_EN_WETENSCHAP': return '🎓';
      default: return '🏢';
    }
  };

  // Filter threats
  const filteredThreats = threats.filter((threat) => {
    // NIS2 vs Algemene Cyberaanvallen filter
    if (categoryFilter === 'NIS2' && !isNis2Threat(threat)) {
      return false;
    }
    if (categoryFilter === 'GENERAL' && isNis2Threat(threat)) {
      return false;
    }

    // Sector filter
    if (selectedSector !== 'ALL' && threat.targetSector !== selectedSector) {
      return false;
    }

    // Origin / Focus filter
    if (originFilter === 'ALBERT_HEIJN') {
      const matchAH =
        threat.targetVictim.toLowerCase().includes('albert heijn') ||
        threat.title.toLowerCase().includes('albert heijn') ||
        threat.description.toLowerCase().includes('albert heijn') ||
        threat.targetSector === 'VOEDSEL_EN_AGRO';
      if (!matchAH) return false;
    }
    if (originFilter === 'RUSLAND' && threat.origin !== 'RUSLAND') return false;
    if (originFilter === 'CHINA' && threat.origin !== 'CHINA') return false;
    if (originFilter === 'NOORD_KOREA' && threat.origin !== 'NOORD_KOREA') return false;
    if (originFilter === 'IRAN' && threat.origin !== 'IRAN') return false;
    if (originFilter === 'DARKWEB_SYNDICAAT' && threat.origin !== 'DARKWEB_SYNDICAAT') return false;
    if (originFilter === 'NL_ONLY' && !threat.isDutchVitalInfra) return false;

    // Search query
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchTitle = threat.title.toLowerCase().includes(q);
      const matchActor = threat.threatActor.toLowerCase().includes(q);
      const matchVictim = threat.targetVictim.toLowerCase().includes(q);
      const matchVector = threat.attackVector.toLowerCase().includes(q);
      const matchDesc = threat.description.toLowerCase().includes(q);
      const matchSector = threat.targetSector ? getSectorLabel(threat.targetSector).toLowerCase().includes(q) : false;
      return matchTitle || matchActor || matchVictim || matchVector || matchDesc || matchSector;
    }

    return true;
  });

  const dutchThreatsCount = threats.filter((t) => t.isDutchVitalInfra).length;
  const nis2ThreatsCount = threats.filter(isNis2Threat).length;
  const generalThreatsCount = threats.filter((t) => !isNis2Threat(t)).length;

  const getSeverityBadge = (severity: string) => {
    switch (severity) {
      case 'KRITIEK':
        return 'bg-rose-950 text-rose-300 border-rose-800 font-extrabold animate-pulse';
      case 'HOOG':
        return 'bg-amber-950 text-amber-300 border-amber-800 font-bold';
      case 'VERHOOGD':
        return 'bg-yellow-950 text-yellow-300 border-yellow-800';
      default:
        return 'bg-slate-800 text-slate-300 border-slate-700';
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'AFTELLEN_PUBLICATIE':
        return 'bg-rose-950/80 text-rose-400 border-rose-800 animate-pulse';
      case 'ACTIEF_LEK':
        return 'bg-orange-950/80 text-orange-400 border-orange-800';
      case 'IN_BEHANDELING_NCSC':
        return 'bg-amber-950/80 text-amber-400 border-amber-800';
      case 'GEPUBLICEERD':
        return 'bg-purple-950/80 text-purple-400 border-purple-800';
      default:
        return 'bg-slate-800 text-slate-400 border-slate-700';
    }
  };

  return (
    <div className="bg-slate-900/90 border border-slate-800 rounded-xl sm:rounded-2xl p-3.5 sm:p-5 shadow-xl">
      {/* Header with Search and Filter bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between pb-3 sm:pb-4 border-b border-slate-800 gap-3 sm:gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-1.5 rounded-lg bg-rose-950 text-rose-400 border border-rose-800">
              <Radio className="w-4 h-4 animate-pulse" />
            </span>
            <h2 className="text-sm sm:text-base font-bold text-white tracking-tight">
              Live Dark Web Ransomware Feed & Lek-Scanner
            </h2>
          </div>
          <p className="text-[11px] sm:text-xs text-slate-400 mt-0.5 sm:mt-1">
            Realtime ontdekking van .onion afpersingspagina's, slachtoffers en staatsgerichte cyberaanvallen
          </p>
        </div>

        {/* Search & Live Sync */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 w-full md:w-auto">
          {onSyncLiveFeeds && (
            <button
              type="button"
              onClick={onSyncLiveFeeds}
              disabled={isSyncingLiveFeeds}
              className="flex items-center justify-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:bg-emerald-800 border border-emerald-400/80 text-white text-xs font-extrabold transition-all shadow-md cursor-pointer shrink-0"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isSyncingLiveFeeds ? 'animate-spin' : ''}`} />
              <span>
                {isSyncingLiveFeeds
                  ? 'Live Ophalen...'
                  : `Live Sync${lastLiveSyncTime ? ` (${lastLiveSyncTime})` : ''}`}
              </span>
            </button>
          )}
          <div className="relative w-full md:w-auto md:min-w-[260px]">
            <Search className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Zoek sector, slachtoffer (ASML, AH, Schiphol)..."
              className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-9 pr-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-rose-600 transition-colors"
            />
          </div>
        </div>
      </div>

      {/* Primary Directive Filter: NIS2 vs Algemene Cyberaanvallen */}
      <div className="mt-3.5 p-2 sm:p-2.5 rounded-xl bg-slate-950/90 border border-slate-800/90 flex flex-wrap items-center justify-between gap-2.5">
        <div className="flex items-center gap-1.5 sm:gap-2 flex-wrap">
          <span className="text-[11px] font-mono-code font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5 mr-0.5">
            <Filter className="w-3.5 h-3.5 text-rose-500" />
            <span>Classificatie:</span>
          </span>

          {/* All Threats */}
          <button
            onClick={() => setCategoryFilter('ALL')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
              categoryFilter === 'ALL'
                ? 'bg-rose-600 text-white shadow-md shadow-rose-950 ring-1 ring-rose-400'
                : 'bg-slate-900 text-slate-400 hover:text-white hover:bg-slate-800 border border-slate-800'
            }`}
          >
            <span>Alle Aanvallen</span>
            <span
              className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono-code ${
                categoryFilter === 'ALL' ? 'bg-white/20 text-white' : 'bg-slate-800 text-slate-400'
              }`}
            >
              {threats.length}
            </span>
          </button>

          {/* NIS2 Filter */}
          <button
            onClick={() => {
              setCategoryFilter('NIS2');
            }}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
              categoryFilter === 'NIS2'
                ? 'bg-emerald-600 text-white shadow-md shadow-emerald-950 ring-1 ring-emerald-400'
                : 'bg-slate-900 text-emerald-400 hover:text-emerald-200 hover:bg-slate-800 border border-emerald-900/60'
            }`}
          >
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-300" />
            <span>NIS2 Vitale Sectoren</span>
            <span
              className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono-code ${
                categoryFilter === 'NIS2'
                  ? 'bg-white/20 text-white'
                  : 'bg-emerald-950 text-emerald-300 border border-emerald-800'
              }`}
            >
              {nis2ThreatsCount}
            </span>
          </button>

          {/* General Cyberattacks Filter */}
          <button
            onClick={() => {
              setCategoryFilter('GENERAL');
              if (onSelectSector) onSelectSector('ALL');
              if (originFilter === 'NL_ONLY') setOriginFilter('ALL');
            }}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
              categoryFilter === 'GENERAL'
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-950 ring-1 ring-indigo-400'
                : 'bg-slate-900 text-indigo-300 hover:text-indigo-200 hover:bg-slate-800 border border-indigo-900/60'
            }`}
          >
            <Globe2 className="w-3.5 h-3.5 text-indigo-300" />
            <span>Algemene Cyberaanvallen</span>
            <span
              className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono-code ${
                categoryFilter === 'GENERAL'
                  ? 'bg-white/20 text-white'
                  : 'bg-indigo-950 text-indigo-300 border border-indigo-800'
              }`}
            >
              {generalThreatsCount}
            </span>
          </button>
        </div>

        <div className="text-[11px] text-slate-400 font-mono-code flex items-center gap-1.5 ml-auto sm:ml-0">
          <span>Weergave:</span>
          <span className="text-white font-bold px-2 py-0.5 rounded bg-slate-900 border border-slate-800">
            {filteredThreats.length} van {threats.length}
          </span>
        </div>
      </div>

      {/* Category Filter Active Banner */}
      {categoryFilter === 'GENERAL' && (
        <div className="mt-2.5 p-2 sm:p-2.5 rounded-xl bg-indigo-950/40 border border-indigo-800/80 flex items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2">
            <Globe2 className="w-4 h-4 text-indigo-400 shrink-0" />
            <span className="text-indigo-200 text-[11px] sm:text-xs">
              Gefilterd op <strong className="text-white">Algemene Cyberaanvallen</strong>: Bevat commerciële datalekken, consumentenplatforms, wereldwijde phishing campaigns en bedrijven buiten de vitale EU NIS2-richtlijn.
            </span>
          </div>
          <button
            onClick={() => setCategoryFilter('ALL')}
            className="px-2 py-0.5 rounded bg-indigo-900/60 hover:bg-indigo-800 text-indigo-200 font-mono-code text-[11px] shrink-0 transition-colors"
          >
            Reset
          </button>
        </div>
      )}

      {categoryFilter === 'NIS2' && (
        <div className="mt-2.5 p-2 sm:p-2.5 rounded-xl bg-emerald-950/40 border border-emerald-800/80 flex items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
            <span className="text-emerald-200 text-[11px] sm:text-xs">
              Gefilterd op <strong className="text-white">NIS2 Richtlijn (Vitale Sectoren)</strong>: Uitsluitend beschermde essentiële en belangrijke sectoren conform NCSC-NL en EU NIS2 compliance toezicht.
            </span>
          </div>
          <button
            onClick={() => setCategoryFilter('ALL')}
            className="px-2 py-0.5 rounded bg-emerald-900/60 hover:bg-emerald-800 text-emerald-200 font-mono-code text-[11px] shrink-0 transition-colors"
          >
            Reset
          </button>
        </div>
      )}

      {/* Filter Tabs - Top Origin & Priority Level */}
      <div className="mt-3 sm:mt-4 flex flex-wrap items-center justify-between gap-2 border-b border-slate-800/80 pb-3">
        <div className="flex items-center gap-1.5 overflow-x-auto scrollbar-none py-0.5 max-w-full sm:flex-wrap">
          <button
            onClick={() => {
              setOriginFilter('ALL');
              if (onSelectSector) onSelectSector('ALL');
            }}
            className={`px-3 py-1 rounded-lg text-xs font-semibold transition-colors ${
              originFilter === 'ALL' && selectedSector === 'ALL'
                ? 'bg-rose-600 text-white shadow-sm shadow-rose-950'
                : 'bg-slate-950 text-slate-400 hover:text-white border border-slate-800'
            }`}
          >
            Alle Feeds ({threats.length})
          </button>
          <button
            onClick={() => {
              setOriginFilter('NL_ONLY');
              if (onSelectSector) onSelectSector('ALL');
            }}
            className={`px-3 py-1 rounded-lg text-xs font-semibold transition-colors flex items-center gap-1.5 ${
              originFilter === 'NL_ONLY' && selectedSector === 'ALL'
                ? 'bg-amber-600 text-white shadow-sm shadow-amber-950 font-bold'
                : 'bg-slate-950 text-amber-300 hover:text-white border border-slate-800'
            }`}
          >
            <span>🇳🇱</span> Nederland Alle Sectoren ({dutchThreatsCount})
          </button>
          <button
            onClick={() => {
              setOriginFilter('ALBERT_HEIJN');
              if (onSelectSector) onSelectSector('ALL');
            }}
            className={`px-3 py-1 rounded-lg text-xs font-semibold transition-colors flex items-center gap-1.5 ${
              originFilter === 'ALBERT_HEIJN'
                ? 'bg-blue-600 text-white shadow-sm shadow-blue-950 font-bold'
                : 'bg-slate-950 text-blue-400 hover:text-white border border-slate-800'
            }`}
          >
            <span>🛒</span> Albert Heijn & Supermarkten
          </button>
          <button
            onClick={() => setOriginFilter('RUSLAND')}
            className={`px-3 py-1 rounded-lg text-xs font-semibold transition-colors flex items-center gap-1.5 ${
              originFilter === 'RUSLAND'
                ? 'bg-rose-950 text-rose-300 border border-rose-700'
                : 'bg-slate-950 text-slate-400 hover:text-white border border-slate-800'
            }`}
          >
            <span>🇷🇺</span> Focus: Rusland APT
          </button>
          <button
            onClick={() => setOriginFilter('CHINA')}
            className={`px-3 py-1 rounded-lg text-xs font-semibold transition-colors flex items-center gap-1.5 ${
              originFilter === 'CHINA'
                ? 'bg-amber-950 text-amber-300 border border-amber-700'
                : 'bg-slate-950 text-slate-400 hover:text-white border border-slate-800'
            }`}
          >
            <span>🇨🇳</span> Focus: China APT
          </button>
          <button
            onClick={() => setOriginFilter('NOORD_KOREA')}
            className={`px-3 py-1 rounded-lg text-xs font-semibold transition-colors flex items-center gap-1.5 ${
              originFilter === 'NOORD_KOREA'
                ? 'bg-red-950 text-red-300 border border-red-700'
                : 'bg-slate-950 text-slate-400 hover:text-white border border-slate-800'
            }`}
          >
            <span>🇰🇵</span> Focus: Noord-Korea APT
          </button>
          <button
            onClick={() => setOriginFilter('IRAN')}
            className={`px-3 py-1 rounded-lg text-xs font-semibold transition-colors flex items-center gap-1.5 ${
              originFilter === 'IRAN'
                ? 'bg-emerald-950 text-emerald-300 border border-emerald-700'
                : 'bg-slate-950 text-slate-400 hover:text-white border border-slate-800'
            }`}
          >
            <span>🇮🇷</span> Focus: Iran APT
          </button>
          <button
            onClick={() => setOriginFilter('DARKWEB_SYNDICAAT')}
            className={`px-3 py-1 rounded-lg text-xs font-semibold transition-colors flex items-center gap-1.5 ${
              originFilter === 'DARKWEB_SYNDICAAT'
                ? 'bg-purple-950 text-purple-300 border border-purple-700'
                : 'bg-slate-950 text-slate-400 hover:text-white border border-slate-800'
            }`}
          >
            <span>🏴‍☠️</span> Dark Web RaaS
          </button>
        </div>

        <div className="text-xs text-slate-400 font-mono-code">
          Gevonden: <strong className="text-white">{filteredThreats.length}</strong> incidenten
        </div>
      </div>

      {/* Expanded Dutch Vital Sectors Quick Filter Toolbar */}
      <div className="mt-3 pt-2 pb-3 border-b border-slate-800/60">
        <div className="flex items-center justify-between gap-2 mb-2">
          <div className="flex items-center gap-2">
            <span className="text-[11px] font-mono-code font-bold text-amber-400 flex items-center gap-1.5 uppercase tracking-wider">
              <span>🇳🇱</span> Nederland Sectoren Filter:
            </span>
            <span className="text-[10px] text-slate-400 font-mono-code">
              (Alle 12 NIS2 vitale categorieën)
            </span>
          </div>

          {(selectedSector !== 'ALL' || originFilter === 'NL_ONLY') && (
            <button
              onClick={() => {
                if (onSelectSector) onSelectSector('ALL');
                setOriginFilter('ALL');
              }}
              className="text-[11px] font-semibold text-rose-400 hover:text-rose-300 transition-colors flex items-center gap-1"
            >
              <span>✕ Reset sectorfilter</span>
            </button>
          )}
        </div>

        {/* 12 Dutch Sector Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto scrollbar-none py-1 max-w-full sm:flex-wrap">
          <button
            onClick={() => {
              setOriginFilter('NL_ONLY');
              if (onSelectSector) onSelectSector('ALL');
            }}
            className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold transition-all flex items-center gap-1.5 shrink-0 ${
              selectedSector === 'ALL' && originFilter === 'NL_ONLY'
                ? 'bg-amber-600 text-white shadow-sm ring-1 ring-amber-400 font-bold'
                : 'bg-slate-950/80 text-amber-300 hover:text-white hover:bg-slate-800 border border-amber-900/50'
            }`}
          >
            <span>🇳🇱</span> Alle NL Sectoren
            <span className="bg-amber-950 text-amber-200 text-[10px] px-1 py-0.2 rounded font-mono-code border border-amber-800">
              {dutchThreatsCount}
            </span>
          </button>

          {VITAL_SECTORS_NL.map((sector) => {
            const isSelected = selectedSector === sector.id;
            const count = threats.filter((t) => t.targetSector === sector.id).length;
            return (
              <button
                key={sector.id}
                onClick={() => {
                  if (onSelectSector) {
                    onSelectSector(isSelected ? 'ALL' : sector.id);
                  }
                  if (originFilter === 'NL_ONLY') {
                    setOriginFilter('ALL');
                  }
                }}
                className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold transition-all flex items-center gap-1.5 ${
                  isSelected
                    ? 'bg-rose-600 text-white shadow-md shadow-rose-950 ring-1 ring-rose-400 font-bold'
                    : 'bg-slate-950/70 text-slate-300 hover:text-white hover:bg-slate-800 border border-slate-800'
                }`}
              >
                <span>{getSectorEmoji(sector.id)}</span>
                <span className="truncate max-w-[170px]">{sector.name.split('(')[0].trim()}</span>
                <span
                  className={`text-[10px] px-1 py-0.2 rounded font-mono-code ${
                    isSelected
                      ? 'bg-white/20 text-white'
                      : count > 0
                      ? 'bg-rose-950 text-rose-300 border border-rose-800'
                      : 'bg-slate-900 text-slate-500'
                  }`}
                >
                  {count}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Active Sector Banner */}
      {selectedSector !== 'ALL' && (
        <div className="mt-3 p-2.5 rounded-xl bg-amber-950/40 border border-amber-800/80 flex items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2">
            <span className="text-base">{getSectorEmoji(selectedSector)}</span>
            <span className="text-amber-200">
              Gefilterd op Nederlandse sector:{' '}
              <strong className="text-white font-bold">{getSectorLabel(selectedSector)}</strong>{' '}
              ({filteredThreats.length} actieve dreigingen gevonden)
            </span>
          </div>
          <button
            onClick={() => onSelectSector && onSelectSector('ALL')}
            className="px-2 py-0.5 rounded bg-amber-900/60 hover:bg-amber-800 text-amber-200 font-mono-code text-[11px] transition-colors"
          >
            Wis sectorfilter
          </button>
        </div>
      )}

      {/* Top Pagination & Page Size Bar */}
      {filteredThreats.length > 0 && (() => {
        const totalPages = Math.max(1, Math.ceil(filteredThreats.length / itemsPerPage));
        const safePage = Math.min(currentPage, totalPages);
        const startIdx = (safePage - 1) * itemsPerPage + 1;
        const endIdx = Math.min(safePage * itemsPerPage, filteredThreats.length);
        return (
          <div className="mt-4 p-3 rounded-xl bg-slate-950/95 border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 text-xs">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="font-mono-code font-bold text-rose-300 bg-rose-950/90 border border-rose-800 px-2.5 py-1 rounded-lg">
                📄 Pagina {safePage} van {totalPages}
              </span>
              <span className="text-slate-400">
                Melding <strong className="text-white">{startIdx}–{endIdx}</strong> van{' '}
                <strong className="text-white">{filteredThreats.length}</strong> incidenten
              </span>
            </div>

            <div className="flex items-center gap-1.5 flex-wrap">
              <button
                type="button"
                disabled={safePage <= 1}
                onClick={() => setCurrentPage(Math.max(1, safePage - 1))}
                className="px-2.5 py-1 rounded-lg bg-slate-900 hover:bg-slate-800 disabled:opacity-40 text-slate-200 border border-slate-700 font-bold cursor-pointer"
              >
                ← Vorige
              </button>
              {Array.from({ length: totalPages }, (_, idx) => idx + 1).map((pageNum) => (
                <button
                  key={pageNum}
                  type="button"
                  onClick={() => setCurrentPage(pageNum)}
                  className={`w-7 h-7 rounded-lg font-mono-code font-bold transition-all cursor-pointer ${
                    pageNum === safePage
                      ? 'bg-rose-600 text-white shadow-sm shadow-rose-950 border border-rose-400'
                      : 'bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800'
                  }`}
                >
                  {pageNum}
                </button>
              ))}
              <button
                type="button"
                disabled={safePage >= totalPages}
                onClick={() => setCurrentPage(Math.min(totalPages, safePage + 1))}
                className="px-2.5 py-1 rounded-lg bg-slate-900 hover:bg-slate-800 disabled:opacity-40 text-slate-200 border border-slate-700 font-bold cursor-pointer"
              >
                Volgende →
              </button>

              <select
                value={itemsPerPage}
                onChange={(e) => {
                  setItemsPerPage(Number(e.target.value));
                  setCurrentPage(1);
                }}
                className="ml-1 bg-slate-900 border border-slate-700 rounded-lg px-2 py-1 text-[11px] text-slate-200 font-mono-code focus:outline-none"
                title="Aantal meldingen per pagina"
              >
                <option value={6}>6 / pagina</option>
                <option value={8}>8 / pagina</option>
                <option value={15}>15 / pagina</option>
                <option value={999}>Alles op 1 pagina</option>
              </select>
            </div>
          </div>
        );
      })()}

      {/* Threats Feed Cards List */}
      <div className="mt-4 space-y-3.5">
        {filteredThreats.length === 0 ? (
          <div className="text-center py-12 bg-slate-950/40 rounded-xl border border-slate-800 text-slate-400 text-xs">
            Geen dreigingen gevonden voor de geselecteerde sector(en). Probeer een andere sector of reset het filter.
          </div>
        ) : (
          filteredThreats
            .slice(
              (Math.min(currentPage, Math.max(1, Math.ceil(filteredThreats.length / itemsPerPage))) - 1) * itemsPerPage,
              Math.min(currentPage, Math.max(1, Math.ceil(filteredThreats.length / itemsPerPage))) * itemsPerPage
            )
            .map((threat) => (
            <div
              key={threat.id}
              className={`p-4 rounded-xl border transition-all ${
                threat.severity === 'KRITIEK'
                  ? 'bg-slate-950/80 border-rose-900/60 hover:border-rose-700 shadow-md shadow-rose-950/20'
                  : 'bg-slate-950/60 border-slate-800/80 hover:border-slate-700'
              }`}
            >
              {/* Card top row */}
              <div className="flex flex-wrap items-center justify-between gap-2 pb-2.5 border-b border-slate-900">
                <div className="flex flex-wrap items-center gap-2">
                  <span
                    className={`text-[10px] font-mono-code px-2 py-0.5 rounded border ${getSeverityBadge(
                      threat.severity
                    )}`}
                  >
                    {threat.severity}
                  </span>

                  <span className="text-xs font-bold text-slate-300 flex items-center gap-1">
                    <span>{threat.originFlag}</span>
                    <span className="text-white">{threat.threatActor}</span>
                  </span>

                  <span className="text-slate-600">•</span>

                  <span
                    className={`text-[10px] font-mono-code px-2 py-0.5 rounded border ${getStatusBadge(
                      threat.leakStatus
                    )}`}
                  >
                    {threat.leakStatus.replace(/_/g, ' ')}
                  </span>

                  {isNis2Threat(threat) ? (
                    <span className="text-[10px] font-mono-code font-bold bg-emerald-950/90 text-emerald-300 border border-emerald-700/80 px-2 py-0.5 rounded flex items-center gap-1 shadow-sm">
                      <ShieldCheck className="w-3 h-3 text-emerald-400" />
                      <span>NIS2 VITAAL</span>
                    </span>
                  ) : (
                    <span className="text-[10px] font-mono-code font-bold bg-indigo-950/90 text-indigo-300 border border-indigo-700/80 px-2 py-0.5 rounded flex items-center gap-1 shadow-sm">
                      <Globe2 className="w-3 h-3 text-indigo-400" />
                      <span>ALGEMENE AANVAL</span>
                    </span>
                  )}

                  {threat.isDutchVitalInfra && (
                    <span className="text-[10px] font-mono-code font-bold bg-amber-950/90 text-amber-300 border border-amber-800 px-2 py-0.5 rounded">
                      🇳🇱 VITALE INFRASTRUCTUUR
                    </span>
                  )}

                  {threat.targetSector && (
                    <button
                      onClick={() => onSelectSector && onSelectSector(threat.targetSector as VitalSectorNL)}
                      className="text-[10px] font-mono-code font-bold bg-slate-900 text-cyan-300 border border-slate-700 hover:border-cyan-500 hover:bg-slate-800 px-2 py-0.5 rounded flex items-center gap-1 transition-colors"
                      title="Klik om te filteren op deze sector"
                    >
                      <span>{getSectorEmoji(threat.targetSector)}</span>
                      <span>{getSectorLabel(threat.targetSector)}</span>
                    </button>
                  )}

                  {(threat.targetVictim.toLowerCase().includes('albert heijn') || threat.title.toLowerCase().includes('albert heijn')) && (
                    <span className="text-[10px] font-mono-code font-bold bg-blue-950/90 text-blue-300 border border-blue-700 px-2 py-0.5 rounded flex items-center gap-1">
                      🛒 ALBERT HEIJN SUPPLY CHAIN
                    </span>
                  )}

                  {/* Realtime Cyber Attack in Progress badge */}
                  <span className="text-[10px] font-mono-code font-extrabold bg-rose-950 text-rose-300 border border-rose-800 px-2 py-0.5 rounded flex items-center gap-1.5 shadow-sm shadow-rose-950 animate-pulse">
                    <span className="relative flex h-2 w-2">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75"></span>
                      <span className="relative inline-flex rounded-full h-2 w-2 bg-rose-500"></span>
                    </span>
                    {threat.realtimeStatus === 'AANVAL_NU_ACTIEF' ? 'LIVE AANVAL ACTIEF' :
                     threat.realtimeStatus === 'DATA_EXFILTRATIE_LIVE' ? 'EXFILTRATIE BEZIG' :
                     threat.realtimeStatus === 'ENCRYPTIE_IN_UITVOERING' ? 'ENCRYPTIE ACTIEF' : 'C2 LIVE'}
                  </span>
                </div>

                {/* Explicit Date and Time display */}
                <div className="flex items-center gap-2 text-[11px] font-mono-code text-slate-300 bg-slate-900/90 px-2.5 py-1 rounded-lg border border-slate-800">
                  <span className="text-amber-400 font-bold flex items-center gap-1">
                    📅 {threat.attackDate || '13 oktober 2026'}
                  </span>
                  <span className="text-slate-500">•</span>
                  <span className="text-slate-300 flex items-center gap-1">
                    <Clock className="w-3 h-3 text-slate-400" />
                    {threat.attackTime || threat.timestamp}
                  </span>
                </div>
              </div>

              {/* Title & Target Details */}
              <div className="mt-3">
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-[10px] font-mono-code font-semibold px-2 py-0.2 rounded bg-rose-950/60 border border-rose-900/70 text-rose-300">
                    REALTIME DOELWIT
                  </span>
                  {threat.liveTelemetryMetrics?.packetsPerSec && (
                    <span className="text-[10px] font-mono-code text-cyan-300 bg-slate-900 px-2 py-0.2 rounded border border-slate-800">
                      Telemetrie: {threat.liveTelemetryMetrics.packetsPerSec}
                    </span>
                  )}
                </div>
                <h3 className="text-sm font-bold text-white hover:text-rose-400 transition-colors cursor-pointer"
                    onClick={() => onOpenDetailsModal(threat)}>
                  {threat.title}
                </h3>

                <p className="mt-1.5 text-xs text-slate-300 line-clamp-2">
                  {threat.description}
                </p>
              </div>

              {/* Technical indicators strip: 2 columns on mobile (just like tablet!), 4 on desktop */}
              <div className="mt-3.5 grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-4 gap-2 text-xs">
                {/* Target Victim */}
                <div className="p-2 rounded-lg bg-slate-900/80 border border-slate-800/80">
                  <span className="text-[10px] text-slate-400 block font-mono-code">DOELWIT / SECTOR</span>
                  <span className="font-semibold text-slate-200 truncate block text-[11px] sm:text-xs">
                    {threat.targetVictim}
                  </span>
                </div>

                {/* Vector / CVE */}
                <div className="p-2 rounded-lg bg-slate-900/80 border border-slate-800/80">
                  <span className="text-[10px] text-slate-400 block font-mono-code">AANVALSVECTOR</span>
                  <span className="font-mono-code text-rose-300 truncate block text-[11px]">
                    {threat.attackVector}
                  </span>
                </div>

                {/* Darkweb Onion link */}
                <div className="p-2 rounded-lg bg-slate-900/80 border border-slate-800/80">
                  <span className="text-[10px] text-slate-400 block font-mono-code">DARKWEB .ONION ADRES</span>
                  <span className="font-mono-code text-purple-300 truncate block text-[11px]">
                    {threat.darkwebOnionSite || 'N.v.t. (Spionage/Wiper)'}
                  </span>
                </div>

                {/* Ransom / Volume */}
                <div className="p-2 rounded-lg bg-slate-900/80 border border-slate-800/80">
                  <span className="text-[10px] text-slate-400 block font-mono-code">LOSGELD / VOLUME</span>
                  <span className="font-mono-code text-amber-300 truncate block text-[11px]">
                    {threat.ransomDemanded || threat.dataVolume || 'Onbekend'}
                  </span>
                </div>
              </div>

              {/* Action buttons */}
              <div className="mt-3.5 pt-3 border-t border-slate-900 flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
                <div className="flex items-center gap-2 text-[11px] text-slate-400 font-mono-code flex-wrap">
                  <span>Locatie: <strong className="text-slate-300">{threat.targetLocation}</strong></span>
                  {threat.verifiedByCsirt && (
                    <span className="flex items-center gap-1 text-emerald-400">
                      <ShieldCheck className="w-3.5 h-3.5" /> Geverifieerd CSIRT
                    </span>
                  )}
                </div>

                <div className="flex items-center gap-2 w-full sm:w-auto">
                  <button
                    type="button"
                    onClick={() => onOpenDetailsModal(threat)}
                    className="flex-1 sm:flex-initial flex items-center justify-center gap-1.5 px-3 py-2 sm:py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold transition-colors border border-slate-600 min-h-[38px] sm:min-h-0 cursor-pointer shadow-sm"
                  >
                    <Eye className="w-3.5 h-3.5 text-cyan-400" />
                    <span>Details & Dossier</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => onSelectThreatForAi(threat)}
                    className="flex-1 sm:flex-initial flex items-center justify-center gap-1.5 px-3 py-2 sm:py-1.5 rounded-lg bg-gradient-to-r from-rose-600 to-amber-600 hover:from-rose-500 hover:to-amber-500 text-white text-xs font-bold transition-all shadow-md shadow-rose-950/40 min-h-[38px] sm:min-h-0 cursor-pointer"
                    title="Genereer instant AI incident advies via Gemini 3.8 Flash"
                  >
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>NCSC AI Analyse</span>
                  </button>
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Bottom Pagination Bar */}
      {filteredThreats.length > itemsPerPage && (() => {
        const totalPages = Math.max(1, Math.ceil(filteredThreats.length / itemsPerPage));
        const safePage = Math.min(currentPage, totalPages);
        return (
          <div className="mt-4 pt-3 border-t border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 text-xs">
            <span className="text-slate-400 font-mono-code">
              Pagina <strong className="text-white">{safePage}</strong> van <strong className="text-white">{totalPages}</strong> ({filteredThreats.length} incidenten totaal)
            </span>
            <div className="flex items-center gap-1.5 flex-wrap">
              <button
                type="button"
                disabled={safePage <= 1}
                onClick={() => setCurrentPage(Math.max(1, safePage - 1))}
                className="px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 disabled:opacity-40 text-slate-200 border border-slate-700 font-bold cursor-pointer"
              >
                ← Vorige Pagina
              </button>
              {Array.from({ length: totalPages }, (_, idx) => idx + 1).map((pageNum) => (
                <button
                  key={pageNum}
                  type="button"
                  onClick={() => setCurrentPage(pageNum)}
                  className={`w-7 h-7 rounded-lg font-mono-code font-bold transition-all cursor-pointer ${
                    pageNum === safePage
                      ? 'bg-rose-600 text-white shadow-sm shadow-rose-950 border border-rose-400'
                      : 'bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800'
                  }`}
                >
                  {pageNum}
                </button>
              ))}
              <button
                type="button"
                disabled={safePage >= totalPages}
                onClick={() => setCurrentPage(Math.min(totalPages, safePage + 1))}
                className="px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 disabled:opacity-40 text-slate-200 border border-slate-700 font-bold cursor-pointer"
              >
                Volgende Pagina →
              </button>
            </div>
          </div>
        );
      })()}
    </div>
  );
};
