import React from 'react';
import {
  ShieldAlert,
  X,
  ExternalLink,
  Sparkles,
  FileCheck2,
  Clock,
  Coins,
  HardDrive,
  FileCode,
  MapPin,
  CheckCircle2,
  MessageSquare,
} from 'lucide-react';
import { ThreatItem } from '../types/threat';

interface ThreatDetailModalProps {
  threat: ThreatItem | null;
  isOpen: boolean;
  onClose: () => void;
  onOpenAiAnalysis: (threat: ThreatItem) => void;
  onOpenVerification: (threat: ThreatItem) => void;
  onAskQuestion?: (threat: ThreatItem) => void;
}

export const ThreatDetailModal: React.FC<ThreatDetailModalProps> = ({
  threat,
  isOpen,
  onClose,
  onOpenAiAnalysis,
  onOpenVerification,
  onAskQuestion,
}) => {
  if (!isOpen || !threat) return null;

  const sources = Array.isArray(threat.verificationSources) ? threat.verificationSources : [];
  const verifiedSourcesCount = sources.length > 0 ? sources.filter((s) => s.verified).length : 3;
  const mitreList = Array.isArray(threat.mitreTechniques) ? threat.mitreTechniques : ['T1190 - Exploit Public-Facing Application'];
  const leakStatusText = (threat.leakStatus || 'IN_ONDERZOEK').replace(/_/g, ' ');

  return (
    <div
      onClick={onClose}
      className="fixed inset-0 z-[60] flex items-center justify-center p-2.5 sm:p-4 bg-slate-950/85 backdrop-blur-sm animate-in fade-in duration-150"
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="bg-slate-900 border border-slate-700 rounded-xl sm:rounded-2xl max-w-2xl w-full p-3.5 sm:p-6 shadow-2xl relative overflow-hidden flex flex-col max-h-[92vh]"
      >
        {/* Glow ambient background */}
        <div className="absolute -top-24 -right-24 w-48 h-48 bg-rose-600/15 rounded-full blur-3xl pointer-events-none" />

        {/* Modal Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-rose-950 border border-rose-800 text-rose-400">
              <ShieldAlert className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-mono-code font-extrabold bg-rose-950 text-rose-300 border border-rose-800 px-2 py-0.5 rounded">
                  {threat.severity}
                </span>
                <span className="text-xs font-bold text-white flex items-center gap-1">
                  <span>{threat.originFlag}</span>
                  <span>{threat.threatActor}</span>
                </span>
              </div>
              <h2 className="text-base font-extrabold text-white mt-1">
                {threat.title}
              </h2>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="mt-4 flex-1 overflow-y-auto space-y-4 pr-1">
          {/* Realtime Cyber Attack & Explicit Date Strip */}
          <div className="p-3.5 rounded-xl bg-gradient-to-r from-rose-950/80 via-slate-950 to-slate-900 border border-rose-800/80 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-2">
              <span className="relative flex h-2.5 w-2.5">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-rose-500"></span>
              </span>
              <div>
                <span className="font-mono-code font-extrabold text-rose-300 block">
                  ACTUEEL INCIDENT & DREIGINGSDOSSIER
                </span>
                <span className="text-[11px] text-slate-400">
                  {threat.liveTelemetryMetrics?.packetsPerSec || 'C2 telemetrie gemonitord door CSIRT-NL'}
                </span>
              </div>
            </div>

            <div className="flex items-center gap-2 font-mono-code text-[11px] text-amber-300 bg-slate-950 px-3 py-1.5 rounded-lg border border-slate-800">
              <span>📅 {threat.attackDate || 'Vandaag'}</span>
              <span>•</span>
              <span className="text-slate-200">⏰ {threat.attackTime || threat.timestamp}</span>
            </div>
          </div>

          {/* Target & Verification Quick Strip */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800">
              <span className="text-[10px] font-mono-code text-slate-400 block">DOELWIT & LOCATIE</span>
              <span className="text-xs font-bold text-white mt-0.5 block truncate">
                {threat.targetVictim}
              </span>
              <span className="text-[11px] text-slate-400 flex items-center gap-1 mt-0.5">
                <MapPin className="w-3 h-3 text-slate-500" />
                {threat.targetLocation}
              </span>
            </div>

            <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800">
              <span className="text-[10px] font-mono-code text-slate-400 block">STATUS OP DARK WEB</span>
              <span className="text-xs font-bold text-amber-300 mt-0.5 block">
                {leakStatusText}
              </span>
              <span className="text-[11px] text-purple-300 font-mono-code truncate block mt-0.5">
                {threat.darkwebOnionSite || 'Geen publiek .onion lek'}
              </span>
            </div>

            <button
              type="button"
              onClick={() => onOpenVerification(threat)}
              className="p-3 rounded-xl bg-slate-950/70 border border-emerald-900/60 hover:border-emerald-500 text-left cursor-pointer transition-colors"
            >
              <span className="text-[10px] font-mono-code text-emerald-400 flex items-center justify-between">
                <span>MEERVOUDIGE BRONNEN</span>
                <CheckCircle2 className="w-3 h-3 text-emerald-400" />
              </span>
              <span className="text-xs font-bold text-emerald-300 mt-0.5 block">
                {verifiedSourcesCount} Bronnen Bevestigd
              </span>
              <span className="text-[11px] text-emerald-400/90 mt-0.5 block font-semibold">
                Klik voor verificatiebewijs →
              </span>
            </button>
          </div>

          {/* Description */}
          <div className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-800">
            <h4 className="text-xs font-bold text-slate-200 mb-1">Uitgebreide Incident Omschrijving & Analyse</h4>
            <p className="text-xs text-slate-300 leading-relaxed">
              {threat.description}
            </p>
          </div>

          {/* Attack Vector & MITRE ATT&CK */}
          <div className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-800">
            <h4 className="text-xs font-bold text-slate-200 mb-2">Aanvalsvector & MITRE ATT&CK TTPs</h4>
            <div className="text-xs font-mono-code text-rose-300 mb-2">
              Exploit / Vector: {threat.attackVector}
            </div>
            <div className="flex flex-wrap gap-1.5">
              {mitreList.map((tech) => (
                <span
                  key={tech}
                  className="px-2 py-0.5 rounded text-[11px] font-mono-code bg-slate-900 border border-slate-800 text-slate-300"
                >
                  {tech}
                </span>
              ))}
            </div>
          </div>

          {/* Inline Verification Sources Summary */}
          {sources.length > 0 && (
            <div className="p-3.5 rounded-xl bg-slate-950/60 border border-emerald-900/50 space-y-2">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-bold text-emerald-300 flex items-center gap-1.5">
                  <FileCheck2 className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Bevestigde Verificatiebronnen ({verifiedSourcesCount}/{sources.length})</span>
                </h4>
                <span className="text-[10px] font-mono-code text-emerald-400 bg-emerald-950/80 px-2 py-0.5 rounded border border-emerald-800">
                  {threat.verificationConfidenceScore || 94}% Betrouwbaarheid
                </span>
              </div>
              <div className="space-y-1.5">
                {sources.map((src) => (
                  <div
                    key={src.id}
                    className="p-2.5 rounded-lg bg-slate-900/90 border border-slate-800 text-xs flex flex-col gap-1"
                  >
                    <div className="flex items-center justify-between gap-2">
                      <span className="font-bold text-white">{src.sourceName}</span>
                      <span className="text-[10px] font-mono-code text-emerald-400">
                        ✓ {src.confidence} ({src.timestamp})
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-300 leading-relaxed">{src.evidenceSummary}</p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Indicators of Compromise (IoCs) */}
          {threat.iocs && (
            <div className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-800 space-y-2">
              <h4 className="text-xs font-bold text-slate-200">Gedetecteerde IoC's (Indicatoren van Inbreuk)</h4>

              {threat.iocs.cves && threat.iocs.cves.length > 0 && (
                <div className="text-xs">
                  <span className="text-slate-400">Kwetsbaarheden (CVE): </span>
                  <span className="font-mono-code text-amber-300">{threat.iocs.cves.join(', ')}</span>
                </div>
              )}

              {threat.iocs.ips && threat.iocs.ips.length > 0 && (
                <div className="text-xs">
                  <span className="text-slate-400">Kwaadaardige IP-ranges: </span>
                  <span className="font-mono-code text-rose-300">{threat.iocs.ips.join(', ')}</span>
                </div>
              )}

              {threat.iocs.sha256 && threat.iocs.sha256.length > 0 && (
                <div className="text-xs">
                  <span className="text-slate-400">File Hashes (SHA-256): </span>
                  <span className="font-mono-code text-cyan-300 text-[11px] truncate block">
                    {threat.iocs.sha256.join(', ')}
                  </span>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Footer actions */}
        <div className="mt-3.5 pt-3 sm:pt-4 border-t border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
          <div className="flex items-center gap-2 flex-wrap">
            <button
              type="button"
              onClick={() => onOpenVerification(threat)}
              className="flex items-center justify-center gap-1.5 px-3 py-2 sm:py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 transition-colors min-h-[38px] sm:min-h-0 cursor-pointer"
            >
              <FileCheck2 className="w-3.5 h-3.5 text-emerald-400" />
              <span>Bekijk Bronnen ({verifiedSourcesCount})</span>
            </button>

            {onAskQuestion && (
              <button
                type="button"
                onClick={() => onAskQuestion(threat)}
                className="flex items-center justify-center gap-1.5 px-3 py-2 sm:py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 hover:border-amber-500 text-amber-300 hover:text-white text-xs font-semibold border border-slate-700 transition-colors min-h-[38px] sm:min-h-0 cursor-pointer"
                title="Stel een vraag of melding over deze specifieke dreiging aan de beheerder"
              >
                <MessageSquare className="w-3.5 h-3.5 text-amber-400" />
                <span>Vraag aan Beheerder</span>
              </button>
            )}
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            <button
              type="button"
              onClick={() => onOpenAiAnalysis(threat)}
              className="flex-1 sm:flex-initial flex items-center justify-center gap-1.5 px-4 py-2 sm:py-1.5 rounded-xl bg-gradient-to-r from-rose-600 to-amber-600 hover:from-rose-500 hover:to-amber-500 text-white text-xs font-bold transition-all shadow-md shadow-rose-950/40 min-h-[38px] sm:min-h-0 cursor-pointer"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>NCSC AI Analyse</span>
            </button>
            <button
              type="button"
              onClick={onClose}
              className="px-3.5 py-2 sm:py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 transition-colors cursor-pointer"
            >
              Sluiten
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
