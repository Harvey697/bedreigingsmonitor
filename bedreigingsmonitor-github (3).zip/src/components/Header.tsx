import React, { useState, useEffect } from 'react';
import {
  ShieldAlert,
  Bell,
  BellOff,
  Volume2,
  VolumeX,
  Radio,
  Lock,
  Flame,
  Clock,
  Sparkles,
  FileText,
  MessageSquare,
  RefreshCw,
} from 'lucide-react';
import { NotificationSettings } from '../types/threat';

interface HeaderProps {
  settings: NotificationSettings;
  onUpdateSettings: (newSettings: NotificationSettings) => void;
  onOpenNotificationModal: () => void;
  onTestNotification: () => void;
  onOpenPdfModal?: () => void;
  activeThreatsCount: number;
  dutchVitalCount: number;
  isOwnerMode?: boolean;
  onToggleOwnerMode?: () => void;
  onOpenFeedbackModal?: () => void;
  unreadFeedbackCount?: number;
  lastLiveSyncTime?: string;
  isSyncingLiveFeeds?: boolean;
  onSyncLiveFeeds?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  settings,
  onUpdateSettings,
  onOpenNotificationModal,
  onTestNotification,
  onOpenPdfModal,
  activeThreatsCount,
  dutchVitalCount,
  isOwnerMode = false,
  onToggleOwnerMode,
  onOpenFeedbackModal,
  unreadFeedbackCount = 0,
  lastLiveSyncTime,
  isSyncingLiveFeeds = false,
  onSyncLiveFeeds,
}) => {
  const [timeStr, setTimeStr] = useState<string>('');
  const [dateStr, setDateStr] = useState<string>('');

  useEffect(() => {
    const updateClock = () => {
      const now = new Date();
      setTimeStr(
        now.toLocaleTimeString('nl-NL', {
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit',
        })
      );
      setDateStr(
        now.toLocaleDateString('nl-NL', {
          day: 'numeric',
          month: 'long',
          year: 'numeric',
        })
      );
    };
    updateClock();
    const interval = setInterval(updateClock, 1000);
    return () => clearInterval(interval);
  }, []);

  const toggleSound = () => {
    onUpdateSettings({ ...settings, soundEnabled: !settings.soundEnabled });
  };

  return (
    <header className="border-b border-slate-800 bg-slate-950/95 backdrop-blur-md sticky top-0 z-40">
      {/* Main navigation & stats bar */}
      <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 py-3">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3">
          {/* Brand identity */}
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-500 via-teal-500 to-cyan-600 p-0.5 shadow-lg shadow-emerald-950/50 flex items-center justify-center shrink-0">
                <div className="w-full h-full bg-slate-950 rounded-[10px] flex items-center justify-center">
                  <ShieldAlert className="w-5 h-5 text-emerald-400" />
                </div>
              </div>
              <div>
                <div className="flex items-center gap-2 flex-wrap">
                  <h1 className="font-black text-lg sm:text-2xl text-white tracking-tight flex items-center gap-0.5">
                    Bedreigingsmonitor<span className="text-emerald-400">.nl</span>
                  </h1>
                  <span className="bg-emerald-950/90 text-emerald-300 border border-emerald-700 px-2 py-0.5 rounded-md text-[10px] font-bold uppercase tracking-wider font-mono-code shadow-sm">
                    WEERBAARHEID &amp; ADVIES
                  </span>
                </div>
              </div>
            </div>

            {/* Compact badges on small mobile screens */}
            <div className="flex sm:hidden items-center gap-1.5 text-xs font-mono-code">
              <span className="bg-slate-900 border border-slate-800 rounded px-2 py-1 text-rose-400 font-bold" title="Actieve Dreigingen">
                ⚠️ {activeThreatsCount}
              </span>
              <span className="bg-amber-950/70 border border-amber-900/60 rounded px-2 py-1 text-amber-300 font-bold" title="NL Vitale Infra">
                🇳🇱 {dutchVitalCount}
              </span>
            </div>
          </div>

          {/* Tactical quick badges & actions */}
          <div className="flex items-center flex-wrap gap-1.5 sm:gap-2 lg:justify-end">
            {/* Live date & time (zichtbaar op zowel mobiel als desktop) */}
            <div className="flex items-center gap-1.5 sm:gap-2 bg-slate-900 border border-slate-800 rounded-xl px-2.5 sm:px-3 py-1 sm:py-1.5 text-[11px] sm:text-xs font-mono-code shrink-0 shadow-sm">
              <span className="text-slate-300 hidden sm:inline">📅 {dateStr}</span>
              <span className="text-slate-600 hidden sm:inline">•</span>
              <span className="text-emerald-400 flex items-center gap-1 font-bold">
                <Radio className="w-3 h-3 text-emerald-400 animate-pulse" />
                <span>{timeStr || '--:--'} CET</span>
              </span>
            </div>

            {/* Prominente Live Sync knop (direct zichtbaar op mobiel & desktop) */}
            {onSyncLiveFeeds && (
              <button
                type="button"
                onClick={onSyncLiveFeeds}
                disabled={isSyncingLiveFeeds}
                className="flex items-center gap-1.5 px-3 py-1 sm:py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:bg-emerald-800 border border-emerald-400/80 text-[11px] sm:text-xs font-mono-code text-white font-extrabold transition-all shadow-md shadow-emerald-950/60 shrink-0 cursor-pointer"
                title="Direct live feeds synchroniseren (Security.NL, NCSC-NL, DIVD, CISA)"
              >
                <RefreshCw className={`w-3.5 h-3.5 text-white ${isSyncingLiveFeeds ? 'animate-spin' : ''}`} />
                <span>
                  {isSyncingLiveFeeds
                    ? 'Syncing...'
                    : `Live Sync${lastLiveSyncTime ? ` • ${lastLiveSyncTime}` : ''}`}
                </span>
              </button>
            )}

            {/* Active stats badges - shown on tablet and desktop */}
            <div className="hidden sm:flex items-center gap-2 bg-slate-900 border border-slate-800 rounded-xl px-3 py-1.5 text-xs shrink-0 shadow-sm">
              <span className="text-slate-300">Actieve Dreigingen:</span>
              <span className="font-mono-code font-extrabold text-rose-400 text-sm">{activeThreatsCount}</span>
            </div>

            <div className="hidden sm:flex items-center gap-2 bg-amber-950/50 border border-amber-900/60 rounded-xl px-3 py-1.5 text-xs shrink-0 shadow-sm">
              <span className="text-amber-200 flex items-center gap-1">
                🇳🇱 Vitale Infra:
              </span>
              <span className="font-mono-code font-extrabold text-amber-400 text-sm">{dutchVitalCount}</span>
            </div>

            {/* Executive PDF Report Export */}
            {onOpenPdfModal && (
              <button
                onClick={onOpenPdfModal}
                className="flex items-center justify-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-700 hover:border-rose-600 hover:bg-slate-800 text-slate-100 hover:text-white font-semibold text-xs transition-all shadow-sm shrink-0 cursor-pointer"
                title="Exporteer actueel CTI directierapport en dashboard overzicht als PDF"
              >
                <FileText className="w-3.5 h-3.5 text-rose-400" />
                <span>PDF Rapport</span>
              </button>
            )}

            {/* Vragen & Reactieformulier knop */}
            {onOpenFeedbackModal && (
              <button
                onClick={onOpenFeedbackModal}
                className={`flex items-center justify-center gap-1.5 px-3 py-1.5 rounded-xl border font-semibold text-xs transition-all shadow-sm shrink-0 cursor-pointer relative ${
                  unreadFeedbackCount > 0 && isOwnerMode
                    ? 'bg-rose-950/80 border-rose-600 text-rose-200 hover:bg-rose-900/80'
                    : 'bg-slate-900 border-slate-700 hover:border-amber-500 hover:bg-slate-800 text-slate-100 hover:text-white'
                }`}
                title={
                  isOwnerMode
                    ? `Beheerder Vragen Inbox: ${unreadFeedbackCount} onbeantwoorde vraag/vragen`
                    : 'Heeft u een vraag of melding? Stel een vraag aan de beheerder'
                }
              >
                <MessageSquare className={`w-3.5 h-3.5 ${unreadFeedbackCount > 0 && isOwnerMode ? 'text-rose-400 animate-bounce' : 'text-amber-400'}`} />
                <span>{isOwnerMode ? 'Vragen Inbox' : 'Stel een Vraag'}</span>
                {unreadFeedbackCount > 0 && isOwnerMode && (
                  <span className="bg-rose-500 text-white text-[10px] font-mono-code font-bold px-1.5 py-0.2 rounded-full animate-pulse">
                    {unreadFeedbackCount}
                  </span>
                )}
              </button>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};
