import React, { useState } from 'react';
import {
  X,
  Share2,
  Copy,
  Check,
  ExternalLink,
  Mail,
  Send,
  MessageSquare,
  Globe,
  Radio,
  Newspaper,
  Tv,
  Cpu,
  Search,
  Sparkles,
  ShieldAlert,
} from 'lucide-react';
import { ThreatItem } from '../types/threat';

export interface SocialAndMediaShareModalProps {
  isOpen: boolean;
  onClose: () => void;
  threat?: ThreatItem | null;
  customTitle?: string;
  customDescription?: string;
}

interface MediaContact {
  name: string;
  category: 'KRANT' | 'OMROEP' | 'TECH_MEDIA';
  emails: string[];
  primaryEmail: string;
  website: string;
  description: string;
}

export const DUTCH_MEDIA_CONTACTS: MediaContact[] = [
  // LANDELIJKE KRANTEN & DAGBLADEN
  {
    name: 'De Telegraaf',
    category: 'KRANT',
    primaryEmail: 'binnenland@telegraaf.nl',
    emails: ['binnenland@telegraaf.nl', 'digitaal@telegraaf.nl', 'nieuwsdienst@telegraaf.nl'],
    website: 'https://www.telegraaf.nl',
    description: 'Grootste dagblad van NL; binnenland- en digitaalredactie voor acute dreigingen.',
  },
  {
    name: 'AD (Algemeen Dagblad)',
    category: 'KRANT',
    primaryEmail: 'redactie@ad.nl',
    emails: ['redactie@ad.nl', 'digitaal@ad.nl', 'tiplijn@ad.nl'],
    website: 'https://www.ad.nl',
    description: 'Landelijke redactie en tech-verslaggevers met regionaal netwerk.',
  },
  {
    name: 'NRC',
    category: 'KRANT',
    primaryEmail: 'redactie@nrc.nl',
    emails: ['redactie@nrc.nl', 'tech@nrc.nl', 'economie@nrc.nl'],
    website: 'https://www.nrc.nl',
    description: 'Kwaliteitsdagblad met diepgravende cyberveiligheid- en economieredactie.',
  },
  {
    name: 'de Volkskrant',
    category: 'KRANT',
    primaryEmail: 'redactie@volkskrant.nl',
    emails: ['redactie@volkskrant.nl', 'economie@volkskrant.nl'],
    website: 'https://www.volkskrant.nl',
    description: 'Landelijke onderzoeksredactie voor nationale veiligheid en vitale infrastructuur.',
  },
  {
    name: 'Het Financieele Dagblad (FD)',
    category: 'KRANT',
    primaryEmail: 'redactie@fd.nl',
    emails: ['redactie@fd.nl', 'tech@fd.nl'],
    website: 'https://www.fd.nl',
    description: 'Financieel-economisch dagblad; focus op beursgenoteerde bedrijven & vitale ketens.',
  },
  {
    name: 'Trouw',
    category: 'KRANT',
    primaryEmail: 'redactie@trouw.nl',
    emails: ['redactie@trouw.nl'],
    website: 'https://www.trouw.nl',
    description: 'Landelijke nieuwsredactie met focus op maatschappelijke impact en overheid.',
  },
  {
    name: 'Het Parool',
    category: 'KRANT',
    primaryEmail: 'redactie@parool.nl',
    emails: ['redactie@parool.nl'],
    website: 'https://www.parool.nl',
    description: 'Amsterdams en nationaal dagblad; focus op datacenter-hub Amsterdam en AMS-IX.',
  },
  {
    name: 'Reformatorisch Dagblad (RD)',
    category: 'KRANT',
    primaryEmail: 'redactie@rd.nl',
    emails: ['redactie@rd.nl'],
    website: 'https://www.rd.nl',
    description: 'Landelijk dagblad met binnenland- en economieredactie.',
  },
  {
    name: 'Nederlands Dagblad (ND)',
    category: 'KRANT',
    primaryEmail: 'redactie@nd.nl',
    emails: ['redactie@nd.nl'],
    website: 'https://www.nd.nl',
    description: 'Christelijk-betrokken landelijk dagblad voor politiek en maatschappij.',
  },

  // OMROEPEN & NIEUWSAGENTSCHAPPEN
  {
    name: 'NOS Nieuws & Tech',
    category: 'OMROEP',
    primaryEmail: 'redactie@nos.nl',
    emails: ['redactie@nos.nl', 'nosnieuws@nos.nl', 'tips@nos.nl'],
    website: 'https://nos.nl',
    description: 'Publieke omroep en nationale calamiteitenzender met gespecialiseerde techredactie.',
  },
  {
    name: 'RTL Nieuws & RTL Tech',
    category: 'OMROEP',
    primaryEmail: 'redactie@rtlnieuws.nl',
    emails: ['redactie@rtlnieuws.nl', 'economie@rtlnieuws.nl'],
    website: 'https://www.rtlnieuws.nl',
    description: 'Commerciële marktleider met onderzoeksjournalisten op cybersecurity.',
  },
  {
    name: 'ANP (Algemeen Nederlands Persbureau)',
    category: 'OMROEP',
    primaryEmail: 'redactie@anp.nl',
    emails: ['redactie@anp.nl'],
    website: 'https://www.anp.nl',
    description: 'Centraal persbureau dat alle Nederlandse redacties simultaan voedt.',
  },
  {
    name: 'NU.nl (Tech & Algemeen)',
    category: 'OMROEP',
    primaryEmail: 'redactie@nu.nl',
    emails: ['redactie@nu.nl', 'tech@nu.nl'],
    website: 'https://www.nu.nl',
    description: 'Grootste online nieuwssite van Nederland met 24/7 techdesk.',
  },
  {
    name: 'BNR Nieuwsradio',
    category: 'OMROEP',
    primaryEmail: 'redactie@bnr.nl',
    emails: ['redactie@bnr.nl', 'digitaal@bnr.nl'],
    website: 'https://www.bnr.nl',
    description: 'Nieuwsradio met dagelijkse BNR Digitaal uitzendingen over cybersecurity.',
  },
  {
    name: 'EenVandaag (AVROTROS)',
    category: 'OMROEP',
    primaryEmail: 'eenvandaag@avrotros.nl',
    emails: ['eenvandaag@avrotros.nl'],
    website: 'https://eenvandaag.avrotros.nl',
    description: 'Actualiteitenrubriek NPO 1 met opiniepanel en diepgravende reportages.',
  },
  {
    name: 'Nieuwsuur (NOS/NTR)',
    category: 'OMROEP',
    primaryEmail: 'nieuwsuur@nos.nl',
    emails: ['nieuwsuur@nos.nl'],
    website: 'https://nos.nl/nieuwsuur',
    description: 'Verdiepende avonduitzending met focus op nationale defensie en spionage.',
  },

  // TECH & CYBER GESPECIALISEERDE MEDIA
  {
    name: 'Tweakers',
    category: 'TECH_MEDIA',
    primaryEmail: 'nieuws@tweakers.net',
    emails: ['nieuws@tweakers.net'],
    website: 'https://tweakers.net',
    description: 'Grootste tech- en IT-nieuwssite van de Benelux met actieve securitydesk.',
  },
  {
    name: 'Security.NL',
    category: 'TECH_MEDIA',
    primaryEmail: 'redactie@security.nl',
    emails: ['redactie@security.nl'],
    website: 'https://www.security.nl',
    description: 'Nederlands platform uitsluitend gewijd aan informatiebeveiliging en privacy.',
  },
  {
    name: 'AG Connect',
    category: 'TECH_MEDIA',
    primaryEmail: 'redactie@agconnect.nl',
    emails: ['redactie@agconnect.nl'],
    website: 'https://www.agconnect.nl',
    description: 'Vakmedium voor IT-professionals, C-level directie en overheids-ICT.',
  },
  {
    name: 'Computable',
    category: 'TECH_MEDIA',
    primaryEmail: 'redactie@computable.nl',
    emails: ['redactie@computable.nl'],
    website: 'https://www.computable.nl',
    description: 'B2B ICT-platform voor marktontwikkelingen, leveranciers en wetgeving.',
  },
  {
    name: 'Emerce',
    category: 'TECH_MEDIA',
    primaryEmail: 'redactie@emerce.nl',
    emails: ['redactie@emerce.nl'],
    website: 'https://www.emerce.nl',
    description: 'Medium over digitale transformatie, e-commerce en internetveiligheid.',
  },
];

export const SocialAndMediaShareModal: React.FC<SocialAndMediaShareModalProps> = ({
  isOpen,
  onClose,
  threat,
  customTitle,
  customDescription,
}) => {
  const [activeTab, setActiveTab] = useState<'SOCIALS' | 'MEDIA_EMAILS'>('SOCIALS');
  const [mediaCategoryFilter, setMediaCategoryFilter] = useState<'ALL' | 'KRANT' | 'OMROEP' | 'TECH_MEDIA'>('ALL');
  const [mediaSearchQuery, setMediaSearchQuery] = useState<string>('');
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  if (!isOpen) return null;

  const currentUrl = typeof window !== 'undefined' ? window.location.href : 'https://ncsc-monitor.nl';

  // Format share texts
  const shareTitle = threat ? threat.title : customTitle || 'Cyber Threat Intelligence Monitor Nederland';
  const shareTarget = threat ? `${threat.targetVictim} (${threat.targetLocation})` : 'Vitale Infrastructuur';
  const shareActor = threat ? `${threat.threatActor} [${threat.originCountry}]` : 'Geavanceerde Dreigingsactoren';
  const shareSeverity = threat ? threat.severity : 'KRITIEK';

  // LinkedIn text
  const linkedinText = threat
    ? `🚨 CTI ALERT: ${threat.title}\n\nDoelwit: ${threat.targetVictim}\nActor: ${threat.threatActor} (${threat.originCountry})\nErnst: ${threat.severity}\n\nDetails: ${threat.description}\n\nBron: Nationale Bedreigingsmonitor Nederland\n#cybersecurity #NCSC #infosec #vitaleinfrastructuur #threatintel #nederland`
    : `🚨 NATIONAAL VEILIGHEIDSBEELD: ${shareTitle}\n\n${customDescription || 'Actuele dreigingsanalyse vitale infrastructuur Nederland.'}\n\n#cybersecurity #NCSC #vitaleinfra #threatintel #nederland`;

  // X (Twitter) text
  const xText = threat
    ? `🚨 NL CTI ALERT: ${threat.title.slice(0, 80)}...\n\n🎯 Doel: ${threat.targetVictim}\n⚠️ Ernst: ${threat.severity}\n👤 Actor: ${threat.threatActor}\n\nVolg realtime: ${currentUrl}\n#cybersecurity #NCSC`
    : `🚨 NL Cyber Threat Monitor: ${shareTitle.slice(0, 90)}...\n\nVolg realtime updates: ${currentUrl}\n#cybersecurity #NCSC`;

  // Telegram text
  const telegramText = threat
    ? `🚨 *CYBER THREAT ALERT (NCSC MONITOR)*\n\n*Titel:* ${threat.title}\n*Ernst:* ${threat.severity}\n*Doelwit:* ${threat.targetVictim} (${threat.targetLocation})\n*Actor:* ${threat.threatActor} [${threat.originCountry}]\n\n*Omschrijving:*\n${threat.description}\n\n🔗 ${currentUrl}`
    : `🚨 *NATIONAAL CTI BEELD NEDERLAND*\n\n${shareTitle}\n\n${customDescription || ''}\n\n🔗 ${currentUrl}`;

  // WhatsApp text
  const whatsappText = threat
    ? `*CTI ALERT NL:* ${threat.title}\nErnst: ${threat.severity}\nDoel: ${threat.targetVictim}\nActor: ${threat.threatActor}\n\nInfo: ${currentUrl}`
    : `*NCSC Bedreigingsmonitor NL:* ${shareTitle}\n\nInfo: ${currentUrl}`;

  const copyToClipboard = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  // Filtered media contacts
  const filteredMedia = DUTCH_MEDIA_CONTACTS.filter((m) => {
    const matchesCategory = mediaCategoryFilter === 'ALL' || m.category === mediaCategoryFilter;
    const matchesSearch =
      mediaSearchQuery === '' ||
      m.name.toLowerCase().includes(mediaSearchQuery.toLowerCase()) ||
      m.primaryEmail.toLowerCase().includes(mediaSearchQuery.toLowerCase()) ||
      m.description.toLowerCase().includes(mediaSearchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const allFilteredEmails = Array.from(new Set(filteredMedia.flatMap((m) => m.emails))).join('; ');

  const handleOpenEmailClient = (toEmail?: string) => {
    const targetEmails = toEmail || allFilteredEmails;
    const subject = encodeURIComponent(`[CTI PERSBULLETIN] ${shareTitle}`);
    const body = encodeURIComponent(
      `Geachte redactie,\n\nHierbij een cybersecurity incident- en dreigingsbulletin afkomstig van de Nederlandse Bedreigingsmonitor:\n\n` +
        `ONDERWERP: ${shareTitle}\n` +
        `ERNST: ${shareSeverity}\n` +
        `DOELWIT: ${shareTarget}\n` +
        `DREIGINGSACTOR: ${shareActor}\n\n` +
        `OMSCHRIJVING:\n${threat ? threat.description : customDescription || ''}\n\n` +
        `Aanvullende forensische gegevens en IoCs zijn te raadplegen via:\n${currentUrl}\n\n` +
        `Met vriendelijke groet,\nCyber Threat Intelligence Desk Nederland`
    );
    window.location.href = `mailto:${targetEmails}?subject=${subject}&body=${body}`;
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
      <div className="bg-slate-900 border border-slate-700/80 rounded-2xl w-full max-w-3xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Modal Header */}
        <div className="p-4 sm:p-5 border-b border-slate-800 bg-slate-950/70 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-blue-500/10 border border-blue-500/30 text-blue-400">
              <Share2 className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold text-white flex items-center gap-2">
                Social Media & Media Redacties
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-blue-950/80 text-blue-300 border border-blue-800/60">
                  VERSPREIDING
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                Deel direct op LinkedIn, X, Telegram of verstuur naar Nederlandse kranten en omroepen.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Selected Context Banner */}
        <div className="px-4 py-2 bg-slate-950/90 border-b border-slate-800/80 flex items-center justify-between text-xs">
          <div className="flex items-center gap-2 truncate pr-2">
            <ShieldAlert className="w-3.5 h-3.5 text-rose-400 shrink-0" />
            <span className="text-slate-400 shrink-0">Onderwerp:</span>
            <span className="font-semibold text-white truncate">{shareTitle}</span>
          </div>
          {threat && (
            <span className="shrink-0 text-[10px] font-bold px-2 py-0.5 rounded bg-rose-950/60 text-rose-300 border border-rose-800/50">
              {threat.severity}
            </span>
          )}
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-slate-800 bg-slate-950/40 px-4 pt-2">
          <button
            onClick={() => setActiveTab('SOCIALS')}
            className={`flex items-center gap-2 px-3.5 py-2 text-xs font-semibold border-b-2 transition-all ${
              activeTab === 'SOCIALS'
                ? 'border-blue-500 text-white'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Globe className="w-3.5 h-3.5" />
            <span>Social Media Integraties (LinkedIn, X, Telegram)</span>
          </button>
          <button
            onClick={() => setActiveTab('MEDIA_EMAILS')}
            className={`flex items-center gap-2 px-3.5 py-2 text-xs font-semibold border-b-2 transition-all ${
              activeTab === 'MEDIA_EMAILS'
                ? 'border-blue-500 text-white'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Newspaper className="w-3.5 h-3.5 text-amber-400" />
            <span>Kranten & Omroepen Redactieadressen ({DUTCH_MEDIA_CONTACTS.length})</span>
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-4 sm:p-5 overflow-y-auto space-y-4">
          {activeTab === 'SOCIALS' ? (
            <div className="space-y-4">
              {/* LinkedIn Section */}
              <div className="p-4 rounded-xl bg-slate-950/70 border border-slate-800 space-y-2.5">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="w-6 h-6 rounded bg-[#0A66C2] flex items-center justify-center text-white font-bold text-xs">
                      in
                    </span>
                    <span className="text-xs font-bold text-white">LinkedIn (Directie & Security Professionals)</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => copyToClipboard(linkedinText, 'linkedin')}
                      className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium border border-slate-700 transition-colors"
                    >
                      {copiedKey === 'linkedin' ? (
                        <>
                          <Check className="w-3 h-3 text-emerald-400" />
                          <span className="text-emerald-300">Gekopieerd!</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3 h-3 text-slate-400" />
                          <span>Kopieer Tekst</span>
                        </>
                      )}
                    </button>
                    <a
                      href={`https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(currentUrl)}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1 px-3 py-1 rounded-lg bg-[#0A66C2] hover:bg-[#004182] text-white text-xs font-bold transition-all shadow-sm"
                    >
                      <ExternalLink className="w-3 h-3" />
                      <span>Deel op LinkedIn</span>
                    </a>
                  </div>
                </div>
                <div className="bg-slate-900 p-3 rounded-lg border border-slate-800 text-xs text-slate-300 font-mono whitespace-pre-line line-clamp-3">
                  {linkedinText}
                </div>
              </div>

              {/* X (Twitter) Section */}
              <div className="p-4 rounded-xl bg-slate-950/70 border border-slate-800 space-y-2.5">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="w-6 h-6 rounded bg-black border border-slate-700 flex items-center justify-center text-white font-bold text-xs">
                      𝕏
                    </span>
                    <span className="text-xs font-bold text-white">X / Twitter (Snelle waarschuwing & OSINT)</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => copyToClipboard(xText, 'x')}
                      className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium border border-slate-700 transition-colors"
                    >
                      {copiedKey === 'x' ? (
                        <>
                          <Check className="w-3 h-3 text-emerald-400" />
                          <span className="text-emerald-300">Gekopieerd!</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3 h-3 text-slate-400" />
                          <span>Kopieer Tweet</span>
                        </>
                      )}
                    </button>
                    <a
                      href={`https://twitter.com/intent/tweet?text=${encodeURIComponent(xText)}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1 px-3 py-1 rounded-lg bg-slate-100 hover:bg-white text-slate-950 text-xs font-bold transition-all shadow-sm"
                    >
                      <ExternalLink className="w-3 h-3" />
                      <span>Post op 𝕏</span>
                    </a>
                  </div>
                </div>
                <div className="bg-slate-900 p-3 rounded-lg border border-slate-800 text-xs text-slate-300 font-mono whitespace-pre-line">
                  {xText}
                </div>
              </div>

              {/* Telegram & WhatsApp Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {/* Telegram */}
                <div className="p-3.5 rounded-xl bg-slate-950/70 border border-slate-800 space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="w-5 h-5 rounded-full bg-[#229ED9] flex items-center justify-center text-white text-[10px]">
                        ✈
                      </span>
                      <span className="text-xs font-bold text-white">Telegram Kanaal</span>
                    </div>
                    <a
                      href={`https://t.me/share/url?url=${encodeURIComponent(currentUrl)}&text=${encodeURIComponent(telegramText)}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-[#229ED9] hover:bg-[#1a85b8] text-white text-[11px] font-bold"
                    >
                      <Send className="w-3 h-3" />
                      <span>Telegram</span>
                    </a>
                  </div>
                  <p className="text-[11px] text-slate-400">
                    Stuur direct naar IT-beveiliging en CERT Telegram groepen.
                  </p>
                </div>

                {/* WhatsApp */}
                <div className="p-3.5 rounded-xl bg-slate-950/70 border border-slate-800 space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="w-5 h-5 rounded-full bg-[#25D366] flex items-center justify-center text-white text-[10px]">
                        💬
                      </span>
                      <span className="text-xs font-bold text-white">WhatsApp Broadcast</span>
                    </div>
                    <a
                      href={`https://api.whatsapp.com/send?text=${encodeURIComponent(whatsappText)}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-[#25D366] hover:bg-[#1ebc57] text-white text-[11px] font-bold"
                    >
                      <MessageSquare className="w-3 h-3" />
                      <span>WhatsApp</span>
                    </a>
                  </div>
                  <p className="text-[11px] text-slate-400">
                    Verzend snel naar crisisoverleg of directie WhatsApp-groep.
                  </p>
                </div>
              </div>
            </div>
          ) : (
            /* MEDIA REDACTIE & KRANTEN ADRESSEN TAB */
            <div className="space-y-3.5">
              {/* Action and Filter Header */}
              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex flex-col sm:flex-row gap-2.5 items-stretch sm:items-center justify-between">
                {/* Search */}
                <div className="relative flex-1">
                  <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={mediaSearchQuery}
                    onChange={(e) => setMediaSearchQuery(e.target.value)}
                    placeholder="Zoek krant of omroep (bijv. Telegraaf, NOS, FD, Tweakers)..."
                    className="w-full bg-slate-900 border border-slate-700/80 rounded-lg pl-8 pr-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
                  />
                </div>

                {/* Categories */}
                <div className="flex items-center gap-1 overflow-x-auto scrollbar-none">
                  {[
                    { id: 'ALL', label: 'Alles' },
                    { id: 'KRANT', label: 'Kranten' },
                    { id: 'OMROEP', label: 'Omroepen' },
                    { id: 'TECH_MEDIA', label: 'Tech Media' },
                  ].map((cat) => (
                    <button
                      key={cat.id}
                      onClick={() => setMediaCategoryFilter(cat.id as any)}
                      className={`px-2.5 py-1 rounded-lg text-xs font-semibold whitespace-nowrap transition-all ${
                        mediaCategoryFilter === cat.id
                          ? 'bg-blue-600 text-white'
                          : 'bg-slate-900 text-slate-400 hover:text-white'
                      }`}
                    >
                      {cat.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Bulk actions bar */}
              <div className="flex flex-wrap items-center justify-between gap-2 p-2.5 rounded-xl bg-blue-950/30 border border-blue-900/50">
                <span className="text-xs text-blue-200">
                  <strong>{filteredMedia.length}</strong> redacties geselecteerd
                </span>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => copyToClipboard(allFilteredEmails, 'all-emails')}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 transition-colors cursor-pointer"
                  >
                    {copiedKey === 'all-emails' ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                        <span className="text-emerald-300">Mailadressen gekopieerd!</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5 text-slate-400" />
                        <span>Kopieer alle adressen (BCC)</span>
                      </>
                    )}
                  </button>
                  <button
                    onClick={() => handleOpenEmailClient()}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold transition-all cursor-pointer shadow-sm"
                  >
                    <Mail className="w-3.5 h-3.5" />
                    <span>Open in Mailprogramma</span>
                  </button>
                </div>
              </div>

              {/* Media List */}
              <div className="space-y-2 max-h-[380px] overflow-y-auto pr-1">
                {filteredMedia.map((media) => {
                  const categoryBadge =
                    media.category === 'KRANT'
                      ? { label: 'Krant', color: 'bg-amber-950/80 text-amber-300 border-amber-800/60' }
                      : media.category === 'OMROEP'
                      ? { label: 'Omroep', color: 'bg-emerald-950/80 text-emerald-300 border-emerald-800/60' }
                      : { label: 'Tech Media', color: 'bg-purple-950/80 text-purple-300 border-purple-800/60' };

                  return (
                    <div
                      key={media.name}
                      className="p-3 rounded-xl bg-slate-950/80 border border-slate-800/90 hover:border-slate-700 transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-2.5"
                    >
                      <div className="space-y-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-xs text-white">{media.name}</span>
                          <span
                            className={`text-[9px] font-mono px-1.5 py-0.2 rounded border ${categoryBadge.color}`}
                          >
                            {categoryBadge.label}
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-400 truncate">{media.description}</p>
                        <div className="flex flex-wrap gap-1.5 pt-0.5">
                          {media.emails.map((email) => (
                            <span
                              key={email}
                              className="font-mono text-[10px] text-cyan-300 bg-cyan-950/30 border border-cyan-800/40 px-1.5 py-0.2 rounded"
                            >
                              {email}
                            </span>
                          ))}
                        </div>
                      </div>

                      <div className="flex items-center gap-1.5 shrink-0 self-end sm:self-center">
                        <button
                          onClick={() => copyToClipboard(media.emails.join('; '), media.name)}
                          className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 transition-colors"
                          title="Kopieer e-mailadressen"
                        >
                          {copiedKey === media.name ? (
                            <Check className="w-3.5 h-3.5 text-emerald-400" />
                          ) : (
                            <Copy className="w-3.5 h-3.5 text-slate-400" />
                          )}
                        </button>
                        <button
                          onClick={() => handleOpenEmailClient(media.primaryEmail)}
                          className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-blue-900/60 hover:bg-blue-800 text-blue-200 text-xs font-semibold border border-blue-700/60 transition-colors"
                          title="Stel direct e-mail op"
                        >
                          <Mail className="w-3 h-3 text-blue-300" />
                          <span>Mail</span>
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-4 sm:p-5 border-t border-slate-800 bg-slate-950/70 flex items-center justify-between">
          <span className="text-[11px] text-slate-500">
            NCSC Bedreigingsmonitor • Geïntegreerde Socials & Mediadienst
          </span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold transition-colors"
          >
            Sluiten
          </button>
        </div>
      </div>
    </div>
  );
};
