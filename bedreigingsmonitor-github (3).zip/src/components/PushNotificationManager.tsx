import React, { useState, useEffect } from 'react';
import {
  Bell,
  BellRing,
  X,
  ShieldAlert,
  Volume2,
  CheckCircle2,
  AlertTriangle,
  Play,
  RotateCcw,
  Sparkles,
} from 'lucide-react';
import { NotificationSettings, ThreatSeverity } from '../types/threat';
import {
  getPushPermissionState,
  isPushSupported,
  requestPushPermission,
  playAlertSound,
} from '../utils/notifications';

interface PushNotificationManagerProps {
  isOpen: boolean;
  onClose: () => void;
  settings: NotificationSettings;
  onUpdateSettings: (newSettings: NotificationSettings) => void;
  onTriggerTestPush: () => void;
}

export const PushNotificationManager: React.FC<PushNotificationManagerProps> = ({
  isOpen,
  onClose,
  settings,
  onUpdateSettings,
  onTriggerTestPush,
}) => {
  const [permissionState, setPermissionState] = useState<NotificationPermission>('default');
  const [supported, setSupported] = useState<boolean>(true);
  const [justTested, setJustTested] = useState<boolean>(false);

  useEffect(() => {
    setSupported(isPushSupported());
    setPermissionState(getPushPermissionState());
  }, [isOpen]);

  if (!isOpen) return null;

  const handleRequestPermission = async () => {
    const res = await requestPushPermission();
    setPermissionState(res);
    if (res === 'granted') {
      onUpdateSettings({ ...settings, pushEnabled: true });
      playAlertSound('HOOG');
    } else {
      onUpdateSettings({ ...settings, pushEnabled: false });
    }
  };

  const handleTest = () => {
    onTriggerTestPush();
    setJustTested(true);
    setTimeout(() => setJustTested(false), 3000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2.5 sm:p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-150">
      <div className="bg-slate-900 border border-slate-700/80 rounded-xl sm:rounded-2xl max-w-lg w-full p-3.5 sm:p-6 shadow-2xl relative overflow-hidden max-h-[92vh] overflow-y-auto">
        {/* Glow ambient background */}
        <div className="absolute -top-20 -right-20 w-44 h-44 bg-rose-600/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-20 -left-20 w-44 h-44 bg-amber-600/10 rounded-full blur-3xl pointer-events-none" />

        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-rose-950/70 border border-rose-800/80 text-rose-400">
              <BellRing className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white">Pushberichten & Dreigingsalarm</h2>
              <p className="text-xs text-slate-400">
                Ontvang directe waarschuwingen bij nieuwe ransomware en darkweb dreigingen
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Master 1-Click Disable / Enable Banner */}
        <div className="mt-4 p-4 rounded-xl border bg-slate-950/90 border-slate-800 space-y-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <div className="text-xs font-bold text-white flex items-center gap-2">
                <span>Status Pushberichten & Pop-up Meldingen</span>
                {settings.pushEnabled || settings.liveSimulationActive || settings.soundEnabled ? (
                  <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-400 bg-emerald-950/80 border border-emerald-700 px-2 py-0.5 rounded-md">
                    <CheckCircle2 className="w-3 h-3" /> Actief
                  </span>
                ) : (
                  <span className="inline-flex items-center gap-1 text-[11px] font-bold text-slate-300 bg-slate-800 border border-slate-700 px-2 py-0.5 rounded-md">
                    🔕 Uitgeschakeld (Stil)
                  </span>
                )}
              </div>
              <p className="text-[11px] text-slate-400 mt-1">
                Schakel hier in één klik alle pushberichten, pop-up meldingen rechtsonder én geluidssignalen volledig uit of aan.
              </p>
            </div>

            {settings.pushEnabled || settings.liveSimulationActive || settings.soundEnabled ? (
              <button
                type="button"
                onClick={() =>
                  onUpdateSettings({
                    ...settings,
                    pushEnabled: false,
                    liveSimulationActive: false,
                    soundEnabled: false,
                  })
                }
                className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs transition-colors shadow-md shadow-rose-950 shrink-0 cursor-pointer"
              >
                🔕 Alles Direct Uitzetten
              </button>
            ) : (
              <button
                type="button"
                onClick={async () => {
                  const res = await requestPushPermission();
                  setPermissionState(res);
                  onUpdateSettings({
                    ...settings,
                    pushEnabled: res === 'granted',
                    liveSimulationActive: true,
                    soundEnabled: true,
                  });
                }}
                className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs transition-colors shadow-md shadow-emerald-950 shrink-0 cursor-pointer"
              >
                🔔 Meldingen Inschakelen
              </button>
            )}
          </div>

          <div className="pt-2.5 border-t border-slate-800/80 flex items-center justify-between text-xs">
            <span className="text-slate-400">
              Browser toestemming:{' '}
              <strong className="text-slate-200">
                {permissionState === 'granted'
                  ? 'Toegestaan in browser'
                  : permissionState === 'denied'
                  ? 'Geblokkeerd in browser'
                  : 'Standaard (Uit)'}
              </strong>
            </span>
            {permissionState !== 'granted' ? (
              <button
                type="button"
                onClick={handleRequestPermission}
                className="px-3 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs transition-colors cursor-pointer"
              >
                Browser Push Toestaan
              </button>
            ) : (
              <button
                type="button"
                onClick={handleTest}
                className="flex items-center gap-1.5 px-3 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs transition-colors border border-slate-700 cursor-pointer"
              >
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                <span>{justTested ? 'Verzonden!' : 'Verstuur Test'}</span>
              </button>
            )}
          </div>
          {permissionState === 'denied' && (
            <p className="mt-1 text-[11px] text-rose-300">
              Notificaties zijn geblokkeerd in uw browserinstellingen. Klik op het slotje links in uw adresbalk om dit aan te passen.
            </p>
          )}
        </div>

        {/* Filter rules & focus settings */}
        <div className="mt-5 space-y-4">
          <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider">
            Geopolitieke & Doelwit Filters
          </h3>

          <div className="space-y-2.5">
            {/* Rusland focus */}
            <label className="flex items-start gap-3 p-3 rounded-xl bg-slate-950/40 border border-slate-800/80 hover:border-slate-700 cursor-pointer transition-colors">
              <input
                type="checkbox"
                checked={settings.notifyOnRussia}
                onChange={(e) => onUpdateSettings({ ...settings, notifyOnRussia: e.target.checked })}
                className="mt-1 rounded bg-slate-800 border-slate-700 text-rose-600 focus:ring-0 focus:ring-offset-0"
              />
              <div className="text-xs">
                <div className="font-semibold text-white flex items-center gap-1.5">
                  <span>🇷🇺 Dreigingen uit Rusland</span>
                  <span className="text-[10px] bg-rose-950 text-rose-300 px-1.5 py-0.2 rounded border border-rose-800">
                    GRU / Sandworm / LockBit / Basta
                  </span>
                </div>
                <div className="text-slate-400 mt-0.5">
                  Directe waarschuwing bij ransomware en wipers van Russische oorsprong gericht op Europa.
                </div>
              </div>
            </label>

            {/* China focus */}
            <label className="flex items-start gap-3 p-3 rounded-xl bg-slate-950/40 border border-slate-800/80 hover:border-slate-700 cursor-pointer transition-colors">
              <input
                type="checkbox"
                checked={settings.notifyOnChina}
                onChange={(e) => onUpdateSettings({ ...settings, notifyOnChina: e.target.checked })}
                className="mt-1 rounded bg-slate-800 border-slate-700 text-amber-600 focus:ring-0 focus:ring-offset-0"
              />
              <div className="text-xs">
                <div className="font-semibold text-white flex items-center gap-1.5">
                  <span>🇨🇳 Dreigingen uit China</span>
                  <span className="text-[10px] bg-amber-950 text-amber-300 px-1.5 py-0.2 rounded border border-amber-800">
                    Volt Typhoon / Salt Typhoon / MSS
                  </span>
                </div>
                <div className="text-slate-400 mt-0.5">
                  Waarschuwing bij pre-positioning op kritieke OT/SCADA en telecom backbones.
                </div>
              </div>
            </label>

            {/* Noord-Korea focus */}
            <label className="flex items-start gap-3 p-3 rounded-xl bg-slate-950/40 border border-slate-800/80 hover:border-slate-700 cursor-pointer transition-colors">
              <input
                type="checkbox"
                checked={settings.notifyOnNorthKorea}
                onChange={(e) => onUpdateSettings({ ...settings, notifyOnNorthKorea: e.target.checked })}
                className="mt-1 rounded bg-slate-800 border-slate-700 text-red-600 focus:ring-0 focus:ring-offset-0"
              />
              <div className="text-xs">
                <div className="font-semibold text-white flex items-center gap-1.5">
                  <span>🇰🇵 Dreigingen uit Noord-Korea</span>
                  <span className="text-[10px] bg-red-950 text-red-300 px-1.5 py-0.2 rounded border border-red-800">
                    Lazarus Group / Kimsuky / RGB Eenheid 121
                  </span>
                </div>
                <div className="text-slate-400 mt-0.5">
                  Crypto/fintech-heists, supply-chain inbraken en spionage op defensie- en maritieme technologie.
                </div>
              </div>
            </label>

            {/* Iran focus */}
            <label className="flex items-start gap-3 p-3 rounded-xl bg-slate-950/40 border border-slate-800/80 hover:border-slate-700 cursor-pointer transition-colors">
              <input
                type="checkbox"
                checked={settings.notifyOnIran}
                onChange={(e) => onUpdateSettings({ ...settings, notifyOnIran: e.target.checked })}
                className="mt-1 rounded bg-slate-800 border-slate-700 text-emerald-600 focus:ring-0 focus:ring-offset-0"
              />
              <div className="text-xs">
                <div className="font-semibold text-white flex items-center gap-1.5">
                  <span>🇮🇷 Dreigingen uit Iran</span>
                  <span className="text-[10px] bg-emerald-950 text-emerald-300 px-1.5 py-0.2 rounded border border-emerald-800">
                    Charming Kitten / MuddyWater / IRGC & MOIS
                  </span>
                </div>
                <div className="text-slate-400 mt-0.5">
                  Sabotage- en spionagecampagnes gericht op energiehavens, petrochemie en diplomatiek verkeer.
                </div>
              </div>
            </label>

            {/* Dark Web leak blogs focus */}
            <label className="flex items-start gap-3 p-3 rounded-xl bg-slate-950/40 border border-slate-800/80 hover:border-slate-700 cursor-pointer transition-colors">
              <input
                type="checkbox"
                checked={settings.notifyOnDarkweb}
                onChange={(e) => onUpdateSettings({ ...settings, notifyOnDarkweb: e.target.checked })}
                className="mt-1 rounded bg-slate-800 border-slate-700 text-purple-600 focus:ring-0 focus:ring-offset-0"
              />
              <div className="text-xs">
                <div className="font-semibold text-white flex items-center gap-1.5">
                  <span>🏴‍☠️ Dark Web .Onion Lek-sites & Veilingen</span>
                  <span className="text-[10px] bg-purple-950 text-purple-300 px-1.5 py-0.2 rounded border border-purple-800">
                    Tor Leaks / Afteltimers
                  </span>
                </div>
                <div className="text-slate-400 mt-0.5">
                  Melding zodra een nieuw slachtoffer of losgeldafteltimer wordt gepubliceerd op het darkweb.
                </div>
              </div>
            </label>

            {/* Only Dutch vital infra */}
            <label className="flex items-start gap-3 p-3 rounded-xl bg-amber-950/20 border border-amber-900/40 hover:border-amber-800/60 cursor-pointer transition-colors">
              <input
                type="checkbox"
                checked={settings.vitalInfraOnly}
                onChange={(e) => onUpdateSettings({ ...settings, vitalInfraOnly: e.target.checked })}
                className="mt-1 rounded bg-slate-800 border-slate-700 text-amber-500 focus:ring-0 focus:ring-offset-0"
              />
              <div className="text-xs">
                <div className="font-semibold text-amber-300 flex items-center gap-1.5">
                  <span>🇳🇱 Filter: Alleen Nederlandse Vitale Infrastructuur</span>
                </div>
                <div className="text-slate-400 mt-0.5">
                  Beperk meldingen uitsluitend tot Haven Rotterdam, TenneT, Rijkswaterstaat, Telecom, Zorg en Overheid.
                </div>
              </div>
            </label>
          </div>

          {/* Sound & Min Severity */}
          <div className="grid grid-cols-2 gap-3 pt-2">
            <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800">
              <div className="text-xs font-semibold text-slate-300 mb-1.5 flex items-center gap-1.5">
                <Volume2 className="w-3.5 h-3.5 text-emerald-400" /> Audio Alarm
              </div>
              <label className="flex items-center gap-2 cursor-pointer text-xs text-slate-400">
                <input
                  type="checkbox"
                  checked={settings.soundEnabled}
                  onChange={(e) => onUpdateSettings({ ...settings, soundEnabled: e.target.checked })}
                  className="rounded bg-slate-800 border-slate-700 text-emerald-500 focus:ring-0"
                />
                Cyber chimes afspelen
              </label>
            </div>

            <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800">
              <div className="text-xs font-semibold text-slate-300 mb-1.5">Minimale Ernst</div>
              <select
                value={settings.minSeverity}
                onChange={(e) => onUpdateSettings({ ...settings, minSeverity: e.target.value as ThreatSeverity })}
                className="w-full bg-slate-900 border border-slate-700 rounded-lg text-xs py-1 px-2 text-white focus:outline-none focus:border-rose-500"
              >
                <option value="KRITIEK">Alleen KRITIEK</option>
                <option value="HOOG">HOOG & KRITIEK</option>
                <option value="VERHOOGD">VERHOOGD en hoger</option>
                <option value="MATIG">Alle niveaus</option>
              </select>
            </div>
          </div>

          {/* Realtime background simulation */}
          <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800 flex items-center justify-between">
            <div>
              <div className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                </span>
                Realtime Simulatie Ticker
              </div>
              <div className="text-[11px] text-slate-400 mt-0.5">
                Simuleert continu live binnenkomende dreigingen om het pushmechanisme te demonstreren.
              </div>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={settings.liveSimulationActive}
                onChange={(e) => onUpdateSettings({ ...settings, liveSimulationActive: e.target.checked })}
                className="sr-only peer"
              />
              <div className="w-9 h-5 bg-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-emerald-600"></div>
            </label>
          </div>
        </div>

        {/* Footer actions */}
        <div className="mt-5 sm:mt-6 pt-3 sm:pt-4 border-t border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
          <button
            onClick={handleTest}
            className="w-full sm:w-auto flex items-center justify-center gap-1.5 text-xs text-amber-400 hover:text-amber-300 transition-colors font-semibold py-1.5"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Test Notificatie Nu</span>
          </button>
          <button
            onClick={onClose}
            className="w-full sm:w-auto flex items-center justify-center px-4 py-2 sm:py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-semibold text-xs transition-colors min-h-[38px] sm:min-h-0"
          >
            Instellingen Opslaan
          </button>
        </div>
      </div>
    </div>
  );
};
